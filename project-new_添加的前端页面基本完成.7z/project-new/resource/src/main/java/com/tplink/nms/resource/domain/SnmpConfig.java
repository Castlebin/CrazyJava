package com.tplink.nms.resource.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author fdj
 */

@Entity
@Table(name = "rm_snmp_config", schema = "")
public class SnmpConfig implements Serializable {
    private Integer snmpId;

    private Integer version;
    private Integer port;
    private Integer timeout;
    private Integer retries;
    private Integer templateType = 0;

    private String templateName;
    private String readCommunity;
    private String writeCommunity;

    private String contextName;
    private String securityName;
    private Integer securityMode;
    private Integer authMode;
    private String authPwd;
    private Integer privacyMode;
    private String privacyPwd;

    public SnmpConfig() {

    }

    public SnmpConfig(int snmpVersion) {
        switch (snmpVersion) {
            case 1:    //v1
            case 2:    //v2c
                contextName = "";
                securityMode = 0;
                securityName = "";
                authMode = 0;
                authPwd = "";
                privacyMode = 0;
                privacyPwd = "";

                version = snmpVersion;
                break;
            case 3:    //v3
                readCommunity = "";
                writeCommunity = "";

                version = snmpVersion;
                break;
            default:
                break;
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "snmp_id")
    public Integer getSnmpId() {
        return snmpId;
    }

    public void setSnmpId(Integer snmpId) {
        this.snmpId = snmpId;
    }

    @Column(name = "snmp_version")
    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    @Column(name = "snmp_port")
    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    @Column(name = "snmp_timeout")
    public Integer getTimeout() {
        return timeout;
    }

    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    @Column(name = "snmp_retries")
    public Integer getRetries() {
        return retries;
    }

    public void setRetries(Integer retries) {
        this.retries = retries;
    }

    @Column(name = "template_type")
    public Integer getTemplateType() {
        return templateType;
    }

    public void setTemplateType(Integer templateType) {
        this.templateType = templateType;
    }

    @Column(name = "template_name", unique = true)
    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    @Column(name = "snmp_readcommunity")
    public String getReadCommunity() {
        return readCommunity;
    }

    public void setReadCommunity(String readCommunity) {
        this.readCommunity = readCommunity;
    }

    @Column(name = "snmp_writecommunity")
    public String getWriteCommunity() {
        return writeCommunity;
    }

    public void setWriteCommunity(String writeCommunity) {
        this.writeCommunity = writeCommunity;
    }

    @Column(name = "snmp_context_name")
    public String getContextName() {
        return contextName;
    }

    public void setContextName(String contextName) {
        this.contextName = contextName;
    }

    @Column(name = "snmp_security_name")
    public String getSecurityName() {
        return securityName;
    }

    public void setSecurityName(String securityName) {
        this.securityName = securityName;
    }

    @Column(name = "snmp_security_mode")
    public Integer getSecurityMode() {
        return securityMode;
    }

    public void setSecurityMode(Integer securityMode) {
        this.securityMode = securityMode;
    }

    @Column(name = "snmp_auth_mode")
    public Integer getAuthMode() {
        return authMode;
    }

    public void setAuthMode(Integer authMode) {
        this.authMode = authMode;
        refreshSecurityMode();
    }

    @Column(name = "snmp_auth_pwd")
    public String getAuthPwd() {
        return authPwd;
    }

    public void setAuthPwd(String authPwd) {
        this.authPwd = authPwd;
    }

    @Column(name = "snmp_privacy_mode")
    public Integer getPrivacyMode() {
        return privacyMode;
    }

    public void setPrivacyMode(Integer privacyMode) {
        this.privacyMode = privacyMode;
    }

    @Column(name = "snmp_privacy_pwd")
    public String getPrivacyPwd() {
        return privacyPwd;
    }

    public void setPrivacyPwd(String privacyPwd) {
        this.privacyPwd = privacyPwd;
        refreshSecurityMode();
    }

    private void refreshSecurityMode() {
        if(authMode == null || privacyMode == null)
            return;

        if((authMode == 0) && privacyMode == 0) {
            securityMode = 0;
        }else if(privacyMode == 0) {
            securityMode = 1;
        }else if(authMode == 1) {
            securityMode = 2;
        }
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("{");
        builder.append("name:").append(templateName);
        builder.append(",version:").append(version);
        builder.append(",port:").append(port);
        builder.append(",timeout:").append(timeout);
        return builder.toString();
    }
}
