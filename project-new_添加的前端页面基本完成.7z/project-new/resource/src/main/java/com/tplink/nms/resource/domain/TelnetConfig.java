package com.tplink.nms.resource.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author fdj
 */
@Entity
@Table(name = "rm_telnet_config", schema = "")
public class TelnetConfig {
    private Integer telnetId;

    private Integer authMode;
    private Integer port;
    private Integer timeout;
    private Integer retries;
    private Integer templateType;

    private String templateName;
    private String username;
    private String password;

    public TelnetConfig(){
        templateType = 0;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "telnet_id")
    public Integer getTelnetId() {
        return telnetId;
    }

    public void setTelnetId(Integer telnetId) {
        this.telnetId = telnetId;
    }

    @Column(name = "telnet_authmode")
    public Integer getAuthMode() {
        return authMode;
    }

    public void setAuthMode(Integer authMode) {
        this.authMode = authMode;
    }

    @Column(name = "telnet_port")
    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    @Column(name = "telnet_timeout")
    public Integer getTimeout() {
        return timeout;
    }

    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    @Column(name = "telnet_retries")
    public Integer getRetries() {
        return retries;
    }

    public void setRetries(Integer retries) {
        this.retries = retries;
    }

    @Column(name = "template_type")
    public Integer getTemplateType() {
        return templateType;
    }

    public void setTemplateType(Integer templateType) {
        this.templateType = templateType;
    }

    @Column(name = "template_name")
    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    @Column(name = "telnet_username")
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Column(name = "telnet_password")
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
