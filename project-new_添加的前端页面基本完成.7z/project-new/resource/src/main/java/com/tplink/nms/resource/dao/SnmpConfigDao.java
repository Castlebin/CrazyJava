package com.tplink.nms.resource.dao;

import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import com.tplink.nms.resource.domain.SnmpConfig;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

/**
 * @author fdj
 */
@Repository("snmpConfigDao")
public class SnmpConfigDao extends BaseDao<SnmpConfig> {

    public Grid getSnmpTemplates(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(SnmpConfig.class, grid, filter);
    }
}
