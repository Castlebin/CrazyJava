package com.tplink.nms.resource.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by Simon Wei on 2015/4/13.
 */
@Controller
@RequestMapping("/resource")
public class IndexController {
    @RequestMapping("/index")
    public String getMenu(){
        return "resource/index";
    }

    @RequestMapping("/device-table")
    public String deviceTable(){
        return "resource/device-table";
    }

    @RequestMapping("/device-discovery")
    public String deviceDiscovery(){
        return "resource/device-discovery";
    }
}
