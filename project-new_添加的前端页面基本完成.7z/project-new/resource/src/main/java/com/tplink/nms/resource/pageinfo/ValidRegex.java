package com.tplink.nms.resource.pageinfo;

import java.util.regex.Pattern;

/**
 * @author fdj
 *
 */
public class ValidRegex {
	public static final String NULL_REGEX = "^$";
	
	public static final String IP_REGEX = "\\b((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\." + 
			"((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\." + 
			"((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\." +
			"((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\b";
	
	public static final String LEGAL_HOUR_GAP = "[1-9]|1[0-9]|2[0-3]";
	
	public static final String LEGAL_DAY_OF_WEEK = "[0-6]";
	
	public static final String LEGAL_DAY_OF_MONTH = "[1-9]|1[0-9]|2[0-8]";
	
	public static void main(String []args) {
//		String a = "12345678901234567890-=-=123456789";
//		System.err.println(Pattern.matches(NULL_REGEX +"|.{1,32}", a));
		String ip = "192.168.11.256";
		System.err.println(Pattern.matches(IP_REGEX, ip));
	}
}
