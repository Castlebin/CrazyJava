package com.tplink.nms.resource.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/**
 * @author fdj
 */
@Entity
@Table(name = "tbl_type_info")
public class TypeInfo {
    private Integer typeId;

    private String typeName;
    private String sysOID;
    private String typeDescription;
    private String vendor;

    private CategoryInfo categoryInfo;
    private IconInfo devIconInfo;
    private IconInfo topoIconInfo;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "type_id")
    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    @ManyToOne(
            targetEntity = com.tplink.nms.resource.domain.CategoryInfo.class,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id")
    @Cascade(value = {CascadeType.SAVE_UPDATE})
    public CategoryInfo getCategoryInfo() {
        return categoryInfo;
    }

    public void setCategoryInfo(CategoryInfo categoryInfo) {
        this.categoryInfo = categoryInfo;
    }

    @ManyToOne(
            targetEntity = com.tplink.nms.resource.domain.IconInfo.class,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "type_default_dev_icon_id")
    @Cascade(value = {CascadeType.SAVE_UPDATE})
    public IconInfo getDevIconInfo() {
        return devIconInfo;
    }

    public void setDevIconInfo(IconInfo devIconInfo) {
        this.devIconInfo = devIconInfo;
    }

    @ManyToOne(
            targetEntity = com.tplink.nms.resource.domain.IconInfo.class,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "type_default_topo_icon_id")
    @Cascade(value = {CascadeType.SAVE_UPDATE})
    public IconInfo getTopoIconInfo() {
        return topoIconInfo;
    }

    public void setTopoIconInfo(IconInfo topoIconInfo) {
        this.topoIconInfo = topoIconInfo;
    }

    @Column(name = "type_name")
    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    @Column(name = "sysoid")
    public String getSysOID() {
        return sysOID;
    }

    public void setSysOID(String sysOID) {
        this.sysOID = sysOID;
    }

    @Column(name = "type_description")
    public String getTypeDescription() {
        return typeDescription;
    }

    public void setTypeDescription(String typeDescription) {
        this.typeDescription = typeDescription;
    }

    @Column(name = "VENDOR")
    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }
}
