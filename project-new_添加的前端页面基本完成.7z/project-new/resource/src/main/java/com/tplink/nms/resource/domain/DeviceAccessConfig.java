package com.tplink.nms.resource.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


/**
 * @author fdj
 */
@Entity
@Table(name = "tbl_device_access_config", schema = "")
public class DeviceAccessConfig {
    private Integer devId;

    private Integer loginType;
    private Integer statusCheckPeriod;

    private DeviceInfo deviceInfo;
    private SnmpConfig snmpConfig;
    private TelnetConfig telnetConfig;

    @ManyToOne(
            targetEntity = com.tplink.nms.resource.domain.SnmpConfig.class,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "snmp_id")
    @Cascade(value = {CascadeType.SAVE_UPDATE, CascadeType.DELETE})
    public SnmpConfig getSnmpConfig() {
        return snmpConfig;
    }

    public void setSnmpConfig(SnmpConfig snmpConfig) {
        this.snmpConfig = snmpConfig;
    }

    @ManyToOne(
            targetEntity = com.tplink.nms.resource.domain.TelnetConfig.class,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "telnet_id")
    @Cascade(value = {CascadeType.SAVE_UPDATE, CascadeType.DELETE})
    public TelnetConfig getTelnetConfig() {
        return telnetConfig;
    }

    public void setTelnetConfig(TelnetConfig telnetConfig) {
        this.telnetConfig = telnetConfig;
    }


    @OneToOne(
            targetEntity = com.tplink.nms.resource.domain.DeviceInfo.class,
            fetch = FetchType.LAZY)
    @JoinColumn(name = "dev_id")
    public DeviceInfo getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(DeviceInfo deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    @Id
    @Column(name = "dev_id")
    @GenericGenerator(
            name = "pkGenerator",
            strategy = "foreign",
            parameters = {@Parameter(name = "property", value = "deviceInfo")})
    @GeneratedValue(generator = "pkGenerator")
    public Integer getDevId() {
        return devId;
    }

    public void setDevId(Integer devId) {
        this.devId = devId;
    }

    @Column(name = "login_type")
    public Integer getLoginType() {
        return loginType;
    }

    public void setLoginType(Integer loginType) {
        this.loginType = loginType;
    }

    @Column(name = "status_check_period")
    public Integer getStatusCheckPeriod() {
        return statusCheckPeriod;
    }

    public void setStatusCheckPeriod(Integer statusCheckPeriod) {
        this.statusCheckPeriod = statusCheckPeriod;
    }


}
