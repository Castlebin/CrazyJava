package com.tplink.nms.resource;

import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;

/**
 * Created by Simon Wei on 2015/4/13.
 */
public class ResourceModule extends AbstractModule{
    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
    }
}
