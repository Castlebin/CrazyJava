package com.tplink.nms.resource.dao;

import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.resource.domain.SnmpConfig;
import com.tplink.nms.resource.domain.TelnetConfig;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

/**
 * @author fdj
 */
@Repository("telnetConfigDao")
public class TelnetConfigDao extends BaseDao<TelnetConfig> {

    public Grid getTelnetTemplates(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(TelnetConfig.class, grid, filter);
    }
}
