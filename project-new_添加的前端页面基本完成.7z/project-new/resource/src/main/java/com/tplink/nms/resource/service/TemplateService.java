package com.tplink.nms.resource.service;

import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.GridQueryFilter;
import com.tplink.nms.mvc.bean.OperationResult;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.resource.dao.SnmpConfigDao;
import com.tplink.nms.resource.dao.TelnetConfigDao;
import com.tplink.nms.resource.domain.SnmpConfig;
import com.tplink.nms.resource.domain.TelnetConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * @author fdj
 */

@Component
public class TemplateService {
    @Autowired
    private SnmpConfigDao snmpConfigDao;

    @Autowired
    private TelnetConfigDao telnetConfigDao;


    public Grid<SnmpConfig> getSnmpTemplates(Grid<SnmpConfig> grid) {
        return snmpConfigDao.getSnmpTemplates(grid, grid.getQueryConditionList(new GridQueryFilter() {
            @Override
            public void filter(Map<String, Object> query, ArrayList<QueryCondition> queryConditions) {
                for(String filed : query.keySet()){
                    if(filed.equals("templateName")){
                        queryConditions.add(new QueryCondition("templateName", query.get("templateName"), QueryCondition.QueryType.like));
                    }
                }
            }
        }));
    }

    public void addSnmpTemplate(SnmpConfig snmpConfig){
        SnmpConfig config = new SnmpConfig();
        config.setTemplateName(snmpConfig.getTemplateName());
        List<SnmpConfig> configs = snmpConfigDao.find(config);

        if(configs.size() > 0){
            snmpConfig.setSnmpId(configs.get(0).getSnmpId());
        }
        snmpConfigDao.saveOrUpdate(snmpConfig);
    }

    public OperationResult deleteSnmpTemplates(Integer[] snmpIds){
        ArrayList<SnmpConfig> snmpConfigs = new ArrayList<>();
        for(Integer id : snmpIds){
            SnmpConfig config = new SnmpConfig();
            config.setSnmpId(id);
            snmpConfigs.add(config);
        }

        snmpConfigDao.deleteAll(snmpConfigs);
        return OperationResult.DEFAULT_SUCCESS;
    }

    public Grid<TelnetConfig> getTelnetTemplates(Grid<TelnetConfig> grid) {
        return telnetConfigDao.getTelnetTemplates(grid, grid.getQueryConditionList(new GridQueryFilter() {
            @Override
            public void filter(Map<String, Object> query, ArrayList<QueryCondition> queryConditions) {
                for (String filed : query.keySet()) {
                    if (filed.equals("templateName")) {
                        queryConditions.add(new QueryCondition("templateName", query.get("templateName"), QueryCondition.QueryType.like));
                    }
                }
            }
        }));
    }

    public OperationResult addTelnetTemplate(TelnetConfig telnetConfig){
        try {
            TelnetConfig config = new TelnetConfig();
            config.setTemplateName(telnetConfig.getTemplateName());
            List<TelnetConfig> configs = telnetConfigDao.find(config);

            if (configs.size() > 0) {
                telnetConfig.setTelnetId(configs.get(0).getTelnetId());
            }
            telnetConfigDao.saveOrUpdate(telnetConfig);
            return OperationResult.DEFAULT_SUCCESS;
        }catch (Exception e){
            return OperationResult.DEFAULT_FAIL;
        }
    }

    public OperationResult deleteTelnetTemplates(Integer[] telnetIds) {
        ArrayList<TelnetConfig> telnetConfigs = new ArrayList<>();
        for(Integer id : telnetIds){
            TelnetConfig config = new TelnetConfig();
            config.setTelnetId(id);
            telnetConfigs.add(config);
        }

        telnetConfigDao.deleteAll(telnetConfigs);
        return OperationResult.DEFAULT_SUCCESS;
    }
}
