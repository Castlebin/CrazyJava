package com.tplink.nms.resource.service;

import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.tplink.nms.resource.dao.DeviceDao;
import com.tplink.nms.resource.domain.DeviceInfo;
import org.apache.log4j.Logger;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author fdj
 * 
 */

@Component("deviceMgr")
public class DeviceMgr{

	@Autowired
	private DeviceDao deviceDao;


	DeviceInfo deviceInfo = null;

}
