package com.tplink.nms.resource.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


/**
 * @author fdj
 */
@Entity
@Table(name = "tbl_device_snmpinfo")
public class DeviceSnmpInfo {
    private Integer devId;

    private String devSysOID;
    private String devSysName;
    private String devVersion;
    private String devContact;
    private String devLocation;

    private Long devStartTime;

    private String devDescription;

    private DeviceInfo deviceInfo;
    private Set<DeviceInterface> interfaces;

    public DeviceSnmpInfo() {
        interfaces = new HashSet<>();
    }

    @OneToMany(
            targetEntity = com.tplink.nms.resource.domain.DeviceInterface.class,
            fetch = FetchType.LAZY,
            mappedBy = "snmpInfo")
    @Cascade(value = {CascadeType.SAVE_UPDATE, CascadeType.DELETE})
    public Set<DeviceInterface> getInterfaces() {
        return interfaces;
    }

    public void setInterfaces(Set<DeviceInterface> interfaces) {
        this.interfaces = interfaces;
    }

    @OneToOne(
            targetEntity = com.tplink.nms.resource.domain.DeviceInfo.class,
            fetch = FetchType.LAZY)
    @JoinColumn(name = "dev_id")
    public DeviceInfo getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(DeviceInfo deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    @Id
    @Column(name = "dev_id")
    @GenericGenerator(
            name = "pkGenerator",
            strategy = "foreign",
            parameters = {@Parameter(name = "property", value = "deviceInfo")})
    @GeneratedValue(generator = "pkGenerator")
    public Integer getDevId() {
        return devId;
    }

    public void setDevId(Integer devId) {
        this.devId = devId;
    }

    @Column(name = "dev_sysoid")
    public String getDevSysOID() {
        return devSysOID;
    }

    public void setDevSysOID(String devSysOID) {
        this.devSysOID = devSysOID;
    }

    @Column(name = "dev_sysname")
    public String getDevSysName() {
        return devSysName;
    }

    public void setDevSysName(String devSysName) {
        this.devSysName = devSysName;
    }

    @Column(name = "dev_version")
    public String getDevVersion() {
        return devVersion;
    }

    public void setDevVersion(String devVersion) {
        this.devVersion = devVersion;
    }

    @Column(name = "dev_contact")
    public String getDevContact() {
        return devContact;
    }

    public void setDevContact(String devContact) {
        this.devContact = devContact;
    }

    @Column(name = "dev_location")
    public String getDevLocation() {
        return devLocation;
    }

    public void setDevLocation(String devLocation) {
        this.devLocation = devLocation;
    }

    @Column(name = "dev_start_time")
    public Long getDevStartTime() {
        return devStartTime;
    }

    public void setDevStartTime(Long devStartTime) {
        this.devStartTime = devStartTime;
    }

    @Column(name = "dev_description")
    public String getDevDescription() {
        return devDescription;
    }

    public void setDevDescription(String devDescription) {
        this.devDescription = devDescription;
    }
}
