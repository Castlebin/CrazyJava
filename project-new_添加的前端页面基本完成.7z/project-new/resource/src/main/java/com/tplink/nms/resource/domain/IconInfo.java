package com.tplink.nms.resource.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author fdj
 *
 */
@Entity
@Table(name = "tbl_icon_info", schema = "")
public class IconInfo {
	private Integer 	iconId;
	private Integer 	iconType;
	
	private String 		iconName;
	private String 		iconFileName;

	@Id
	@Column(name = "icon_id")
	public Integer getIconId() {
		return iconId;
	}
	
	public void setIconId(Integer iconId) {
		this.iconId = iconId;
	}
	
	@Column(name = "icon_type")
	public Integer getIconType() {
		return iconType;
	}
	
	public void setIconType(Integer iconType) {
		this.iconType = iconType;
	}
	
	@Column(name = "icon_name")
	public String getIconName() {
		return iconName;
	}
	
	public void setIconName(String iconName) {
		this.iconName = iconName;
	}
	
	@Column(name = "icon_filename")
	public String getIconFileName() {
		return iconFileName;
	}
	
	public void setIconFileName(String iconFileName) {
		this.iconFileName = iconFileName;
	}	
}
