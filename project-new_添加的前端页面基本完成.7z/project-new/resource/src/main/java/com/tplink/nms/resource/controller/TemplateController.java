package com.tplink.nms.resource.controller;

import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import com.tplink.nms.resource.domain.SnmpConfig;
import com.tplink.nms.resource.domain.TelnetConfig;
import com.tplink.nms.resource.service.TemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * Created by Simon Wei on 2015/4/22.
 */
@Controller
@RequestMapping("/resource")
public class TemplateController {

    @Autowired
    TemplateService templateService;

    @RequestMapping("/snmp-template")
    public String snmpTemplate() {
        return "resource/snmp-template";
    }

    @ResponseBody
    @RequestMapping(value = "/snmp-template-table", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Grid<SnmpConfig> snmpTemplateTable(Grid<SnmpConfig> grid) {
        templateService.getSnmpTemplates(grid);
        return grid;
    }

    @ResponseBody
    @RequestMapping(value = "/snmp-template-add", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public OperationResult snmpTemplateAdd(SnmpConfig snmpConfig){
        templateService.addSnmpTemplate(snmpConfig);
        return OperationResult.DEFAULT_SUCCESS;
    }

    @ResponseBody
    @RequestMapping(value = "/snmp-template-delete", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public OperationResult snmpTemplateDelete(@RequestParam("snmpIds[]")Integer[] snmpIds){
        return templateService.deleteSnmpTemplates(snmpIds);
    }

    @RequestMapping("/telnet-template")
    public String telnetTemplate(){
        return "resource/telnet-template";
    }

    @ResponseBody
    @RequestMapping(value = "/telnet-template-table", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Grid<TelnetConfig> telnetTemplateTable(Grid<TelnetConfig> grid) {
        templateService.getTelnetTemplates(grid);
        return grid;
    }

    @ResponseBody
    @RequestMapping(value = "/telnet-template-add", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public OperationResult telnetTemplateAdd(TelnetConfig telnetConfig) {
        return templateService.addTelnetTemplate(telnetConfig);
    }

    @ResponseBody
    @RequestMapping(value = "/telnet-template-delete", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public OperationResult telnetTemplateDelete(@RequestParam("telnetIds[]")Integer[] telnetIds){
        return templateService.deleteTelnetTemplates(telnetIds);
    }
}
