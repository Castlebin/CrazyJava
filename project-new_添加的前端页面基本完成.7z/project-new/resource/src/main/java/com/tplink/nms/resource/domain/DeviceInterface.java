package com.tplink.nms.resource.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author fdj
 */
@Entity
@Table(name = "tbl_device_interfaces")
@IdClass(value = DeviceInterfaceUnionPK.class)
public class DeviceInterface {
    private Integer devId;
    private Integer ifIndex;

    private int ifType;
    private int ifSpeed;
    private int ifAdminStatus;
    private int ifOperationStatus;
    private int ifMtu;

    private String ifName;
    private String ifDescription;
    private String ifPhyAddress;
    private String ifAlias;
    private int ifLastChange;
    private int ifUsed;
    private int isPort;

    private DeviceSnmpInfo snmpInfo;

    public DeviceInterface() {

    }

    public DeviceInterface(Integer devId, Integer ifIndex) {
        this.devId = devId;
        this.ifIndex = ifIndex;
    }

    @Id
    //@Column(name = "dev_id")
    public Integer getDev_id() {
        return devId;
    }

    public void setDev_id(Integer devId) {
        this.devId = devId;
    }

    @Id
    //@Column(name = "dev_ifindex")
    public Integer getDev_ifindex() {
        return ifIndex;
    }

    public void setDev_ifindex(Integer ifIndex) {
        this.ifIndex = ifIndex;
    }

    @Column(name = "dev_iftype")
    public int getIfType() {
        return ifType;
    }

    public void setIfType(int ifType) {
        this.ifType = ifType;
    }

    @Column(name = "dev_ifspeed")
    public int getIfSpeed() {
        return ifSpeed;
    }

    public void setIfSpeed(int ifSpeed) {
        this.ifSpeed = ifSpeed;
    }

    @Column(name = "dev_ifadminstatus")
    public int getIfAdminStatus() {
        return ifAdminStatus;
    }

    public void setIfAdminStatus(int ifAdminStatus) {
        this.ifAdminStatus = ifAdminStatus;
    }

    @Column(name = "dev_ifopstatus")
    public int getIfOperationStatus() {
        return ifOperationStatus;
    }

    public void setIfOperationStatus(int ifOperationStatus) {
        this.ifOperationStatus = ifOperationStatus;
    }

    @Column(name = "dev_ifmtu")
    public int getIfMtu() {
        return ifMtu;
    }

    public void setIfMtu(int ifMtu) {
        this.ifMtu = ifMtu;
    }

    @Column(name = "dev_ifname")
    public String getIfName() {
        return ifName;
    }

    public void setIfName(String ifName) {
        this.ifName = ifName;
    }

    @Column(name = "dev_ifdesc")
    public String getIfDescription() {
        return ifDescription;
    }

    public void setIfDescription(String ifDescription) {
        this.ifDescription = ifDescription;
    }

    @Column(name = "dev_ifphyaddress")
    public String getIfPhyAddress() {
        return ifPhyAddress;
    }

    public void setIfPhyAddress(String ifPhyAddress) {
        this.ifPhyAddress = ifPhyAddress;
    }

    @Column(name = "dev_ifalias")
    public String getIfAlias() {
        return ifAlias;
    }

    public void setIfAlias(String ifAlias) {
        this.ifAlias = ifAlias;
    }

    @Column(name = "dev_iflastchange")
    public int getIfLastChange() {
        return ifLastChange;
    }

    public void setIfLastChange(int ifLastChange) {
        this.ifLastChange = ifLastChange;
    }

    @Column(name = "dev_ifused")
    public int getIfUsed() {
        return ifUsed;
    }

    public void setIfUsed(int ifUsed) {
        this.ifUsed = ifUsed;
    }

    @Column(name = "dev_ifisport")
    public int getIsPort() {
        return isPort;
    }

    public void setIsPort(int isPort) {
        this.isPort = isPort;
    }

    @ManyToOne(targetEntity = com.tplink.nms.resource.domain.DeviceSnmpInfo.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "dev_id", insertable = false, updatable = false)
    public DeviceSnmpInfo getSnmpInfo() {
        return snmpInfo;
    }

    public void setSnmpInfo(DeviceSnmpInfo snmpInfo) {
        this.snmpInfo = snmpInfo;
    }

    @Override
    public String toString() {
        return "DeviceInterface [devId=" + devId + ", ifIndex=" + ifIndex
                + ", ifType=" + ifType + ", ifSpeed=" + ifSpeed
                + ", ifAdminStatus=" + ifAdminStatus + ", ifOperationStatus="
                + ifOperationStatus + ", ifMtu=" + ifMtu + ", ifName=" + ifName
                + ", ifDescription=" + ifDescription + ", ifPhyAddress="
                + ifPhyAddress + ", ifAlias=" + ifAlias + ", ifLastChange="
                + ifLastChange + ", ifUsed=" + ifUsed + ", isPort=" + isPort
                + ", snmpInfo=" + snmpInfo + "]";
    }

}
