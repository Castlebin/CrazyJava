package com.tplink.nms.resource.domain;

import java.io.Serializable;

/**
 * @author fdj
 */
public class DeviceInterfaceUnionPK implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer devId;
    private Integer ifIndex;

    public DeviceInterfaceUnionPK() {

    }

    public DeviceInterfaceUnionPK(Integer devId, Integer ifIndex) {
        this.devId = devId;
        this.ifIndex = ifIndex;
    }

    public Integer getDev_id() {
        return devId;
    }

    public void setDev_id(Integer id) {
        this.devId = id;
    }

    public Integer getDev_ifindex() {
        return ifIndex;
    }

    public void setDev_ifindex(Integer ifIndex) {
        this.ifIndex = ifIndex;
    }

    @Override
    public boolean equals(Object object) {
        if (object instanceof DeviceInterfaceUnionPK) {
            DeviceInterfaceUnionPK key = (DeviceInterfaceUnionPK) object;
            if (this.devId.equals(key.devId) && this.ifIndex.equals(key.ifIndex)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
