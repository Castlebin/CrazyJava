package com.tplink.nms.resource.domain;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import javax.persistence.*;

/**
 * @author fdj
 */

@Entity
@Table(name = "tbl_device_info", schema = "")
public class DeviceInfo {
    private Integer devId;

    private String devName;
    private String devIp;
    private String devMask;
    private String devMac;
    private int devStatus;

    private Long devDiscoveryTime;
    private Long devSynchorTime;

    private TypeInfo devTypeInfo;
    private CategoryInfo devCategoryInfo;
    private DeviceAccessConfig deviceAccessConfig;
    private DeviceSnmpInfo deviceSnmpInfo;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dev_id")
    public Integer getDevId() {
        return devId;
    }

    public void setDevId(Integer devId) {
        this.devId = devId;
    }

    @Column(name = "dev_name")
    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

    @Column(name = "dev_ip")
    public String getDevIp() {
        return devIp;
    }

    public void setDevIp(String devIp) {
        this.devIp = devIp;
    }

    @Column(name = "dev_mask")
    public String getDevMask() {
        return devMask;
    }

    public void setDevMask(String devMask) {
        this.devMask = devMask;
    }

    @Column(name = "dev_mac")
    public String getDevMac() {
        return devMac;
    }

    public void setDevMac(String devMac) {
        this.devMac = devMac;
    }

    @Column(name = "dev_status")
    public int getDevStatus() {
        return devStatus;
    }

    public void setDevStatus(int devStatus) {
        this.devStatus = devStatus;
    }

    @Column(name = "dev_discovery_time")
    public Long getDevDiscoveryTime() {
        return devDiscoveryTime;
    }

    public void setDevDiscoveryTime(Long devDiscoveryTime) {
        this.devDiscoveryTime = devDiscoveryTime;
    }


    @Column(name = "dev_synchor_time")
    public Long getDevSynchorTime() {
        return devSynchorTime;
    }

    public void setDevSynchorTime(Long devSynchorTime) {
        this.devSynchorTime = devSynchorTime;
    }

    @ManyToOne(
            targetEntity = com.tplink.nms.resource.domain.TypeInfo.class,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "dev_type_id")
    public TypeInfo getDevTypeInfo() {
        return devTypeInfo;
    }

    public void setDevTypeInfo(TypeInfo devTypeInfo) {
        this.devTypeInfo = devTypeInfo;
    }

    @ManyToOne(
            targetEntity = com.tplink.nms.resource.domain.CategoryInfo.class,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "dev_category_id")
    public CategoryInfo getDevCategoryInfo() {
        return devCategoryInfo;
    }

    public void setDevCategoryInfo(CategoryInfo devCategoryInfo) {
        this.devCategoryInfo = devCategoryInfo;
    }

    @OneToOne(
            targetEntity = com.tplink.nms.resource.domain.DeviceAccessConfig.class,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "dev_id")
    @Cascade(value = {CascadeType.SAVE_UPDATE, CascadeType.DELETE})
    @PrimaryKeyJoinColumn
    public DeviceAccessConfig getDeviceAccessConfig() {
        return deviceAccessConfig;
    }

    public void setDeviceAccessConfig(DeviceAccessConfig deviceAccessConfig) {
        this.deviceAccessConfig = deviceAccessConfig;
    }

    @OneToOne(
            targetEntity = com.tplink.nms.resource.domain.DeviceSnmpInfo.class,
            fetch = FetchType.EAGER)
    @JoinColumn(name = "dev_id")
    @Cascade(value = {CascadeType.SAVE_UPDATE, CascadeType.DELETE})
    @PrimaryKeyJoinColumn
    public DeviceSnmpInfo getDeviceSnmpInfo() {
        return deviceSnmpInfo;
    }

    public void setDeviceSnmpInfo(DeviceSnmpInfo deviceSnmpInfo) {
        this.deviceSnmpInfo = deviceSnmpInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DeviceInfo that = (DeviceInfo) o;

        if (devId != null ? !devId.equals(that.devId) : that.devId != null) return false;
        if (devIp != null ? !devIp.equals(that.devIp) : that.devIp != null) return false;
        if (devMac != null ? !devMac.equals(that.devMac) : that.devMac != null) return false;
        if (devMask != null ? !devMask.equals(that.devMask) : that.devMask != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = devId != null ? devId.hashCode() : 0;
        result = 31 * result + (devIp != null ? devIp.hashCode() : 0);
        result = 31 * result + (devMask != null ? devMask.hashCode() : 0);
        result = 31 * result + (devMac != null ? devMac.hashCode() : 0);
        return result;
    }
}