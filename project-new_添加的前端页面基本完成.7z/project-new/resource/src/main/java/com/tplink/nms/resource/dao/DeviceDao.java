package com.tplink.nms.resource.dao;

import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import com.tplink.nms.resource.domain.DeviceInfo;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 * @author fdj
 */

@Repository("deviceDao")
public class DeviceDao extends BaseDao<DeviceInfo> {

    private int deviceNum;

    public int getDeviceNum() {
        return deviceNum;
    }

    public void setDeviceNum(int deviceNum) {
        this.deviceNum = deviceNum;
    }

    public List<DeviceInfo> getAllDevices() {
        String hql = "from DeviceInfo info";
        List<DeviceInfo> devices = (List<DeviceInfo>) getTemplate().find(hql);

        if (devices == null || devices.isEmpty()) {
            return null;
        } else {
            return devices;
        }
    }

    public List<DeviceInfo> getDevicesByCategoryId(Integer categoryId) {
        String hql = "from DeviceInfo device where device.categoryId = ?";
        List<DeviceInfo> devices = (List<DeviceInfo>) getTemplate().find(hql, categoryId);

        if (devices == null || devices.isEmpty()) {
            return null;
        } else {
            return devices;
        }
    }

    public void updateDevices(List<DeviceInfo> deviceList) {
        getTemplate().saveOrUpdate(deviceList);
    }

    public DeviceInfo getDeviceByIp(String ip) {
        String hql = "from DeviceInfo info where info.devIp = ?";
        List<DeviceInfo> list = (List<DeviceInfo>) getTemplate().find(hql, ip);

        if (list == null || list.isEmpty() || list.size() > 1) {
            return null;
        }

        return list.get(0);
    }

    public DeviceInfo getDeviceByMac(String mac) {
        if (mac == null) {
            return null;
        }

        String hql = "from DeviceInfo info where info.devMac = ?";

        List<DeviceInfo> list = (List<DeviceInfo>) getTemplate().find(hql, mac);

        if (list == null || list.isEmpty() || list.size() != 1) {
            return null;
        }

        return list.get(0);
    }

    public List<DeviceInfo> getDevicesByName(String name) {
        String hql = "from DeviceInfo info where info.devName = ?";
        List<DeviceInfo> list = (List<DeviceInfo>) getTemplate().find(hql);

        if (list == null || list.isEmpty()) {
            return null;
        }

        return list;
    }


    public List<DeviceInfo> getDevicesByType(Integer typeId) {
        // TODO Auto-generated method stub
        if (typeId < 0) {
            return null;
        }

        String hql = "from DeviceInfo device where device.devTypeInfo.typeId = ?";

        List<DeviceInfo> devList = (List<DeviceInfo>) getTemplate().find(hql, typeId);

        if (devList == null || devList.isEmpty()) {
            return null;
        }

        return devList;
    }
}
