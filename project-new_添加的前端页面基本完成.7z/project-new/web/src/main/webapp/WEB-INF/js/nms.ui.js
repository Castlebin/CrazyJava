;(function(window, undefined){
window.nms = function(selector, context){
		return $(selector, context);
	};
var nms = window.nms;
$.extend(nms, {
	version : "0.0.1",
	debug : true,
	keyCode : {
		BACKSPACE: 8,
	    TAB: 9,
	    ENTER: 13,
	    ESCAPE: 27,
	    SPACE: 32,
		LEFT: 37,
		UP: 38,
		RIGHT: 39,
		DOWN: 40
	},
	lang : {
		_cur : "en",
		get : function(attr){
			return nms.lang[this._cur][attr];
		},
		set : function(lang, object){
			if(typeof lang === "string"){
				if(object == undefined){
					this._cur = lang.length > 0 ? lang : "en";
				}else{
					this[lang] = this[lang] || {};
					$.extend(true, this[lang], object);
				}
			}else{//setting several kinds of languages via one object looks like {'en':{},'zh':{}}
				$.each(lang, function(attr){
					nms.lang.set(attr, lang[attr]);
				});
			}
		}
	},
	factory : {},
	create : function(name, options, element){
		this.factory[name].call(options, element);
	},
	extend : function(object){
		$.extend(true, nms, object);
	}
});

nms.widget = function(name, base){
	nms.factory[name] = function(options, element){
		if(arguments.length){
			this._createWidget(options, element);
		}
	}

	var basePrototype = new nms.widgetBase();
	basePrototype.options = $.extend( true, {}, basePrototype.options );
	
	this.factory[name].prototype = $.extend(true, basePrototype, {
		widgetName: name,
		widgetBaseClass : "nms-"+name
	}, base);
	
	$.fn[name] = function(options){
		var isMethodCall = typeof options === "string",
			args = Array.prototype.slice.call( arguments, 1 ),
			returnValue = this;
			
		options = !isMethodCall && args.length ?
			$.extend.apply( null, [ true, options ].concat(args) ) :
			options;

		if ( isMethodCall && options.charAt( 0 ) === "_" ) {
			return returnValue;
		}
		
		if ( isMethodCall ) {
			this.each(function() {
				var instance = $.data( this, name ),
					methodValue = instance && $.isFunction( instance[options] ) ?
						instance[ options ].apply( instance, args ) :
						instance;

				if ( methodValue !== instance && methodValue !== undefined ) {
					returnValue = methodValue;
					return false;
				}
			});
		} else {
			this.each(function() {
				var instance = $.data( this, name );
				if ( instance ) {
					instance.option( options || {} )._init();
				} else {
					instance = new nms.factory[name]( options, this );
					$.data( this, name, instance );
				}
			});
		}

		return returnValue;
	}
}

nms.widgetBase = function(options, element){
	if ( arguments.length ) {
		this._createWidget(options, element);
	}
}
nms.widgetBase.prototype = {
	widgetName: "widget",
	options : {
		disabled : false
	},
	_createWidget : function(options, element){
		$.data( element, this.widgetName, this );
		this.element = $( element );
		
		this.options =  $.extend( true, {},
			this.options,
			options );

		this._create();
		this._init();
	},
	widget : function(){
		return this.element;
	},
	option : function(key, value){
		var options = {};
		if  (typeof key === "string" ) {
			if ( value === undefined ) {
				return this.options[ key ];
			}
			options[ key ] = value;
		}else if(typeof key === "object"){
			options = key;
		}
		
		$.extend( true, this.options, options );
		
		return this;
	},
	_create : function(){},
	_init : function(){},
	destroy: function() {
	}
}

$.extend($.fn, {
    getFirstAbsoluteElement: function(){
        var e = this.parents(),
            element = false;
        e.each(function(i, o){
            var position = o.currentStyle?o.currentStyle['position']:document.defaultView.getComputedStyle(o, false)['position'];
            if(position == 'absolute' || position == 'fixed' || position == 'relative'){
                element = $(o);
                return false;
            }
        })
        return element;
    }
})
})(window);;(function(window, undefined){
window.$id = window.$id || function(id){return document.getElementById(id);};
$.extend(String.prototype, {
	format: function(){
        var args = arguments;
        return this.replace(/\{(\d+)\}/g,
            function(m, i){
                return args[i];
            });
		},
    trim: String.prototype.trim || function(){
        return this.replace(/(^\s*)|(\s*$)/g,"");
    },
	isIp: function(type){
        this.trim();
        var szarray = /^([01]?\d{1,2}|2[0-4]\d|25[0-5])\.([01]?\d{1,2}|2[0-4]\d|25[0-5])\.([01]?\d{1,2}|2[0-4]\d|25[0-5])\.([01]?\d{1,2}|2[0-4]\d|25[0-5])$/.exec(this);
        if(szarray == null)return false;
        if(type == undefined)return true;

        if("ip" == type){ // server ip
            //D,E class IP, Loop IP, end with 0
            if((szarray[1] > 223) || (szarray[1] == 127))
                return false;
            if(0 == szarray[4])
                return false;
            return true;
        }
        else if("gateway" == type){ //gateway
            if(0 == szarray[1])
                return (0 == szarray[2] && 0 == szarray[3] && 0 == szarray[4]);

            if((szarray[1] > 223) || (szarray[1] == 127))
                return false;
            return true;
        }else if("mask" == type){
            var ipStr = "";
            for(var i = 1; i<=4 ; i++){
                ipStr += parseInt(szarray[i]).toString(2);
            }
            return /^1*0*$/.test(ipStr);
        }

        return false;
	},
	
	isNumber: function(min, max){
		var numRegExp = /^\d{1,10}$/,
            result = true,
            number = 0;
	
		if(!numRegExp.test(this))
			return false;

        number = parseInt(this, 10);
		if(typeof min != 'undefined' && number < min){
            result = false;
        }
        if (typeof max != 'undefined' && number > max){
            result = false;
        }
        return result;
    },
    isEmail: function(){
        return /^[a-zA-Z0-9_+.-]+\@([a-zA-Z0-9-]+\.)+[a-zA-Z0-9]{2,4}$/.test(this);
    }
});

nms.extend({
post: function(url, callback, data, dataType, requestMethod){
    var dType = dataType || 'json';
    var param = {url:url, dataType:dType};
    if(data)param.data = data;
    if(dType == "json")param.type = 'POST';
	if(requestMethod)param.type = requestMethod;

    param.success = function(data){
        if(dataType == "json" && typeof data != "object"){
            throw new Error("Ajax data type ERROR.");
        }
        callback(data);
    }
    param.error = function(){
		if(!nms.debug)
			location.reload(true);
    }

    $.ajaxSetup ({cache: false});
    $.ajax(param);
},
contentFill: function(url){
    if(!url || url == "#"){
        return;
    }
    nms.container = nms.container || $("#content");

    nms.post(url, function(data){
        nms.container.html(data);
    }, '', 'html');
},
getCookie: function(Name) { 
    var search = Name + "=" 
    if(document.cookie.length > 0){
        offset = document.cookie.indexOf(search) 
        if(offset != -1) { 
            offset += search.length 
            end = document.cookie.indexOf(";", offset) 
            if(end == -1) end = document.cookie.length 
            return unescape(document.cookie.substring(offset, end)) 
        } 
    } 
	return "" ;
},
setCookie: function (c_name,value,expiredays){
	var exdate=new Date()
	exdate.setDate(exdate.getDate()+expiredays)
	document.cookie=c_name+ "=" +escape(value)+((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
},
$document : $(document),
$window : $(window),
alert : function (msg, time, callBack) {
    var callee = arguments.callee;

    clearTimeout(callee.timeout);
    callee.$w = callee.$w || $('<div class="nms-alert-wrapper"></div>').appendTo($('body'));
    callee.$w.hide().empty().removeClass("nms-alert-confirm nms-alert-success nms-alert-failed").html('<span class="nms-alert-msg">' + msg + '</span>').fadeIn();
    if (callBack) {
        callBack();
    }
    callee.timeout = setTimeout(function () {
        nms.alert.$w.fadeOut(1500);
    }, time || 1000000);
},
success : function (msg, time) {
    this.alert(msg || "OK", time);
    this.alert.$w.addClass("nms-alert-success");
},
failed : function (msg, time) {
    this.alert(msg || "Failed", time || 2000);
    this.alert.$w.addClass("nms-alert-failed").append('<div class="icon icon-close nms-alert-close">').find('.icon-close').click(function () {
        clearTimeout(nms.alert.timeout);
        nms.alert.$w.fadeOut();
    });
},
msg : function (isSuccess, msgContent, time) {
    if (isSuccess) {
        this.success(msgContent, time);
    } else {
        this.failed(msgContent, time);
    }
}
});

nms.Listener = function(callback){
    this.setCallback(callback);
}
nms.Listener.prototype = {
    data: false,
    callback: false,
    setCallback: function(callback){
        this.callback = callback;
    },
    set: function(value){
        var me = this;

        me.data = value;
        if(me.callback){
            me.callback(me.data);
        }
    },
    get: function(){
	    var me = this;
        return me.data;
    }
}

nms.lang.set(nms.getCookie("language"));

$(document).keydown(function(e){
    if (e.keyCode === nms.keyCode.ESCAPE){
        $('.nms-dialog-body').dialog('close');
    }
});
})(window);;(function(){
nms.widget("menu", {
	options : {
		source : [],
        click: null
	},
	_create : function(){
		var me = this,
			o = me.options;

		if(typeof o.source == "string"){
            nms.post(o.source, function(data){
				me.data = data;
                me._buildMenu();
			});
		}else{
			me.data = o.source;
            me._buildMenu();
		}
	},
	
	_buildMenu : function(){
		var me = this,
			e = me.element,
			data = me.data;
		
		var html = '<ul class="menu">';
		
		for(var i in data){
            var menu = data[i];
			html += '<li class="menu-item" ';
			if(menu.src)
				html += ' src="'+menu.src+'" ';

            html += '><div class="icon menu-icon '+ menu.class+'"></div>';
			html += '<span>'+menu.name+'</span>';
            html += '<div class="icon icon-menu-arrow"></div>';
			html += '</li>';
		}
		html += "</ul>";
		e.html(html);

        e.children("ul").children("li").click(function(){
            var $li = $(this);
            $("body").css("background","white");
            e.find("li").removeClass("menu-li-selected");
            $li.addClass("menu-li-selected");
            me.getContent($li.attr("src"));
        }).mouseenter(function(){
			$(this).addClass("menu-li-hover");
		}).mouseleave(function(){
            $(this).removeClass("menu-li-hover");
        });

	},

    getContent: function(src){
        $content = nms("#content").empty();
        nms.post(src, function(data){
            $content.html(data);
        },{},"html");
    },

    select:function(menu){
        var e = this.element;
        e.find("li").each(function(i, o){
            $li = $(this);
            if(typeof menu === "string"){
                if($li.find("span").html() == menu){
                    $li.trigger("click");
                }
            }else{
                if(i === menu)
                    $li.trigger("click");
            }
        });
    }
});
})();;(function(){
nms.widget("leftMenu", {
    options: {
        source:[]
    },
    _create: function(){
        var me = this;

        me.element.addClass("left-menu");
        var source = me.options.source;
        if(typeof source == "string"){
            nms.post(source, function(data){
               me.data = data;
               me._buildTopMenu();
            });
        }else{
            me.data = source;
            me._buildTopMenu();
        }
    },

    _init: function(){
        var me = this;

        $("body").css("background", "url('../images/body-bg.png') repeat-y");

        me.element.find(".sub-menu").click(function(event){
            var menu = $(this);
            var a = menu.children("a");
            var index = a.attr("index").split(',');
            var click = me.options.source[index[0]].subMenu[index[1]].click;

            me.element.find(".sub-menu").removeClass("left-menu-selected");
            menu.addClass("left-menu-selected");
            click = click || me.options.click || me._subMenuClick;
            click(a.attr("url"));
        }).mouseenter(function(){
            $(this).addClass("left-menu-hover");
        }).mouseleave(function(){
            $(this).removeClass("left-menu-hover");
        });

        //nms.leftMenu = me;
    },

    _subMenuClick: function(url, param){
        nms.post(url, function(data){
            nms("#main-content").empty().html(data);
        },{},"html");
    },

    set: function(name, param, type){
        var me = this,
            url = name,
            source = me.options.source;

        var menu = name.split(".");
        if(menu.length<2 || type == 'url'){
            me._subMenuClick(url, param);
            return;
        }

        for(var index in source){
            if(source[index].name == menu[0]){
                var subMenu = source[index].subMenu;
                for(var i in subMenu){
                    if(subMenu[i].name == menu[1]){
                        me._subMenuClick(subMenu[i].url, param);
                    }
                }
            }
        }
    },

    _buildTopMenu: function(){
        var me = this,
            data = me.data;

        var html = "";
        for(var index in data){
            html += '<div class="top-menu">'
                 + '<div class="left-menu-name-top pointer"><div class="left-menu-name-bg"></div><span>' + data[index].display +'</span></div>'

            for(var i in data[index].subMenu){
                var subMenu = data[index].subMenu[i];
                html += '<div class="sub-menu pointer"><a url="'
                    + subMenu.url + '" index="'
                    + index+',' + i + '">'
                    + subMenu.display + '</a><div class="icon left-menu-icon"></div></div>'
            }

            html += '</div>';
        }

        me.element.append(html);
    },

    select: function(target){
        var me = this;
        var index = 0;

        if ($.isArray(target)){//like [0,1]
            for (var i= 0; i <= target[0]-1; i++){
                index += this.options.source[i].subMenu.length;
            }
            index += target[1];
        }
        me.element.find(".sub-menu").each(function(i, o){
            $sub = $(this);
            if(typeof target === "string"){
                if($sub.find("a").html() == target){
                    $sub.trigger("click");
                }
            }else{
                if($.isArray(target) && i == index)
                    $sub.trigger("click");
            }
        });
    }
});
})();;(function () {
	nms.widget("button", {
		options: {
			height:"12px",
            name: "",
			onPress: false,
			toggle: false,
            onToggle: false,
            disabled: false,
			isPressed: false,
			type: false
		},
		_create: function () {
			var me = this;

            me.element.addClass("nms-button unselectable");
            me.element.append('<span></span><span class="nms-button-text inline">'+ me.options.name +'</span>');
			me._setBtnClass();
		},
		_init: function () {
			var me = this,
                e = me.element,
				o = me.options;

            me.element.click(function(event){
                if(o.disabled)return;
                if(o.onPress){
                    o.onPress.call(e, event);
                }
                if(o.toggle){
                    if(1 != event.which)return;
                    o.isPressed = !o.isPressed;
                    o.isPressed
                        ? e.addClass("nms-button-down")
                        : e.removeClass("nms-button-down");
                    if(o.onToggle){
                        o.onToggle(e, o.isPressed);
                    }
                }
            }).mouseenter(function(){
                if(!o.disabled){
                    e.addClass("nms-button-hover");
                }
            }).mouseleave(function(){
                    e.removeClass("nms-button-hover");
            });

		},
		_setBtnClass: function(){
			var me = this,
				e = me.element,
				o = me.options;

			if(o.disabled) e.addClass("nms-button-disabled");
            if(o.type){
                e.children("span:first").addClass("icon icon-"+ o.type);
            }

            if(o.toggle && o.isPressed)e.addClass("nms-button-down");
            if(o.name === '')e.addClass("nms-button-icon-only");

		},
		enable:function(){
            var me = this;

            if(me.options.disabled){
                me.options.disabled = false;
                me.element.removeClass("nms-button-disabled");
            }
		},
		disable: function(){
            var me = this;

            if(!me.options.disabled){
                me.options.disabled = true;
                me.element.addClass("nms-button-disabled");
            }
		},
		isDisabled: function(){
            return this.options.disabled;
        },
        isPressed: function(){
            return this.options.isPressed;
        }
	});
})();/**
 * Created by simon on 14-8-21.
 */

/**
 * $("XXX").tooltip({
 *      title       : content to show
 *      position    : [left, right, up, down]
 *      type        : [tip, alert]
 *      show        : show tool tip immediately
 *      color       : border color
 *      container   : tooltip dom wrapper
 * });
 */
;nms.widget("tooltip", {
    options: {
        position    : "bottom",
        bdcolor     : "#1F1F1F",
        bgColor     : "#1F1F1F",
        color       : "#FFFFFF",
        type        : "tip",
        title       : "",
        show        : false,
        container   : false,
        delay       : false,
	    offset      : {left: null, top: null}
    },
    _create : function(){
        var s = this,
            o = s.options,
            e = s.element,
            html = '';

        e.removeAttr('title');
        s._title = o.title;
        s._disabled = false;
        if(o.type == "alert"){
            o.bgColor = "#FFFFFF";
            o.bdcolor = "#e9424e";
            o.color = "#707070";
        }

        s.id = Math.random().toString().substr(2);
        html = '<div id="tip' + s.id + '" class="nms-tooltip '  + o.position
                    + '" style="background-color:'+ o.bgColor
                    + ';border:solid 1px '+ o.bdcolor+';color:'+ o.color+'">';

        html += '<div class="nms-tooltip-content"></div>';
        html += '<div class="nms-tooltip-pointer-outer" style="border-'+ o.position+'-color:'+ o.bdcolor+'"></div>';
        html += '<div class="nms-tooltip-pointer" style="border-'+ o.position+'-color:'+ o.bgColor+'"></div>';

        html += '</div>';

        s.html = html;

        e.bind('mouseover', function(){if(!s._disabled)s.show()})
            .bind('mouseleave', function(){if(!s._disabled)s.hide()});
    },

    _init : function(){
        if(this.options.show){
            this.show();
        }
    },

    _wrapTitle: function(title){
        var text = '',
            n = 200,/* max letters in one line */
            textArray = title.split(' '),
            temp='';

        if(title.length>n){
            for (var i = 0, l = textArray.length; i < l; i++) {
                temp += textArray[i]+' ';
                if(temp.length>n){
                    text += temp+'<br/>';
                    temp = '';
                }
            }
            if(temp.length==0){text = text.slice(0,text.length-5);}
            else{text += temp;}
        }else{
            text = title;
        }
        return text;
    },

    _getPosition: function(){
        var e = this.element,
            p = this.options.position,
            w = e.outerWidth(),
            h = e.outerHeight(),
            t = e.offset().top,
            l = e.offset().left,
            tw = this._getToolTip().outerWidth(),
            th = this._getToolTip().outerHeight(),
            margin = 15;

        var pos;

        if(p == "right"){
            pos = {top : t + h/2 - th/2, left: l + w + margin};
        }else if(p == "bottom"){
            pos = {top : t + h + margin, left : l + w/2 - tw/2};
        }else if(p == "top"){
            pos = {top : t - th - margin, left: l + w/2 -tw/2};
        }else{
            pos = {top : t + h/2 - th/2, left : l - tw  - margin};
        }

        var absElem = e.getFirstAbsoluteElement();

        if(absElem){
            pos.left -= absElem.offset().left;
            pos.top -= absElem.offset().top;

        }

	    return {
		    left : this.options.offset.left || pos.left,
		    top:  this.options.offset.top || pos.top
	    };
    },

    _getToolTip: function(){
        return this._getContainer().find('#tip' + this.id);
    },

    _getContainer: function(){
        var o = this.options;
        return (o.container) ? ((typeof o.container == "string") ? $(o.container) : o.container) : this.element.parent();
    },

    hide: function(){
        this._getToolTip().remove();
    },

    show: function(delay){
        var s = this;

        s._getContainer().append(s.html);
        s._getToolTip().find('.nms-tooltip-content').text(s._title);
        s._getToolTip().show().css(s._getPosition());

        delay = delay || this.options.delay;
        if(delay){
            setTimeout(function(){s.hide(0)}, delay);
        }
    },

    update: function(newTitle){
        this._title = newTitle || this.options.title;
        this._disabled = false;
    },

    disable: function(){
        this._disabled = true;
        this.hide();
    }
});;(function () {
	nms.widget("combobox", {
		options: {
			height: false,
			width : false,
			maxOptions : 6,
            focusOption: 0,
			/*sortable: true,*/
            disabled: false,
			autoComplete: true,
            onChanged: false,
			opts : []
		},

		_create: function () {
			var s = this,
				e = this.element,
				o = this.options;


			e.addClass("nms-combobox inline");
            s.disabled = o.disabled;
			s.$header = $("<div></div>").addClass("nms-combo-header");
			s.$input = $('<input class="nms-combo-input inline" autocomplete="off' +
                '"/>').appendTo(s.$header);
			s.$arrow = $('<span class="icon icon-arrow-bottom"></span>').appendTo(s.$header);
			s.$opts = $('<div class="opt-block"></div>');

			e.append(s.$header).append(s.$opts);

            o.height = parseInt(o.height, 10) || e.height();
            o.width  = parseInt(o.width, 10) || e.width();
            s.$input.css({width: o.width- 25, height: o.height - 2});
            if (o.maxOptions < o.opts.length){
                s.$opts.css("height", o.maxOptions * o.height+"px");
            }
            s.$opts.css({width: o.width + 8, "line-height": o.height + "px"});
		},
		_init: function () {
			var s = this,
				e = this.element,
				o = this.options,
				html = "";

			s.optItems = [];
			s.readOnly = ( (typeof o.opts[0]) === "object" );/* used as select */
			s.$input.prop("readOnly", s.readOnly);

			for(var x in o.opts){
				html += s._option2HTML(o.opts[x]);
			}

			//common
			s.focusedOpt = false;


			s.$opts.hide().append(html).find(".opt").css("height", o.height)
			.each(function(i, el){
					s._bindOptEvent($(el));
					s.optItems.push($(el));
			});

			//readOnly mode
			if(s.readOnly){

				s.$header.click(function(){
                    if (s.disabled){
                        return;
                    }
                    if (s.$opts.is(':visible')){
                        s._displayOpts(false);
                    }
                    else{
                        s._displayOpts(true);
                    }
				});

				e.mouseleave(function(){
					s._displayOpts(false);
				});

			//writable mode
			}else{

				s.$arrow.click(function(){
                    if (s.disabled){
                        return;
                    }
					s._displayOpts(true, true);
				});

				e.mouseleave(function(){
					s._displayOpts(false);
				});

				s.$input.click(function(){
                    if (s.disabled){
                        return;
                    }
					s._displayOpts(true, true);
				})
				.keyup(function(){
                    if (s.disabled){
                        return;
                    }
					//auto-complete
					if(o.autoComplete){
						s.$opts.find(".opt").detach();
						var value = s.$input.val();

						for( var i in s.optItems){
							var item = s.optItems[i].get(0).innerHTML;

							if(value === item.slice(0, value.length)){
								s.$opts.append(s.optItems[i]);
							}
						}
					}

					s._displayOpts(true);
				});
			}

		},
		_option2HTML: function(opt){
			var html;

			if(!this.readOnly){
				html = '<div class="opt">'+opt+'</div>';
			}else{
				html = '<div class="opt" val="'+opt.value+'">'+opt.display+'</div>';
			}

			return html;
		},

		_displayOpts: function(show, reload){
			var s = this;
	        if(show){
			        s.$opts.show();//.focus();
		        if(reload){
			        s.$opts.find(".opt").detach();
			        for(var i in s.optItems){
				        s.optItems[i].appendTo(s.$opts);
			        }
		        }
	        }else{
		        s.$opts.hide();
	        }
        },

		_focusOpts: function(opt){
			var s = this;
			if(typeof s.focusedOpt === "object"){
				s.focusedOpt.removeClass("opt-focused");
			}
			s.focusedOpt = opt.addClass("opt-focused");
		},

		_bindOptEvent: function(opt){
			var s = this,
                o = s.options;
			opt.click(function(){
				s.$input.val(this.innerHTML);

				if(s.readOnly){
					s.value = $(this).attr("val");
                    //trigger change event
                    if ($.isFunction(o.onChanged)){
                        o.onChanged.call(s, s.value);
                    }
				}

				s._focusOpts($(this));
				s._displayOpts(false);

			}).mouseover(function(){
				s._focusOpts($(this));
			});
		},

		_onHotKey: function(keyCode){
			var s = this;

			if(!s.focusedOpt){
				return;
			}
			switch(keyCode){
				//up
				case nms.keyCode.UP:
					alert(typeof s.focusedOpt.prev());
					s._focusOpts( s.focusedOpt.prev() );
					break;
				//down
				case nms.keyCode.DOWN:
					s._focusOpts( s.focusedOpt.next() );
					break;
				default:
					return;
			}
		},

		getValue: function(){
			var s = this,
				o = s.options,
				inputVal = s.$input.val();

			//search opts[], even code like $combo.find("input").val("value"); , we can also read the correct value if "value" is in this.options.opts.
			if(s.readOnly ){
				for(var index in o.opts){
					if( o.opts[index].display === inputVal ){
						return o.opts[index].value;
					}
				}
                return "";
			}
            else{
                return inputVal;
            }

		},
        setValue: function(v){
            var s = this,
                o = s.options;

            if (s.readOnly){
                for(var index in o.opts){
                    if( o.opts[index].value == v ){
                        s.$input.val(o.opts[index].display);
                        s.value = v;
                        return;
                    }
                }
                s.$input.val("");
                s.value = "";
            }
            else{
                s.$input.val(v);
            }
        },
        setStatus: function(isEnabled){
            var s = this,
                e = s.element;

            if (typeof  isEnabled !== 'boolean'){
                return;
            }
            s.disabled = !isEnabled;
            if (s.disabled){
                s.$header.addClass('disabled');
                s.$input.prop('disabled', true).addClass('disabled');
            }
            else{
                s.$header.removeClass('disabled');
                s.$input.prop('disabled', false).removeClass('disabled');
            }
        }
	});
})();;$.extend($.fn, {
	getCss: function(key) {
		var v = parseInt(this.css(key));
		if (isNaN(v))
			return false;
		return v;
	}
});

$.fn.draggable = function(opts) {
	var ps = $.extend({
		zIndex: 20,
		opacity: .7,
		handler: null,
		inWindow: true,
		onMove: function() { },
		onDrop: function() { }
	}, opts);
	var dragndrop = {
		drag: function(e) {
			var dragData = e.data.dragData;
			
			var left = dragData.left + e.pageX - dragData.offLeft,
				top = dragData.top + e.pageY - dragData.offTop,
				$w = $(window),
				$e = e.data.dragData.me;
				
			if(ps.inWindow){
				var max_left = $w.width()-dragData.width,
					max_top = $w.height()-dragData.height;
					
				left = left>0 ? ( left< max_left ? left : max_left ) : 0;
				top = top>0 ? (top< max_top ? top : max_top ) : 0;
			}
			
			dragData.target.css({
				left: left,
				top: top
			});
			dragData.handler.css('cursor', 'move');
			return false;
		},
		drop: function(e) {
			var dragData = e.data.dragData;
			dragData.target.css(dragData.oldCss)
			dragData.handler.css('cursor', 'auto');

			$(this).unbind('mousemove', dragndrop.drag)
				.unbind('mouseup', dragndrop.drop);
				
			$(document).unbind('mousemove').unbind('mouseup');
			dragData.handler.unbind('mousemove').unbind('mouseup');
			document.onmousemove = null;
			document.onmouseup = null;
						
			document.unselectable  = "off";
            document.body.classList.remove("unselectable");
			document.onselectstart = null;
			
			//拖拽结束后仍保持光标为move
			$(this).mouseover();
			return false;
		}
	}
	return this.each(function() {
		var me = this,
			$me = $(me),
			handler = null;

		if (typeof ps.handler == 'undefined' || ps.handler == null)
			handler = $me;
		else
			handler = (typeof ps.handler == 'string' ? $(ps.handler, this) : ps.handler);

		handler.bind('mousedown', { e : me }, function(s) {
			var target = $(s.data.e);
			var oldCss = {};
			if (target.css('position') != 'absolute')
				target.css('position', 'absolute');
				
			var oldPosition = target.position();
			
			oldCss.cursor = target.css('cursor') || 'default';
			oldCss.opacity = target.getCss('opacity') || 1;
			var dragData = {
				left: oldPosition.left,
				top: oldPosition.top,
				width: target.outerWidth() || target.getCss('width'),
				height: target.outerHeight() || target.getCss('height'),
				offLeft: s.pageX,
				offTop: s.pageY,
				oldCss: oldCss,
				onMove: ps.onMove,
				onDrop: ps.onDrop,
				handler: handler,
				target: target
			}
			target.css('opacity', ps.opacity);
			
			document.unselectable  = "on";
            document.body.classList.add("unselectable");
			document.onselectstart = function(){return false;};/* 禁止选中 */
			
			handler.bind('mousemove', { dragData: dragData }, dragndrop.drag)
				.bind('mouseup', { dragData: dragData }, dragndrop.drop);
			
			$(document).bind('mousemove',{ dragData: dragData }, function(e){
				dragndrop.drag(e);
			}).bind('mouseup',{ dragData: dragData }, function(e){
				dragndrop.drop(e);
			});
			
			$me.find('body').bind('mousemove',{ dragData: dragData }, function(e){
				dragndrop.drag(e);
			}).bind('mouseup',{ dragData: dragData }, function(e){
				dragndrop.drop(e);
			});
			
		}).bind('mouseover', function(){
			handler.css('cursor','move');
			return false;
		}).bind('mouseout', function(){
			handler.css('cursor','auto');
			return false;
		});
	});
};;(function(){
	nms.lang.set({
		'zh':{
            'form.general':'验证错误',
			'form.require':'必填',
			'form.number':'必须是数字',
			'form.ip':'必须是有效的IP地址',
            'form.mask':'必须是有效的掩码',
            'form.gateway':'必须是有效的网关地址',
            'form.email':'邮箱名格式不正确',
            'form.string':'字符串长度不正确'
		},
		'en':{
            'form.general':'validate error',
			'form.require':'need to be not empty',
			'form.number':'must be a number',
			'form.ip':'must be a valid IP address',
            'form.mask':'must be a valid mask',
            'form.gateway':'must be a valid gateway address',
            'form.email':'invalid E-mail format',
            'form.string':'invalid string length'
		}
	});
	nms.widget('form', {
		options : {
			dataOptions:[],
            width : 140,
            height : 26
		},
		_create : function(){
			var s = this,
				e = this.element,
				o = this.options;

            e.addClass('nms-form');
            s.validationQueue = [];
            s.formMembers = {};
            s.hasPlaceHolder = s.hasPlaceHolder || (function(){return 'placeholder' in document.createElement('input');})();
            //s.hasPlaceHolder = false;

			$.each(o.dataOptions, function(index, obj){
                var target;
                if (obj.name == undefined){
                    return;
                }
                s.formMembers[obj.name] = obj;
                s.formMembers[obj.name].$target = e.find('[name="'+ obj.name +'"]');
                s.formMembers[obj.name].tooltipInit = false;
                $target = s.formMembers[obj.name].$target;
                if (!obj.type){
                    if($target.is('input')){
                        obj.type = $target.attr('type') || 'text';
                    }
                    else if ($target.is('select')){
                        obj.type = 'select';
                    }
                    else if ($target.is('textarea')){
                        obj.type = 'textarea';
                    }
                    else if ($target.is('button')){
                        return;
                    }
                    else{
                        obj.type = 'text';
                    }
                }
                if (s.hasPlaceHolder && !!obj.placeHolder){
                    $target.attr('placeholder', obj.placeHolder);
                }
                if (!!obj.value){
                    $target.val(obj.value);
                }
                if ($.isFunction(obj.change)){
                    $target.data('change', obj.change);
                }
				s._bindValidation(obj);
			});

		},

		_init : function(){
			var s = this,
				e = this.element,
				o = this.options;

            $.each(s.formMembers, function(key, obj){
                var $target = obj.$target;
                if (obj.type === 'text'){
                    if (!s.hasPlaceHolder && !!obj.placeHolder){
                        $target.focus(function(){
                            if($target.val()==obj.placeHolder){
                                $target.val('');
                            }
                            $target.removeClass('nms-form-placeHolder');
                            if ($target.hasClass('nms-form-alert')){
                                $target.removeClass('nms-form-alert').tooltip('disable');
                            }
                        }).blur(function(){
                            if($target.val()==''){
                                $target.val(obj.placeHolder)
                                    .addClass('nms-form-placeHolder');
                            }
                        }).focus().blur();
                    }
                    else{
                        $target.focus(function(){
                            if ($target.hasClass('nms-form-alert')){
                                $target.removeClass('nms-form-alert').tooltip('disable');
                            }
                        });
                    }
                }
            });

            e.find('input').each(function(i, o){
                var $o = $(o);
                if ($o.attr('type') == 'text' || $o.attr('type') == 'password' || $o.attr('type') == undefined){
                    $o.addClass('nms-form-text').keypress(function(e){
                        if(e.keyCode === nms.keyCode.ENTER){
                            e.preventDefault();/* stop default submit */
                            s.doSubmit();
                        }
                    });
                }
            });
            e.find('select').each(function(i, o){
                var $o = $(o),
                    opts = [];
                $o.find('option').each(function(idx, obj){
                    opts.push({display: obj.innerHTML, value: $(obj).attr('value')});
                });
                $o.hide().after('<div/>');
                $o.next().combobox({
                    opts: opts,
                    width: s.options.width,
                    height: s.options.height,
                    onChanged: function(val){
                        $o.val(val);
                        if ($.isFunction($o.data('change'))){
                            $o.data('change').call($o, val);
                        }
                    }
                }).combobox('setValue', $o.val());
            });
            if (o.submit && o.submit.button){
                if(typeof o.submit.button == "string"){
                    o.submit.button = e.find("#"+ o.submit.button);
                }
                o.submit.button.click(function(e){
                    s.doSubmit();
                });
            }

            e.submit(function(e){
                e.preventDefault();
            });
		},

		_bindValidation: function(obj){
			var s = this,
                member = s.formMembers[obj.name];

			var callValidation = function(validation){
                if (s['_'+validation] == undefined){
                    return true;
                }
                member.$target.addClass('nms-form-'+validation);
				return  s['_'+validation].call(s, member);
			};

			switch(typeof obj.validation){
				case 'function':
					s.validationQueue.push({name:obj.name, validType: 'function', fn:function(){
						return obj.validation(member.$target);
					}});
					break;
				case 'string':
					s.validationQueue.push({name:obj.name, validType: obj.validation, fn:function(){
						return callValidation(obj.validation);
					}});
					break;
				case 'object':/* Array */
                    if(obj.validation instanceof RegExp){
                        s.validationQueue.push({name:obj.name, validType: "reg", fn:function(){
                            return obj.validation.test(member.$target.val().trim());
                        }});
                        break;
                    }
					$.each(obj.validation,function(i,va){
						if(typeof va!=='string')
							return;
						s.validationQueue.push({name:obj.name, validType: va, fn:function(){
							return callValidation(va);
						}});
					});
					break;
				default:
					break;
			}
		},

        _getTitle: function(validObj){
            var opt = this.formMembers[validObj.name];
            if (!opt){
                return nms.lang.get('form.general');
            }
            else {
                return opt.title || nms.lang.get('form.'+validObj.validType) || nms.lang.get('form.general');
            }
        },

		_require: function(member){
            var target = member.$target;
			if(target.val()==='' || target.hasClass('nms-form-placeHolder')){
				return false;
			}
			return true;
		},

		_number:function(member){
            var target = member.$target;
			if(!target.val().isNumber(member.min, member.max)){
				return false;
			}
			return true;
		},

		_ip: function(member){
            var target = member.$target;
			if(!target.val().isIp('ip')){
				return false;
			}
			return true;
		},

        _gateway: function(member){
            var target = member.$target;
            if(!target.val().isIp('gateway')){
                return false;
            }
            return true;
        },

        _mask: function(member){
            var target = member.$target;
            if(!target.val().isIp('mask')){
                return false;
            }
            return true;
        },

        _email: function(member){
            var target = member.$target;
            if(!target.val().isEmail()){
                return false;
            }
            return true;
        },

        _string: function(member){
            var target = member.$target;
            if (typeof member.min && target.val().length < member.min){
                return false;
            }
            if (typeof member.max && target.val().length > member.max){
                return false;
            }
            return true;
        },

		validate: function(){
			var s = this,
                result = true,
                $target;

            $.each(s.formMembers, function(key, obj){
                $target = obj.$target;
                if ($target.hasClass('nms-form-alert')){
                    $target.removeClass('nms-form-alert').tooltip('disable');
                }
            });

			$.each(s.validationQueue,function(index,obj){
                $target = s.formMembers[obj.name].$target;
				if($target.is(':visible')&&!$target.prop('disabled')){
					if(!obj.fn()){
                        result = false;
						if(!$target.hasClass('nms-form-alert')){
							$target.addClass('nms-form-alert');
						}
                        if(!s.formMembers[obj.name].tooltipInit){
                            $target.tooltip({
                                title: s._getTitle(obj),
                                position:'top',
                                type:"alert",
                                container: s.element
                            });
                            s.formMembers[obj.name].tooltipInit = true;
                        }
                        else{
                            $target.tooltip('update', s._getTitle(obj));
                        }
					}
				}else{
					$target.val('');
				}
			});
			return result;
		},

        _getData: function(){
            var s = this,
                e = s.element,
                data = {};


            e.find('[name]').each(function(i, o){
                var $o = $(o),
                    name = $o.attr('name');

                var value = s._getMemberValue($o);
                if(value != undefined)
                    data[name] = value;
            });
            return data;
        },

        _getMemberValue: function($o){
            var type = $o.attr('type');
            if ($o.is('button'))
                    return;
            if ($o.is('input')){
                if(type === 'button' || type === 'submit')
                    return;

                if (type === 'radio' && $o.is(':checked'))
                    return $o.val();
                if (type === 'checkbox'){
                    return $o.is(':checked') ? true : false;
                }else{
                    return $o.val().trim();
                }
            }else{
                return $o.val();
            }
        },

        _setMemberValue:function($o, v){
            var type = $o.attr('type');
            if($o.is('button') || type == 'button')return;

            if($o.is('input') && (type=="text" || type=='password' || type==undefined))
                $o.val(v);
            else if($o.is("textarea")){
                $o.val(v);
            }
            else if($o.is("select")){
                $o.next().combobox("setValue", v);
            }else if($o.is('input') && type=="radio"){
                $o.prop("checked", v?true:false);
            }else if(type == "checkbox"){
                $o.prop("checked", v?true:false);
            }
        },

        value : function(name, v){
            var me = this;
            if(name == undefined){
                return me._getData();
            }else if(typeof name == "object"){
                for(var key in name){
                    me.value(key, name[key]);
                }
            }else if(v == undefined){
                var $o = me.element.find("[name="+name+"]");
                return me._getMemberValue($o);
            }else{
                var $o = me.element.find("[name="+name+"]");
                me._setMemberValue($o, v);
            }
        },

        doSubmit: function(){
            var s = this,
                e = s.element,
                param = s.options.submit;

            if(!s.validate()){
                return;
            }
            else{
                if (typeof param !== 'object'){
                    return;
                }
                nms.post(param.url, function(data){
                    //s.submiting = false;
                    if($.isFunction(param.success)){
                        param.success.call(s, data);
                    }
                }, s._getData(), param.dataType || 'json', param.type || 'post');
            }
        },

        setStatus: function(name, isEnable){
            var obj = this.formMembers[name],
                type,
                $target;
            if (typeof isEnable !== 'boolean'){
                return;
            }
            if (!obj){
                $target = this.element.find('[name="'+ name +'"]');
                type = $target.get(0).tagName.toLowerCase();
                if (type === 'input'){
                    type = $target.attr('type') || 'text';
                }
            }
            else{
                $target = obj.$target;
                type = obj.type;
            }

            if (type === 'select'){
                $target.prop('disabled', !isEnable).next().combobox('setStatus', isEnable);
            }
            else{
                $target.prop('disabled', !isEnable);
                if (isEnable){
                    $target.removeClass('disabled');
                }
                else{
                    $target.addClass('disabled');
                    if ($target.hasClass('nms-form-alert')){
                        $target.removeClass('nms-form-alert').tooltip('disable');
                    }
                }
            }
        }
	});
})();;(function () {
	nms.lang.set({
		"zh":{
			"grid.page_l":"第 ",
			"grid.page_r":" 页，总共 {0} 页",
			"grid.hide_filter_h":"隐藏过滤条件",
			"grid.hide_filter_s":"显示过滤条件",
			"grid.select_col":"显示/隐藏列",
            "grid.page_size":"每页显示",
            "grid.page_jump":"跳转到",
            "g.filter":"过滤",
            "g.clear":"清除",
            "grid.empty_data":"没有可以显示的条目"
		},
		"en":{
			"grid.page_l":"Page ",
			"grid.page_r":" of {0}",
			"grid.hide_filter_h":"Hide Filter",
			"grid.hide_filter_s":"Show Filter",
			"grid.select_col":"Columns",
            "grid.page_size":"Page Size",
            "grid.page_jump":"Jump To",
            "g.filter":"Filter",
            "g.clear":"Clear",
            "grid.empty_data":"No entry in the table"
		}
	});
	nms.widget("grid", {
		options: {
			title: false,
			width: "auto",
			height: "auto",
			source: [],

			selectable: true,

			page: 1,
			pageSize: 10,
			pageSizeOptions: [10, 15, 20, 30, 50, 100],
			sortName: false,
			sortOrder: "asc",
			colModel: false,
			defaultColModel:{
				width: "auto",
				align: "center",
                show: true,
                sortAble: false
			},

			onDoubleClick: false,

			filterParam: false,

			btnSet: [],
			filter: false,
            initedCallback: false,
            helpInfo: {
                shown: false,
                source: false
            }
		},

		_create: function () {
			var me = this,
				e = this.element;

			e.addClass("nms-grid");
			me.$store = {};
			me.listener = {};
            me.param = {};

            me._paramInit();
			me._buildTitle();
			me._buildFilter();
			me._buildToolBar();
			me._buildHeader();
            me._buildColSel();
            me._refreshPage();

			me.refresh();
		},
		_init: function () {
			var me = this,
                $store = me.$store,
                param = me.param;
			var $sortable = $store.$header.find(".nms-grid-sortable").click(function(){
				var $td = $(this);
				if(param.sortName == $td.find("div:first").attr("cellname")){
                    if(param.sortOrder == "asc"){
                        param.sortOrder =  "desc";
                        $td.removeClass("nms-grid-arrow-asc").addClass("nms-grid-arrow-desc");
                    }
                    else{
                        param.sortOrder = "asc";
                        $td.removeClass("nms-grid-arrow-desc").addClass("nms-grid-arrow-asc");
                    }
				}else{
					param.sortName = $td.find("div:first").attr("cellname");
					param.sortOrder = me.options.sortOrder;
                    $sortable.removeClass("nms-grid-arrow-asc").removeClass("nms-grid-arrow-desc");
                    $td.addClass("nms-grid-arrow-"+me.options.sortOrder);
				}
                param.page = 1;

				me.refresh();
			}).mouseenter(function(){
                var $td = $(this);
                if(param.sortName != $td.find("div:first").attr("cellname")){
                    $td.addClass("nms-grid-arrow-"+me.options.sortOrder);
                }
            }).mouseleave(function(){
                var $td = $(this);
                if(param.sortName != $td.find("div:first").attr("cellname")){
                    $td.removeClass("nms-grid-arrow-asc").removeClass("nms-grid-arrow-desc");
                }
            });
            $store.$page.find("input").keypress(function(event){
                if(event.keyCode == nms.keyCode.ENTER){
                    if(!this.value.isNumber() || this.value > me.data.pageNum || this.value < 1 || this.value == me.param.page)
                        return;
                    me.param.page = this.value;
                    me.refresh();
                }
            });
            $store.$page.find(".nms-grid-page-jump-wrapper>div").click(function(){
                var input = $store.$page.find(".nms-grid-page-jump-wrapper>input").val();
                if(!input.isNumber() || input > me.data.pageNum || input < 1 || input == me.param.page)
                    return;
                me.param.page = input;
                me.refresh();
            });
		},

		_buildTitle: function(){
			var me = this,
				o = me.options;

			if(!o.title && !o.helpInfo.shown)return;

			var html = '<div class="nms-grid-title">';
			if (!!o.title) html += '<span>'+o.title+'</span>';
            if (!!o.helpInfo.shown) html += '<div class="icon icon-help nms-grid-help-info"></div>';
			html += '</div>';

			me.element.append(html);
		},
    _buildFilter:function(){
        var me = this,
            filter = me.options.filter;

        if(!filter || !filter.length)return;
        if(me.$filter){
            me.$filter.isSlideDown ? me.$filter.slideDown(150) : me.$filter.slideUp(150);
            me.$filter.isSlideDown = !me.$filter.isSlideDown;
            return;
        }

        var html = '<div class="nms-grid-filter"><div class="nms-grid-filter-content">';
        for(var index in filter){
            var f = filter[index];
            if(f.type == "input"){
                html += '<div><span class="nms-grid-filter-display inline">'+ f.display + '</span></td>'
                    + '<input id="nms-grid-form-'+ f.name +'" type="text" name="'+ f.name +'"></div>';
            }else if(f.type == "select"){
                html += '<div><span class="nms-grid-filter-display inline">'+ f.display +'</span><select id="nms-grid-form-'+ f.name +'">';

                for(var i in f.options){
                    html +=  '<option value="' + f.options[i].value + '">' + f.options[i].display + '</option>';
                }
                html += '</select><div></div></div>';
            }else if(f.type == "checkbox"){
                html += '<div><label for="nms-grid-form-' + f.name + '"><span class="nms-grid-filter-display inline">'+ f.display
                    +'</span></label><input id="nms-grid-form-'+ f.name +'" type="checkbox" name="'+ f.name +'"></div>';
            }
        }
        html += '</div><div  class="nms-grid-filter-control"><div id="nms-grid-filter-apply"><button>'+ nms.lang.get("g.filter") +'</button></div>';
        html += '<div id="nms-grid-filter-clear"><button>'+ nms.lang.get("g.clear") +'</button></div></div></div>';

        me.$filter = $(html).appendTo(me.element).hide();
        me.$filter.form = {};
        me.$filter.isSlideDown = true;
        for(var index in filter){
            var f = filter[index];
            me.$filter.form[f.name] = me.$filter.find("#nms-grid-form-"+f.name);
            if (f.type == "select"){
                me.$filter.form[f.name].hide().next().combobox({
                    opts: f.options,
                    width: 200,
                    height: 25
                }).combobox('setValue', f.defaultOption);
            }
            if (f.type == "input"){
                me.$filter.form[f.name].css({width: 200, height: 25});
            }
        }

        me.$filter.find("#nms-grid-filter-apply").click(function(){
            me.param.filter = $.extend({}, me.param.filter);

            me.filter = {};
            for(var index in filter){
                var f = filter[index];
                if(f.type == "input"){
                    me.filter[f.name] = me.$filter.form[f.name].val();
                }
                if(f.type == "checkbox"){
                    me.filter[f.name] = me.$filter.form[f.name].attr("checked") ? true: false;
                }
                if(f.type == "select"){
                    me.filter[f.name] = me.$filter.form[f.name].next().combobox("getValue");
                }
            }
            $.extend(me.param.filter, me.filter);

            me.refresh();
        });
        me.$filter.find("#nms-grid-filter-clear").click(function(){
            me.param.filter = $.extend({}, me.options.filterParam);

            for(var index in filter){
                var f = filter[index];
                if(f.type == "input"){
                    me.$filter.form[f.name].val('');
                }else if(f.type == "checkbox"){
                    me.$filter.form[f.name].attr("checked", false);
                }else if(f.type == "select"){
                    me.$filter.form[f.name].val(f.defaultOption);
                    me.$filter.form[f.name].next().combobox('setValue', f.defaultOption);
                }
            }
            me.filter = {};

            me.refresh();
        });
    },

    _buildToolBar: function(){
        var me = this,
            o = me.options;

        var html = '<div class="nms-grid-toolBar">';

        html += '<div class="nms-grid-toolBar-common"><div></div></div>';

        html += '<div class="nms-grid-toolBar-btnD">';
        for(var i = 0; i < o.btnSet.length; i++){
            html += '<div></div>';
        }
        html += '</div>';

        html += '</div>';

        me.$toolbar = $(html).appendTo(me.element);
        me.$toolbar.find(".nms-grid-toolBar-btnD div").each(function(index, ele){
            $(ele).button(o.btnSet[index]);
        });

        me.$colSelD = $('<ul class="nms-grid-colSelD"><ul/>').hide();
        $(".nms-grid-toolBar-common div:first").button({
                name: '',
                type: "button-colSel",
                toggle: true,
                onToggle: function(){
                    if(me.$colSelD.css("display")!=="none"){
                        me.$colSelD.css("display", "none");
                    }else{
                        me.$colSelD.css("display", "block");
                    }
                }
            }).after(me.$colSelD);

        if(o.filter && o.filter.length){
            $("<div/>").button({
                name: '',
                type: "button-filter",
                toggle: true,
                onToggle: function(){me._buildFilter();}
            }).appendTo(me.element.find(".nms-grid-toolBar-common"));
        }
    },

    _buildHeader: function(){
        var me = this,
            o = me.options;

        //wrap table to be scroll
        me.$tableWrapper = $('<div class="nms-grid-tbWrapper"/>').appendTo(me.element);

        if(!o.colModel){
            throw new Error("Field colModel is NULL in options.");
        }

        me.name = [];
        var html = '<table class="nms-grid-header"><tr>';

        if(typeof o.selectable == "string"){
            html += '<td width="26px">'
            if(o.selectable == "multiple"){
                html += '<input id="nms_grd_select_all" type="checkbox">';
            }
            html += '</td>';
        }

        for(var i in o.colModel){
            var col = o.colModel[i];
            var w = (typeof col.width == "string")?col.width:(col.width+"px");
            var sortClass = col.sortAble?' class="nms-grid-sortable"':'';
            html += '<td width="'+ w +'"'+sortClass+'>';
            html += '<div style="text-align:'+ col.align+'" class="pointer" cellname="'+col.name+'">';
            html += '<span>'+col.display+'</span>';
            html += '</div><div class="nms-grid-arrow"></div></td>';

            me.name.push(col.name);
        }

        html += '</tr></table>';
        me.$store['$header'] = $(html).appendTo(me.$tableWrapper);
        me.$selectall = me.$store.$header.find("#nms_grd_select_all").click(function(){
            var isSelect = this.checked;
            me.$checkbox.each(function(i, o){
                this.checked = isSelect;
                me.selectData[$(this).attr("index")] = isSelect ? true : false;
            });
            if ($.isFunction(o.onSelect)){
                o.onSelect.call(null, me.getSelectRow());
            }
        });
    },

    _buildBody : function(){
        var me = this,
            o = me.options;

        if(!me.body){
            me.body = $('<table class="nms-grid-body"></table>');
            me.$tableWrapper.append(me.body);
        }

        if(!me.data){
            return;
        }

        var body = me.body,
            data = me.data.rows,
            name = me.name,
            cols = o.colModel,
            html = '',
            w    = '';

        body.empty();
        $('.nms-grid-empty').remove();
        if (!data || data.length === 0){
            body.after('<div class="nms-grid-empty">' + nms.lang.get('grid.empty_data') + '</div>');
            me._adjustColumn();
            return;
        }
        for(var index in data){
            var row = data[index];
            html += '<tr index="'+ index +'">';

            if(typeof o.selectable == 'string'){
                html += '<td width="26px"><input id="nms_grid_checkbox" index="'+index+'" type="checkbox"></td>';;
            }
            for(var i in name){
                var col = cols[i];
                w = (typeof col.width == "string")?col.width:(col.width+"px");
                html += '<td width="'+ w +'"  style="text-align:'+ col.align+'">';
                if(col.callback){
                    var text = col.callback(me._getCellData(row, name[i]), index);
                    html += (typeof text == "string") ? text : me._getCellData(row, name[i]);
                }else{
                    html += me._getCellData(row, name[i]);
                }
                html += '</td>';
            }
            html += '</tr>';
        }

        body.append(html);

        //add zebra background
        body.find('tr:nth-child(even)').addClass('nms-grid-zebra');

        me.selectData = [];
        var checkboxClick = function($checkbox){
            var trIndex = $checkbox.attr("index");
            if(o.selectable == "multiple"){
                me.$selectall.prop("checked", false);
            }else if(o.selectable == "single"){
                body.find("#nms_grid_checkbox").each(function(i, o){
                    if(o.checked && $(o).attr('index') !=trIndex){
                        o.checked = false;
                    }
                });
                me.selectData = [];
            }
            me.selectData[trIndex] = $checkbox.prop("checked");
            if ($.isFunction(o.onSelect)){
                o.onSelect.call(null, me.getSelectRow());
            }
        }
        me.$checkbox = body.find("#nms_grid_checkbox").click(function(event){
            event.stopPropagation();
            checkboxClick($(this));
        });
        body.children().children("tr").click(function(){
            var $checkbox = $(this).find("#nms_grid_checkbox");
            $checkbox.prop("checked", !$checkbox.prop("checked"));
            checkboxClick($checkbox);
        }).dblclick(function(){
            if(o.onDoubleClick){
                o.onDoubleClick($(this).attr("index"));
            }
        });
        me._adjustColumn();

        if(o.initedCallback){
            o.initedCallback.call(me.element);
        }
    },

    _getCellData: function(row, name){
        if(typeof name == "string"){
            var names = name.split(".");
            return (names.length==1)?row[name]:this._getCellData(row, names);
        }

        return (name.length <= 1)?row[name]:this._getCellData(row[name.shift()], name);
    },

    _refreshPage: function(currentPage, totalPage){
        var me = this,
            html = '',
            lang = nms.lang,
            pageSizeOptions = me.options.pageSizeOptions,
            pageSizeConf = [],
            omitLength = 2,
            leftOmit = false,
            rightOmit = false;

        if (!me.$store['$page']){//the page container create only once
            me.$store['$page'] = $('<div class="nms-grid-page">' +
                '<div class="nms-grid-page-size-wrapper"></div>' +
                '<div class="nms-grid-page-jump-wrapper"></div>' +
                '<div class="nms-grid-page-button-wrapper"></div>' +
                '</div>')
                .appendTo(me.element).delegate('.nms-grid-page-button', 'click', function(){
                var pageClick = this.innerHTML;
                me.param.page = parseInt(me.param.page, 10);
                me.data.pageNum = parseInt(me.data.pageNum, 10);
                if (pageClick == '&lt;'){
                    if (me.param.page <= 1){
                        return;
                    }
                    else{
                        me.param.page -= 1;
                    }
                }
                else if (pageClick == '&gt;'){
                    if (me.param.page >= me.data.pageNum){
                        return;
                    }
                    else{
                        me.param.page += 1;
                    }
                }
                else{
                    pageClick = parseInt(pageClick, 10);
                    me.param.page = pageClick;
                }
                me.refresh();
            });
            html = '<span>' + lang.get('grid.page_size') + '</span>';
            for(var index in pageSizeOptions){
                pageSizeConf.push({display: pageSizeOptions[index], value: pageSizeOptions[index]});
            }
            me.$store['$page'].find('.nms-grid-page-size-wrapper').html(html)
                .append($('<div/>').combobox({
                    width: 50,
                    height: 25,
                    opts: pageSizeConf,
                    onChanged: function(v){
                        me.param.pageSize = v;
                        me.param.page = 1;
                        me.refresh();
                    }
                }).combobox('setValue', pageSizeOptions[0]));
            html = '<span>' + lang.get('grid.page_jump') + '</span>';
            html += '<input type="text" class="nms-grid-jump-index" />';
            html += '<div>GO</div>';
            me.$store['$page'].find('.nms-grid-page-jump-wrapper').html(html);
            return;
        }
        if (!me.data.rows || me.data.rows.length == 0){
            me.$store['$page'].addClass('nms-grid-page-empty');
            return;
        }
        else{
            me.$store['$page'].removeClass('nms-grid-page-empty');
        }
        html = '<div class="nms-grid-page-button">&lt;</div>';
        for (var i = 1; i <= totalPage; i++){
            if (i != 1 && (currentPage - i > omitLength) && (totalPage - i > omitLength *2+2)){
                if (!leftOmit){
                    html += '<div class="nms-grid-page-omit">...</div>';
                    leftOmit = true;
                }
                continue;//do not create
            }
            if (i != totalPage && (i - currentPage > omitLength) && (i - 1 > omitLength *2+2)){
                if (!rightOmit){
                    html += '<div class="nms-grid-page-omit">...</div>';
                    rightOmit = true;
                }
                continue;//do not create
            }
            if (i != currentPage){
                html += '<div class="nms-grid-page-button">' + i + '</div>';
            }
            else{
                html += '<div class="nms-grid-page-button nms-grid-page-button-current">' + i + '</div>';
            }
        }
        html += '<div class="nms-grid-page-button">&gt;</div>';
        me.$store['$page'].find('.nms-grid-page-button-wrapper').empty().append($(html));
    },
    _paramInit: function(){
        var me = this,
            o = me.options,
            _param = me.param;

        _param.page = o.page;
        _param.pageSize = o.pageSize;
        _param.sortName = o.sortName;
        _param.sortOrder = o.sortOrder;
        //_param.query = null;
        //_param.queryType = null;

        if(o.filterParam){
            _param.filter = $.extend({}, o.filterParam, true);
        }
        for (var i in o.colModel){
            o.colModel[i] = $.extend({}, o.defaultColModel, o.colModel[i]);
        }
    },

    refresh: function(source, options){
        var me = this,
            o = me.options;

        me.$selectall.prop("checked", false);
        o.source = source || o.source;

        if(options != undefined){
            o = $.extend(o, options, true);
        }

        if(typeof o.source == 'object'){
            if($.isArray(o.source)){
                var gridData = $.extend({}, me.param, true);
                gridData.rows = o.source;
                gridData.pageNum = Math.ceil(gridData.rows.length/gridData.pageSize);
                o.source = gridData;
            }
            me._refresh(o.source);
        }else{
            me.param.filter = $.extend({}, o.filterParam, me.filter);
            nms.post(o.source, function(data){
                me._refresh(data);
            }, me.param);
        }
    },

    _refresh: function(data){
        var me = this;
        me.data = data;
        //me.listener.page.set(me.data.pageNum);
        me._buildBody();
        me._refreshPage(me.param.page, me.data.pageNum);
    },

    _buildColSel: function(){
        var html = '',
            me = this,
            col = me.options.colModel;
        $.each(col, function(index){
            html += '<li><input type="checkbox" id="col-index-'+index+'"/><label for="col-index-'+index+'">'+col[index].display+'</label></li>';
        });
        me.$colSelD.empty().append($(html)).find("input").each(function(index, input){
            $(input).prop("checked", col[index].show).change(function(){
                col[index].show = $(this).prop("checked");
                me._adjustColumn();
            });
        });
    },

    _adjustColumn: function(){
        var me = this,
            col = me.options.colModel,
            flags = {
                autoColumnExist: false,
                widestColumnIndex: 0,
                widestColumnLength: 0
            },
            changeColumn = function(index, type){
                var length = col.length;
                if (typeof  me.options.selectable == 'string'){
                    index++;
                    length++;
                }
                var query = 'td:nth-of-type('+length+'n+'+index+')';
                switch (type){
                    case 'show':
                        me.$tableWrapper.find(query).show();
                        break;
                    case 'hide':
                        me.$tableWrapper.find(query).hide();
                        break;
                    case 'auto':
                        me.$tableWrapper.find(query).addClass('auto');
                        break;
                    default :
                        break;
                }
            };

        //update the visible status; make the visible widest column width to be 'auto'
        for (var i= 0; i< col.length; i++){
            if (col[i].show == true){
                if (col[i].width === 'auto'){
                    flags.autoColumnExist = true;
                }
                else{
                    if (parseInt(col[i].width, 10) >= flags.widestColumnLength){
                        flags.widestColumnIndex = i;
                        flags.widestColumnLength = parseInt(col[i].width, 10);
                    }
                }
                changeColumn(i+1, 'show');
            }
            else{
                changeColumn(i+1, 'hide');
            }
        }
        if (!flags.autoColumnExist){
            me.$tableWrapper.find('td').removeClass('auto');
            changeColumn(flags.widestColumnIndex+1, 'auto');
        }
    },

    getSelectRow: function(){
        var row = [],
            selectData = this.selectData;
        for(var i in selectData){
            if(selectData[i]){
                row.push(i);
            }
        }
        return row;
    },

    getData: function(index){
        return this.data ? (index==undefined ? this.data.rows : (this.data.rows[index]==undefined?null: this.data.rows[index])) : null;
    },

    getButtonByName: function(name){
        var me = this,
            o  = me.options,
            i  = 0;

        if (!name){
            return false;
        }
        for (i = o.btnSet.length - 1; i >=0; i--){
            if (o.btnSet[i].name === name){
                return me.$toolbar.find(".nms-grid-toolBar-btnD .nms-button:eq(" + i +")");
            }
        }
        return false;
    },

    send: function(url, key, data, callBack, onError){
        var me = this,
            rowsData = me.getData(),
            rows = me.getSelectRow(),
            submitData = {
                rows: [],
                data: {}
            };
        if(data == null){
            if ($.isFunction(onError) && rows.length === 0){
                onError();
                return;
            }
        }
        else{
            submitData.data = data;
        }
        for(var j = rows.length-1; j >=0; j--){
            var tempObj = {};
            for(var k = key.length-1; k>=0; k--){
                tempObj[key[k]] = rowsData[rows[j]][key[k]];
            }
            submitData.rows.push(tempObj);
        }
        nms.post(url, callBack || function(){}, submitData);
    }
});
})();;(function(){
nms.widget("dialog", {
	options : {
		maxHeight : false,
		maxWidth : false,
		modal : true,
		draggable : true,
		title : "",
		closable : true,
		onClosePress : false,
		maxiable: false,
		url:false,
		source:false
	},
	_create : function(){
		var s = this,
			e = this.element,
			o = this.options;

        e.css("display", "block");

		o.maxHeight = o.maxHeight ? o.maxHeight : 500;
		o.maxWidth = o.maxWidth ? o.maxWidth : $(window).width();
			
        //e.css('max-height', o.maxHeight);/* 注释掉，不让滚动条出现 */
		
		s.width = o.width ? o.width :
			( e.width() > o.maxWidth ? o.maxWidth : e.width() );
		s.width += "px";
		
		o.onClosePress = o.onClosePress ? o.onClosePress : function(){s.close()};
		
		if(typeof o.source == "string"){
			$.post(o.source, [], function(data){
				s.data = data;
				s._buildDialog();
			});
		}else{
			s.data = o.source;
			s._buildDialog();
		}
	},
	
	_init : function(){
		var s = this,
			e = this.element,
			o = this.options;
			
		s._$mask = $('<div class="nms-dialog-mask"></div>');
		e.addClass("nms-dialog-body");
		s._modal( o.modal );
        if (o.maxiable){
            s._header.bind('dblclick', function(){
                s._$maxIcon.trigger('click');
            });
        }
	},
	
	_buildDialog : function(){
		var s = this,
			e = this.element,
			o = this.options;
		
		var $header = $('<div class="nms-dialog-header"></div>'),
			$title = $('<div class="nms-dialog-title"></div>').html(o.title ? o.title : "&nbsp;"), 
			$tools = $('<div class="nms-dialog-tools"></div>'), 
			handler = o.handler ? o.handler : $title,
			$dialog = $('<div class="nms-dialog"></div>').css("width", s.width);

		s._dialog = $dialog;
		s._header = $header;
		$header.append($title).append($tools);
		e.before($dialog).appendTo($dialog).before($header);
		
		s._2center();
		s._initTools($tools);
		s._draggable(handler);
		
		s.loadAjax();
	},
	
	_modal : function(isModal){
		var s = this;
		if( isModal )
			$("body").append(s._$mask);
		else
			s._$mask.remove();
	},
	
	_draggable : function(handler){
		var s = this,
			e = this.element,
			o = this.options;

		if(!o.draggable)
			return e;
		
		s._dialog.draggable({handler:handler});
		return e;
	}, 
	
	_initTools : function($tools){
		var s = this,
			e = this.element,
			o = this.options;
			
			if(o.closable){
				var $closeIcon = $('<div class="nms-icon-close"></div>');
				$closeIcon.appendTo($tools);
				$closeIcon.click(o.onClosePress);
			}
			
			if(o.maxiable){
				var $maxIcon = $('<div class="nms-icon-max"></div>'),
					$w = $(window);
					
				$maxIcon.appendTo($tools); 
				
				$maxIcon.click(function(){
					var type = $maxIcon.attr("class");
					
					if(type === "nms-icon-max"){
						$maxIcon.attr("class", "nms-icon-return");
						
						var bodyHeight = e.height() + $w.height() - s._dialog.outerHeight();
                        var windowWidth = $w.width();
						e.height(bodyHeight);
                        s._dialog.css({left:0, top:0, width: windowWidth});
						
					}else{
						$maxIcon.attr("class", "nms-icon-max");
						e.css("height", "auto");
                        s._dialog.css("width", s.width);
						s._2center();
					}
				});
                s._$maxIcon = $maxIcon;
			}
	},
	
	_2center : function(){
		var $w = $(window),
			s = this,
			top = ($w.height() - parseInt(s.element.height()))/2,
			left = ($w.width() - parseInt(s.width))/2;
			
		top = top>0 ? top : 0;
		left = left>0 ? left : 0;
		s._dialog.css({left:left, top:top});
	},
	
	loadAjax : function(){
		var s = this,
			e = s.element,
			o = s.options;
			
		if( o.url )
			e.load(o.url);
		return e;
	},

    title: function(title){
        this._header.find(".nms-dialog-title").html(title);
    },
	
	close : function(){
		var s = this;
		
		s._dialog.css("display", "none");
		s._modal(false);
	},
	
	open : function(){
		var s = this,
			o = s.options;
        if (!s._dialog){
            return false;
        }
		s._dialog.css("display", "block");
		s._modal( o.modal );
        return true;
	},
	
	remove: function(){
		this.close();
		this._dialog.remove();
	}
});
})();