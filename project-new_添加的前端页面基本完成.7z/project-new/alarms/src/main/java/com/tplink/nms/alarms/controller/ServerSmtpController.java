package com.tplink.nms.alarms.controller;

import com.tplink.nms.alarms.domain.ServerSmtp;
import com.tplink.nms.alarms.service.ServerSmtpService;
import com.tplink.nms.mvc.bean.OperationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/alarms")
public class ServerSmtpController {

    @Autowired
    private ServerSmtpService serverSmtpService;

    @RequestMapping("/server-smtp")
    public String serverSmtp() {
        return "/alarms/server-smtp";
    }

    @ResponseBody
    @RequestMapping(value = "/get-server-smtp", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public ServerSmtp getServerSmtp() {
        return serverSmtpService.getServerSmtp();
    }

    @ResponseBody
    @RequestMapping(value = "/set-server-smtp" ,method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public OperationResult setServerSmtp(@RequestBody ServerSmtp serverSmtp) {
        return serverSmtpService.setServerSmtp(serverSmtp);
    }

    @ResponseBody
    @RequestMapping(value = "/test-server-smtp" ,method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public OperationResult testServerSmtp(@RequestBody ServerSmtp serverSmtp) {
        return serverSmtpService.testServerSmtp(serverSmtp);
    }

}
