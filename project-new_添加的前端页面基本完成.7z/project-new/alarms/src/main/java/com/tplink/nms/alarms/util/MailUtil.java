package com.tplink.nms.alarms.util;

import com.sun.mail.util.MailSSLSocketFactory;
import com.tplink.nms.alarms.domain.ServerSmtp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import java.security.GeneralSecurityException;
import java.util.Properties;

public class MailUtil {
    public static boolean      debug = false;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public static final String SMTP                        = "smtp";
    public static final String SMTPS                       = "smtps";
    public static final String MAIL_PORT                   = "mail.smtp.port";
    public static final String MAIL_SSL                    = "mail.smtps.ssl.enable";
    public static final String MAIL_SSL_FACTORY            = "mail.smtps.ssl.socketFactory";
    public static final String UTF8_ENCODE                 = "text/plain;charset=UTF-8";
    public static final String MAIL_SMTP_HOST              = "mail.smtp.host";
    public static final String MAIL_SMTP_AUTH              = "mail.smtp.auth";
    public static final String MAIL_SMTPS_HOST             = "mail.smtps.host";
    public static final String MAIL_SMTPS_AUTH             = "mail.smtps.auth";
    public static final String MAIL_SMTP_CONNECTIONTIMEOUT = "mail.smtp.connectiontimeout";
    public static final String MAIL_SMTP_TIMEOUT           = "mail.smtp.timeout";

    public static boolean testSmtp(ServerSmtp serverSmtp) {
        Transport transport = null;
        Session mailSession = null;
        String sender = serverSmtp.getSender();
        try {
            Properties props = getProperties(serverSmtp);
            String password = serverSmtp.getPassword();
            mailSession = Session.getInstance(props);
            mailSession.setDebug(debug);
            if (serverSmtp.isSslEnable()) {
                transport = mailSession.getTransport(SMTPS);
            } else {
                transport = mailSession.getTransport(SMTP);
            }
            transport.connect(serverSmtp.getSmtpServer(), serverSmtp.getPort(),
                    serverSmtp.getUserName(), password);

        } catch (GeneralSecurityException | NumberFormatException | MessagingException e) {
            return false;
        }

        return true;

    }

    private static Properties getProperties(ServerSmtp mailServer) throws GeneralSecurityException {
        Properties props = System.getProperties();
        removeProperties(props);
        boolean sslEnable = mailServer.isSslEnable();
        String host = mailServer.getSmtpServer();
        String authEnable = String.valueOf(mailServer.isAuthEnable());
        String protocol = sslEnable ? "smtps" : "smtp";

        if (sslEnable) {
            MailSSLSocketFactory sf = null;
            try {
                sf = new MailSSLSocketFactory();
            } catch (GeneralSecurityException e) {
                e.printStackTrace();
                throw e;
            }

            sf.setTrustedHosts(new String[] { "my-server" });
            props.put(MAIL_SSL, "true");
            props.put(MAIL_SSL_FACTORY, sf);
        }

        props.put((new StringBuilder("mail.")).append(protocol).append(".host").toString(), host);
        props.put((new StringBuilder("mail.")).append(protocol).append(".auth").toString(), authEnable);

        return props;
    }

    private static void removeProperties(Properties props) {
        props.remove(MAIL_SMTP_HOST);
        props.remove(MAIL_SMTP_AUTH);
        props.remove(MAIL_SMTPS_HOST);
        props.remove(MAIL_SMTPS_AUTH);
    }

}
