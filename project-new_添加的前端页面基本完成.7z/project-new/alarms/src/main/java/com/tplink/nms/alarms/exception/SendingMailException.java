/*
 * Copyright (C) 2014 TP-LINK Technologies Co., Ltd. All rights reserved.
 * 
 * Filename: SendingMailException.java
 */

package com.tplink.nms.alarms.exception;

/**
 * @author taozi
 * 
 */

public class SendingMailException extends FMException {
    private static final long   serialVersionUID    = 7235381983674535767L;

    private static final String SEND_MAIL_EXCEPTION = "com.tplink.nms.alarms.mail.sendingFailed";
    
    public SendingMailException() {
        super(SEND_MAIL_EXCEPTION);
    }
    
    public SendingMailException(String message) {
        super(SEND_MAIL_EXCEPTION, message);
    }
    
    public SendingMailException(Throwable cause) {
        super(SEND_MAIL_EXCEPTION, cause);
    }
    
    public SendingMailException(String message, Throwable cause) {
        super(SEND_MAIL_EXCEPTION, message, cause);
    }
    
}
