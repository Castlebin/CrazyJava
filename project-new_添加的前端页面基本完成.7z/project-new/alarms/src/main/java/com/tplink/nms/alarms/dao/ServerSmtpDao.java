package com.tplink.nms.alarms.dao;

import com.tplink.nms.alarms.domain.ServerSmtp;
import com.tplink.nms.mvc.dao.BaseDao;
import org.springframework.stereotype.Repository;

@Repository
public class ServerSmtpDao extends BaseDao<ServerSmtp> {

    public ServerSmtp getServerSmtp() {
        return get(1l);
    }

    public void setServerSmtp(ServerSmtp serverSmtp) {
        saveOrUpdate(serverSmtp);
    }

}
