package com.tplink.nms.alarms.service;

import com.tplink.nms.alarms.dao.RemoteNoticeGroupDao;
import com.tplink.nms.alarms.domain.RemoteNoticeUserGroup;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RemoteNoticeGroupService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private RemoteNoticeGroupDao remoteNoticeGroupDao;

    public Grid<RemoteNoticeUserGroup> getRemoteNoticeGroup(Grid<RemoteNoticeUserGroup> grid) {
        return remoteNoticeGroupDao.getRemoteNoticeGroup(grid, grid.getQueryConditionList());
    }

    public List<OperationResult> deleteRemoteNoticeGroup(List<Long> ids) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(deleteRemoteNoticeGroup(id));
        }

        return operResult;
    }

    private OperationResult deleteRemoteNoticeGroup(Long id) {
        try {
            remoteNoticeGroupDao.deleteRemoteNoticeGroup(id);
            return new OperationResult("success", "fm.service.global.delete", null);
        } catch (DataAccessException e) {
            logger.error("Delete failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

    public OperationResult editRemoteNoticeGroup(RemoteNoticeUserGroup remoteNoticeUserGroup) {
        try {
            remoteNoticeGroupDao.editRemoteNoticeGroup(remoteNoticeUserGroup);
            return new OperationResult("success", "fm.service.global.delete", null);
        } catch (DataAccessException e) {
            logger.error("Edit failed, remote user group: {}.", remoteNoticeUserGroup.getName());
        }

        return new OperationResult("fail","fm.service.global.fail" , null);
    }
}
