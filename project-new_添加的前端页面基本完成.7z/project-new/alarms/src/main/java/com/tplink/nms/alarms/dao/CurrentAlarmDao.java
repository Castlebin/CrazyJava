package com.tplink.nms.alarms.dao;

import com.tplink.nms.alarms.domain.CurrentAlarm;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public class CurrentAlarmDao extends BaseDao<CurrentAlarm> {

    public Grid getCurrentAlarm(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(FilterHql.getFilterHql(CurrentAlarm.class, filter), grid);
    }

}
