package com.tplink.nms.alarms.domain;

import com.tplink.nms.mvc.utils.JsonDateSerializer;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "tnt_current_alarm")
public class CurrentAlarm implements Serializable {
    private static final long serialVersionUID = 4231074610603978757L;

    private Long id;
    private Integer count;
    private Integer devId;
    private Integer devTypeId;
    private String devIp;
    private String devName;
    private Date faultTime;
    private Date lastArrivedTime;
    private String ackedUser;
    private Date ackedTime;
    private String paras;
    private String clearedUser;
    private Date clearedTime;
    private String status;

    private AlarmConf alarmConf;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "alarm_id")
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "count")
    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    @Column(name = "dev_id")
    public Integer getDevId() {
        return devId;
    }

    public void setDevId(Integer devId) {
        this.devId = devId;
    }

    @Column(name = "dev_type_id")
    public Integer getDevTypeId() {
        return devTypeId;
    }

    public void setDevTypeId(Integer devTypeId) {
        this.devTypeId = devTypeId;
    }

    @Column(name = "dev_ip")
    public String getDevIp() {
        return devIp;
    }

    public void setDevIp(String devIp) {
        this.devIp = devIp;
    }

    @Column(name = "dev_name")
    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

    @JsonSerialize(using=JsonDateSerializer.class)
    @Column(name = "fault_time")
    public Date getFaultTime() {
        return faultTime;
    }

    public void setFaultTime(Date faultTime) {
        this.faultTime = faultTime;
    }

    @JsonSerialize(using=JsonDateSerializer.class)
    @Column(name = "last_arrived_time")
    public Date getLastArrivedTime() {
        return lastArrivedTime;
    }

    public void setLastArrivedTime(Date lastArrivedTime) {
        this.lastArrivedTime = lastArrivedTime;
    }

    @Column(name = "acked_user")
    public String getAckedUser() {
        return ackedUser;
    }

    public void setAckedUser(String ackedUser) {
        this.ackedUser = ackedUser;
    }

    @Column(name = "acked_time")
    public Date getAckedTime() {
        return ackedTime;
    }

    public void setAckedTime(Date ackedTime) {
        this.ackedTime = ackedTime;
    }

    @Column(name = "paras")
    public String getParas() {
        return paras;
    }

    public void setParas(String paras) {
        this.paras = paras;
    }

    @Column(name = "cleared_user")
    public String getClearedUser() {
        return clearedUser;
    }

    public void setClearedUser(String clearedUser) {
        this.clearedUser = clearedUser;
    }

    @Column(name = "cleared_time")
    public Date getClearedTime() {
        return clearedTime;
    }

    public void setClearedTime(Date clearedTime) {
        this.clearedTime = clearedTime;
    }

    @Column(name = "status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @ManyToOne(targetEntity = com.tplink.nms.alarms.domain.AlarmConf.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "alarm_sn")
    public AlarmConf getAlarmConf() {
        return alarmConf;
    }

    public void setAlarmConf(AlarmConf alarmConf) {
        this.alarmConf = alarmConf;
    }

    @Transient
    public Boolean isAcked() {
        return (status.equals("ANC") || status.equals("AC"));
    }
    @Transient
    public Boolean isCleared() {
        return (status.equals("NAC") || status.equals("AC"));
    }

}
