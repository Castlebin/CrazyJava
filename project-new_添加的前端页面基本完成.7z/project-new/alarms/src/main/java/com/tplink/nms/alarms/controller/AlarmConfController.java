package com.tplink.nms.alarms.controller;

import com.tplink.nms.alarms.domain.AlarmConf;
import com.tplink.nms.alarms.service.AlarmConfService;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/alarms")
public class AlarmConfController {

    @Autowired
    private AlarmConfService alarmConfService;

    @RequestMapping("/alarm-conf")
    public String alarmConf() {
        return "/alarms/alarm-conf";
    }

    @ResponseBody
    @RequestMapping(value = "/alarm-conf-table", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public Grid<AlarmConf> getAlarmConf(Grid<AlarmConf> grid) {
        alarmConfService.getAlarmConf(grid);
        return grid;
    }

    @ResponseBody
    @RequestMapping(value = "/delete-alarm-conf", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public List<OperationResult> deleteAlarmConf(@RequestBody List<Long> ids){
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        return alarmConfService.deleteAlarmConf(ids);
    }

}
