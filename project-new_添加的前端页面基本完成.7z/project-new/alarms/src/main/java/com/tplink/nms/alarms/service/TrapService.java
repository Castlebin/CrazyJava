package com.tplink.nms.alarms.service;

import com.tplink.nms.alarms.dao.TrapDao;
import com.tplink.nms.alarms.domain.Trap;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TrapService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TrapDao trapDao;

    public Grid<Trap> getTraps(Grid<Trap> grid) {
        return trapDao.getTraps(grid, grid.getQueryConditionList());
    }

    public OperationResult deleteTrap(Long id) {
        try {
            trapDao.deleteTrap(id);
            return new OperationResult("success", "fm.service.global.delete", null);
        } catch (DataAccessException e) {
            logger.error("Delete failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.delete" , id);
    }

    public List<OperationResult> deleteTrap(List<Long> ids) {
        List<OperationResult> operResult = new ArrayList<OperationResult>();
        for(Long id : ids) {
            operResult.add(deleteTrap(id));
        }

        return operResult;
    }
}
