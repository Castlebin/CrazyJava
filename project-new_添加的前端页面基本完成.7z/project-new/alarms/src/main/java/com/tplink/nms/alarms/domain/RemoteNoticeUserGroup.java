package com.tplink.nms.alarms.domain;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "rn_group")
public class RemoteNoticeUserGroup implements Serializable {
    private static final long serialVersionUID = -142113348235226815L;

    private Long id;
    private String name;
    private String desc;
    private List<RemoteNoticeUser> users;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "group_id")
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "desc_info")
    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @OneToMany(fetch = FetchType.EAGER, targetEntity = RemoteNoticeUser.class, cascade = {
            CascadeType.ALL, CascadeType.REMOVE})
    @JoinColumn(name = "group_id")
    @Fetch(FetchMode.SUBSELECT)
    public List<RemoteNoticeUser> getUsers() {
        return users;
    }

    public void setUsers(List<RemoteNoticeUser> users) {
        this.users = users;
    }

}
