/*
 * Copyright (C) 2014 TP-LINK Technologies Co., Ltd. All rights reserved.
 * 
 * Filename: ConnectionException.java
 */

package com.tplink.nms.alarms.exception;

/**
 * @author taozi
 * 
 */

public class ConnectionException extends FMException {
    private static final long   serialVersionUID     = -314696552347341372L;

    private static final String CONNECTION_EXCEPTION = "com.tplink.nms.alarms.mail.connectionFailed";
    
    public ConnectionException() {
        super(CONNECTION_EXCEPTION);
    }
    
    public ConnectionException(String message) {
        super(CONNECTION_EXCEPTION, message);
    }
    
    public ConnectionException(Throwable cause) {
        super(CONNECTION_EXCEPTION, cause);
    }
    
    public ConnectionException(String message, Throwable cause) {
        super(CONNECTION_EXCEPTION, message, cause);
    }
    
}
