package com.tplink.nms.alarms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/alarms")
public class AlarmModuleIndexController {

    @RequestMapping("/index")
    public String getMenu(){
        return "/alarms/index";
    }

}
