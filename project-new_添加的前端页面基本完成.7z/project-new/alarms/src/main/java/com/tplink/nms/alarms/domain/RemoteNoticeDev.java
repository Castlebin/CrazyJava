package com.tplink.nms.alarms.domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "rn_dev")
public class RemoteNoticeDev implements Serializable {
    private static final long serialVersionUID = -9154657472330636383L;

    private Long id;
    private Integer typeTblId;
    private Integer devId;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tbl_id")
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "type_tbl_id")
    public Integer getTypeTblId() {
        return typeTblId;
    }

    public void setTypeTblId(Integer typeTblId) {
        this.typeTblId = typeTblId;
    }

    @Column(name = "dev_id")
    public Integer getDevId() {
        return devId;
    }

    public void setDevId(Integer devId) {
        this.devId = devId;
    }

}
