package com.tplink.nms.alarms.domain;

import com.tplink.nms.mvc.utils.JsonDateSerializer;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "tnt_trap")
public class Trap implements Serializable {
    private static final long serialVersionUID = 4472954411519214000L;

    private Long id;
    private Date receiveTime;   // 接收到Trap的时间
    private String trapVersion;
    private String devIp;
    private Integer devId;
    private String paras;
    private Integer enterpriseId;
    private String trapType;
    private String trapOid;
    private Integer genericId;
    private Integer specificId;
    private String systemTime;  // Trap报文中的系统启动时间

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "trap_id")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @JsonSerialize(using=JsonDateSerializer.class)
    @Column(name = "receive_time")
    public Date getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(Date receiveTime) {
        this.receiveTime = receiveTime;
    }

    @Column(name = "trap_version")
    public String getTrapVersion() {
        return trapVersion;
    }

    public void setTrapVersion(String trapVersion) {
        this.trapVersion = trapVersion;
    }

    @Column(name = "dev_ip")
    public String getDevIp() {
        return devIp;
    }

    public void setDevIp(String devIp) {
        this.devIp = devIp;
    }

    @Column(name = "paras")
    public String getParas() {
        return paras;
    }

    public void setParas(String paras) {
        this.paras = paras;
    }

    @Column(name = "enterprise_id")
    public Integer getEnterpriseId() {
        return enterpriseId;
    }

    public void setEnterpriseId(Integer enterpriseId) {
        this.enterpriseId = enterpriseId;
    }

    @Column(name = "trap_oid")
    public String getTrapOid() {
        return trapOid;
    }

    public void setTrapOid(String trapOid) {
        this.trapOid = trapOid;
    }

    @Column(name = "generic_id")
    public Integer getGenericId() {
        return genericId;
    }

    public void setGenericId(Integer genericId) {
        this.genericId = genericId;
    }

    @Column(name = "specific_id")
    public Integer getSpecificId() {
        return specificId;
    }

    public void setSpecificId(Integer specificId) {
        this.specificId = specificId;
    }

    @Column(name = "trap_type")
    public String getTrapType() {
        return trapType;
    }

    public void setTrapType(String trapType) {
        this.trapType = trapType;
    }

    @Column(name = "dev_id")
    public Integer getDevId() {
        return devId;
    }

    public void setDevId(Integer devId) {
        this.devId = devId;
    }

    @Column(name = "system_time")
    public String getSystemTime() {
        return systemTime;
    }

    public void setSystemTime(String systemTime) {
        this.systemTime = systemTime;
    }
}
