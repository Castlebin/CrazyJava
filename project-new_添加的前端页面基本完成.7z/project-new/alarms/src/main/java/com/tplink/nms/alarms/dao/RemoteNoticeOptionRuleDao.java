package com.tplink.nms.alarms.dao;

import com.tplink.nms.alarms.domain.RemoteNoticeOptionRule;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public class RemoteNoticeOptionRuleDao extends BaseDao<RemoteNoticeOptionRule> {

    public Grid getRemoteNoticeOptionRule(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(FilterHql.getFilterHql(RemoteNoticeOptionRule.class, filter), grid);
    }

    public void deleteRemoteNoticeOptionRule(Long id) {
        RemoteNoticeOptionRule rnRule = new RemoteNoticeOptionRule();
        rnRule.setId(id);

        delete(rnRule);
    }
}
