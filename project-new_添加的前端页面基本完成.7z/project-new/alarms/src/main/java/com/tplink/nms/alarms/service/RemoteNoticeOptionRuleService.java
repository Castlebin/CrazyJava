package com.tplink.nms.alarms.service;

import com.tplink.nms.alarms.dao.RemoteNoticeOptionRuleDao;
import com.tplink.nms.alarms.domain.RemoteNoticeOptionRule;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RemoteNoticeOptionRuleService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private RemoteNoticeOptionRuleDao remoteNoticeOptionRuleDao;

    public Grid<RemoteNoticeOptionRule> getRemoteNoticeOptionRule(Grid<RemoteNoticeOptionRule> grid) {
        return remoteNoticeOptionRuleDao.getRemoteNoticeOptionRule(grid, grid.getQueryConditionList());
    }

    public List<OperationResult> deleteRemoteNoticeOptionRule(List<Long> ids) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(deleteRemoteNoticeOptionRule(id));
        }

        return operResult;
    }

    private OperationResult deleteRemoteNoticeOptionRule(Long id) {
        try {
            remoteNoticeOptionRuleDao.deleteRemoteNoticeOptionRule(id);
            return new OperationResult("success", "fm.service.global.delete", null);
        } catch (DataAccessException e) {
            logger.error("Delete failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

    public List<OperationResult> enableRemoteNoticeOptionRule(List<Long> ids) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(enableRemoteNoticeOptionRule(id));
        }

        return operResult;
    }

    private OperationResult enableRemoteNoticeOptionRule(Long id) {
        try {
            RemoteNoticeOptionRule rule = remoteNoticeOptionRuleDao.get(id);
            rule.setEnable(1);
            remoteNoticeOptionRuleDao.update(rule);
            return new OperationResult("success", "fm.service.global.update", null);
        } catch (DataAccessException e) {
            logger.error("Enable failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

    public List<OperationResult> disableRemoteNoticeOptionRule(List<Long> ids) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(disableRemoteNoticeOptionRule(id));
        }

        return operResult;
    }

    private OperationResult disableRemoteNoticeOptionRule(Long id) {
        try {
            RemoteNoticeOptionRule rule = remoteNoticeOptionRuleDao.get(id);
            rule.setEnable(0);
            remoteNoticeOptionRuleDao.update(rule);
            return new OperationResult("success", "fm.service.global.update", null);
        } catch (DataAccessException e) {
            logger.error("Disable failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

}
