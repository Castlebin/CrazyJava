package com.tplink.nms.alarms.dao;

import com.tplink.nms.alarms.domain.HistoryAlarm;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public class HistoryAlarmDao extends BaseDao<HistoryAlarm> {

    public Grid getHistoryAlarm(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(FilterHql.getFilterHql(HistoryAlarm.class, filter), grid);
    }

    public void deleteHistoryAlarm(Long id) {
        HistoryAlarm tmp = new HistoryAlarm();
        tmp.setId(id);

        delete(tmp);
    }
}
