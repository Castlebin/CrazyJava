package com.tplink.nms.alarms.controller;

import com.tplink.nms.alarms.domain.HistoryAlarm;
import com.tplink.nms.alarms.service.HistoryAlarmService;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/alarms")
public class HistoryAlarmController {

    @Autowired
    private HistoryAlarmService historyAlarmService;

    @RequestMapping("/history-alarm")
    public String historyAlarm() {
        return "/alarms/history-alarm";
    }

    @ResponseBody
    @RequestMapping(value = "/history-alarm-table", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public Grid<HistoryAlarm> getHistoryAlarm(Grid<HistoryAlarm> grid) {
        historyAlarmService.getHistoryAlarm(grid);
        return grid;
    }

    @ResponseBody
    @RequestMapping(value = "/delete-history-alarm", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public List<OperationResult> deleteHistoryAlarm(@RequestBody List<Long> ids){
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        return historyAlarmService.deleteHistoryAlarm(ids);
    }

    @ResponseBody
    @RequestMapping(value = "/ack-history-alarm", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public List<OperationResult> ackHistoryAlarm(@RequestBody List<Long> ids){
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        String userName = "system"; // must get user from session here

        if (userName == null) {
            operationResult.add(new OperationResult("fail", "fm.service.alarm.userName.unknown", "Not Login!"));
            return operationResult;
        }

        return historyAlarmService.ackHistoryAlarm(ids, userName);
    }

    @ResponseBody
    @RequestMapping(value = "/disack-history-alarm", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public List<OperationResult> disAckHistoryAlarm(@RequestBody List<Long> ids){
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        String userName = "system"; // must get user from session here

        if (userName == null) {
            operationResult.add(new OperationResult("fail", "fm.service.alarm.userName.unknown", "Not Login!"));
            return operationResult;
        }

        return historyAlarmService.disAckHistoryAlarm(ids, userName);
    }

}
