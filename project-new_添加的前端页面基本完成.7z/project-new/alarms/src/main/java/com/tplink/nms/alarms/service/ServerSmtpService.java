package com.tplink.nms.alarms.service;

import com.tplink.nms.alarms.dao.ServerSmtpDao;
import com.tplink.nms.alarms.domain.ServerSmtp;
import com.tplink.nms.alarms.util.MailUtil;
import com.tplink.nms.mvc.bean.OperationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

@Service
public class ServerSmtpService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ServerSmtpDao serverSmtpDao;

    public ServerSmtp getServerSmtp() {
        return serverSmtpDao.getServerSmtp();
    }

    public OperationResult setServerSmtp(ServerSmtp serverSmtp) {
        try {
            serverSmtp.setId(1l);
            serverSmtpDao.saveOrUpdate(serverSmtp);

            return new OperationResult("success", "", null);
        } catch (DataAccessException e) {
            logger.error("Set Server SMTP failed.");
        }

        return new OperationResult("fail","fm.service.global.fail" , null);
    }

    public OperationResult testServerSmtp(ServerSmtp serverSmtp) {
        try {
            boolean result = MailUtil.testSmtp(serverSmtp);

            return result==true? OperationResult.DEFAULT_SUCCESS : OperationResult.DEFAULT_FAIL;
        } catch (Exception e) {
            logger.error("Test Server SMTP failed.");
        }

        return OperationResult.DEFAULT_FAIL;
    }
}
