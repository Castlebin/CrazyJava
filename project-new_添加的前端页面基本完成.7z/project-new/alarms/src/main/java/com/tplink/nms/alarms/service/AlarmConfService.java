package com.tplink.nms.alarms.service;

import com.tplink.nms.alarms.dao.AlarmConfDao;
import com.tplink.nms.alarms.domain.AlarmConf;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AlarmConfService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AlarmConfDao alarmConfDao;

    public Grid<AlarmConf> getAlarmConf(Grid<AlarmConf> grid) {
        return alarmConfDao.getAlarmConf(grid, grid.getQueryConditionList());
    }

    public OperationResult deleteAlarmConf(Long id) {
        try {
            alarmConfDao.deleteAlarmConf(id);
            return new OperationResult("success", "fm.service.global.delete", null);
        } catch (DataAccessException e) {
            logger.error("Delete failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

    public List<OperationResult> deleteAlarmConf(List<Long> ids) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(deleteAlarmConf(id));
        }

        return operResult;
    }

}
