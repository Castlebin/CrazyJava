package com.tplink.nms.alarms.controller;

import com.tplink.nms.alarms.domain.RemoteNoticeUserGroup;
import com.tplink.nms.alarms.service.RemoteNoticeGroupService;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/alarms")
public class RemoteNoticeGroupController {

    @Autowired
    private RemoteNoticeGroupService remoteNoticeGroupService;

    @RequestMapping("/rn-group")
    public String remoteNoticeGroup() {
        return "/alarms/rn-group";
    }

    @ResponseBody
    @RequestMapping(value = "/rn-group-table", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public Grid<RemoteNoticeUserGroup> getRemoteNoticeGroup(Grid<RemoteNoticeUserGroup> grid) {
        remoteNoticeGroupService.getRemoteNoticeGroup(grid);
        return grid;
    }

    @ResponseBody
    @RequestMapping(value = "/delete-rn-group", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public List<OperationResult> deleteRemoteNoticeGroup(@RequestBody List<Long> ids){
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        return remoteNoticeGroupService.deleteRemoteNoticeGroup(ids);
    }

    @ResponseBody
    @RequestMapping(value = "/edit-rn-group", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public OperationResult editRemoteNoticeGroup(@RequestBody RemoteNoticeUserGroup remoteNoticeUserGroup) {
        String rnGroupName = remoteNoticeUserGroup.getName();
        if(rnGroupName == null || rnGroupName.trim().equals("")) {
            return new OperationResult("fail", "fm.ui.global.param", null);
        }

        return remoteNoticeGroupService.editRemoteNoticeGroup(remoteNoticeUserGroup);
    }

}
