package com.tplink.nms.alarms.service;

import com.tplink.nms.alarms.dao.HistoryAlarmDao;
import com.tplink.nms.alarms.domain.HistoryAlarm;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@Service
public class HistoryAlarmService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private HistoryAlarmDao historyAlarmDao;

    public Grid<HistoryAlarm> getHistoryAlarm(Grid<HistoryAlarm> grid) {
        return historyAlarmDao.getHistoryAlarm(grid, grid.getQueryConditionList());
    }

    public List<OperationResult> deleteHistoryAlarm(List<Long> ids) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(deleteHistoryAlarm(id));
        }

        return operResult;
    }

    private OperationResult deleteHistoryAlarm(Long id) {
        try {
            historyAlarmDao.deleteHistoryAlarm(id);
            return new OperationResult("success", "fm.service.global.delete", null);
        } catch (DataAccessException e) {
            logger.error("Delete failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

    public List<OperationResult> ackHistoryAlarm(List<Long> ids, String userName) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(ackHistoryAlarm(id, userName));
        }

        return operResult;
    }

    private OperationResult ackHistoryAlarm(Long id, String userName) {
        try {
            HistoryAlarm historyAlarm = historyAlarmDao.get(id);
            if (historyAlarm.isAcked() == true) {
                logger.info("Alarm already been acked: {}.", id);
                return new OperationResult("info", "fm.service.alarm.status.isAcked", id);
            }
            Calendar ca = Calendar.getInstance();
            historyAlarm.setAckedTime(ca.getTime());
            historyAlarm.setAckedUser(userName);
            if (historyAlarm.getStatus().equals("NAC")) {
                historyAlarm.setStatus("AC");
            } else if (historyAlarm.getStatus().equals("NANC")) {
                historyAlarm.setStatus("ANC");
            }
            historyAlarmDao.update(historyAlarm);

            return new OperationResult("success", "fm.service.global.update", null);
        } catch (DataAccessException e) {
            logger.error("Acknowledge failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

    public List<OperationResult> disAckHistoryAlarm(List<Long> ids, String userName) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(disAckHistoryAlarm(id, userName));
        }

        return operResult;
    }

    private OperationResult disAckHistoryAlarm(Long id, String userName) {
        try {
            HistoryAlarm historyAlarm = historyAlarmDao.get(id);
            if (historyAlarm.isAcked() == false) {
                logger.warn("Alarm has not acked  {}", id);
                return new OperationResult("info", "fm.service.alarm.status.isNotAcked", id);
            }
            if (!userName.equals(historyAlarm.getAckedUser())) {
                return new OperationResult("fail", "fm.service.alarm.username.ackedByOtherUser", null);
            }
            historyAlarm.setAckedTime(null);
            historyAlarm.setAckedUser(null);
            if (historyAlarm.getStatus().equals("AC")) {
                historyAlarm.setStatus("NAC");
            } else if (historyAlarm.getStatus().equals("ANC")) {
                historyAlarm.setStatus("NANC");
            }
            historyAlarmDao.update(historyAlarm);

            return new OperationResult("success", "fm.service.global.update", null);
        } catch (DataAccessException e) {
            logger.error("Dis Acknowledge failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

}
