package com.tplink.nms.alarms.controller;

import com.tplink.nms.alarms.domain.CurrentAlarm;
import com.tplink.nms.alarms.service.CurrentAlarmService;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/alarms")
public class CurrentAlarmController {

    @Autowired
    private CurrentAlarmService currentAlarmService;

    @RequestMapping("/current-alarm")
    public String currentAlarm() {
        return "/alarms/current-alarm";
    }

    @ResponseBody
    @RequestMapping(value = "/current-alarm-table", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public Grid<CurrentAlarm> getCurrentAlarm(Grid<CurrentAlarm> grid) {
        currentAlarmService.getCurrentAlarm(grid);
        return grid;
    }

    @ResponseBody
    @RequestMapping(value = "/ack-current-alarm", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public List<OperationResult> ackCurrentAlarm(@RequestBody List<Long> ids){
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        String userName = "system"; // must get user from session here

        if (userName == null) {
            operationResult.add(new OperationResult("fail", "fm.service.alarm.userName.unknown", "Not Login!"));
            return operationResult;
        }

        return currentAlarmService.ackCurrentAlarm(ids, userName);
    }

    @ResponseBody
    @RequestMapping(value = "/disack-current-alarm", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public List<OperationResult> disAckCurrentAlarm(@RequestBody List<Long> ids){
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        String userName = "system"; // must get user from session here

        if (userName == null) {
            operationResult.add(new OperationResult("fail", "fm.service.alarm.userName.unknown", "Not Login!"));
            return operationResult;
        }

        return currentAlarmService.disAckCurrentAlarm(ids, userName);
    }

    @ResponseBody
    @RequestMapping(value = "/clear-current-alarm", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public List<OperationResult> clearCurrentAlarm(@RequestBody List<Long> ids){
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        String userName = "system"; // must get user from session here

        if (userName == null) {
            operationResult.add(new OperationResult("fail", "fm.service.alarm.userName.unknown", "Not Login!"));
            return operationResult;
        }

        return currentAlarmService.clearCurrentAlarm(ids, userName);
    }

}
