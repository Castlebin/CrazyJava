package com.tplink.nms.alarms.dao;

import com.tplink.nms.alarms.domain.RemoteNoticeUserGroup;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public class RemoteNoticeGroupDao extends BaseDao<RemoteNoticeUserGroup> {

    public Grid getRemoteNoticeGroup(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(FilterHql.getFilterHql(RemoteNoticeUserGroup.class, filter), grid);
    }

    public void deleteRemoteNoticeGroup(Long id) {
        RemoteNoticeUserGroup group = new RemoteNoticeUserGroup();
        group.setId(id);

        delete(group);
    }

    public void editRemoteNoticeGroup(RemoteNoticeUserGroup remoteNoticeUserGroup) {
        saveOrUpdate(remoteNoticeUserGroup);
    }
}
