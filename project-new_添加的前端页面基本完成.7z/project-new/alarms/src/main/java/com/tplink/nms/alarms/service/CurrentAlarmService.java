package com.tplink.nms.alarms.service;

import com.tplink.nms.alarms.dao.CurrentAlarmDao;
import com.tplink.nms.alarms.dao.HistoryAlarmDao;
import com.tplink.nms.alarms.domain.CurrentAlarm;
import com.tplink.nms.alarms.domain.HistoryAlarm;
import com.tplink.nms.alarms.util.BeanUtil;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@Service
public class CurrentAlarmService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private CurrentAlarmDao currentAlarmDao;

    @Autowired
    private HistoryAlarmDao historyAlarmDao;

    public Grid<CurrentAlarm> getCurrentAlarm(Grid<CurrentAlarm> grid) {
        return currentAlarmDao.getCurrentAlarm(grid, grid.getQueryConditionList());
    }

    public List<OperationResult> ackCurrentAlarm(List<Long> ids, String userName) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(ackCurrentAlarm(id, userName));
        }

        return operResult;
    }

    private OperationResult ackCurrentAlarm(Long id, String userName) {
        try {
            CurrentAlarm currentAlarm = currentAlarmDao.get(id);
            if (currentAlarm.isAcked() == true) {
                logger.info("Current alarm already been acked: {}.", id);
                return new OperationResult("info", "fm.service.alarm.status.isAcked", id);
            }
            Calendar ca = Calendar.getInstance();
            currentAlarm.setAckedTime(ca.getTime());
            currentAlarm.setAckedUser(userName);
            if (currentAlarm.getStatus().equals("NAC")) {
                currentAlarm.setStatus("AC");
            } else if (currentAlarm.getStatus().equals("NANC")) {
                currentAlarm.setStatus("ANC");
            }
            currentAlarmDao.update(currentAlarm);

            return new OperationResult("success", "fm.service.alarm.ack", null);
        } catch (DataAccessException e) {
            logger.error("Acknowledge failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

    public List<OperationResult> disAckCurrentAlarm(List<Long> ids, String userName) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(disAckCurrentAlarm(id, userName));
        }

        return operResult;
    }

    private OperationResult disAckCurrentAlarm(Long id, String userName) {
        try {
            CurrentAlarm currentAlarm = currentAlarmDao.get(id);
            if (currentAlarm.isAcked() == false) {
                logger.info("Current Alarm is not acked {}", id);
                return new OperationResult("info", "fm.service.alarm.status.isNotAcked", id);
            }
            if (!userName.equals(currentAlarm.getAckedUser())) {
                return new OperationResult("fail", "fm.service.alarm.username.ackedByOtherUser", null);
            }
            currentAlarm.setAckedTime(null);
            currentAlarm.setAckedUser(null);
            if (currentAlarm.getStatus().equals("AC")) {
                currentAlarm.setStatus("NAC");
            } else if (currentAlarm.getStatus().equals("ANC")) {
                currentAlarm.setStatus("NANC");
            }
            currentAlarmDao.update(currentAlarm);

            return new OperationResult("success", "fm.service.global.update", null);
        } catch (DataAccessException e) {
            logger.error("Dis Acknowledge failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

    public List<OperationResult> clearCurrentAlarm(List<Long> ids, String userName) {
        List<OperationResult> operResult = new ArrayList<>();
        for(Long id : ids) {
            operResult.add(clearCurrentAlarm(id, userName));
        }

        return operResult;
    }

    private OperationResult clearCurrentAlarm(Long id, String userName) {
        try {
            CurrentAlarm currentAlarm = currentAlarmDao.get(id);
            if (currentAlarm.isCleared() == true) {
                logger.info("Alarm already been cleared {}", id);
                return new OperationResult("fail", "fm.service.alarm.status.isCleared", id);
            }

            Calendar ca = Calendar.getInstance();
            currentAlarm.setClearedTime(ca.getTime());
            currentAlarm.setClearedUser(userName);

            if (currentAlarm.getStatus().equals("ANC")) {
                currentAlarm.setStatus("AC");
            } else if (currentAlarm.getStatus().equals("NANC")) {
                currentAlarm.setStatus("NAC");
            }

            currentAlarmDao.delete(currentAlarm);
            HistoryAlarm historyAlarm = BeanUtil.currentAlarmToHistory(currentAlarm);
            historyAlarmDao.add(historyAlarm);

            // TODO 发送事件提示
    /*
        Alarm alarm = new Alarm(historyAlarm);
        AlarmNotificationImpl notification = new AlarmNotificationImpl();
        notification.notifyAlarm(alarm);    */

            return new OperationResult("success", "fm.service.alarm.clear", null);
        } catch (DataAccessException e) {
            logger.error("Clear failed: {}.", id);
        }

        return new OperationResult("fail","fm.service.global.fail" , id);
    }

}
