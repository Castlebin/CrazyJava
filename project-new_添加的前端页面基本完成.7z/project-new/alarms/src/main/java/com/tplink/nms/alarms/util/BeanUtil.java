package com.tplink.nms.alarms.util;

import com.tplink.nms.alarms.domain.CurrentAlarm;
import com.tplink.nms.alarms.domain.HistoryAlarm;

public class BeanUtil {
    public static HistoryAlarm currentAlarmToHistory(CurrentAlarm currentAlarm) {
        HistoryAlarm historyAlarm = new HistoryAlarm();

        historyAlarm.setCount(currentAlarm.getCount());
        historyAlarm.setDevId(currentAlarm.getDevId());
        historyAlarm.setDevTypeId(currentAlarm.getDevTypeId());
        historyAlarm.setDevIp(currentAlarm.getDevIp());
        historyAlarm.setDevName(currentAlarm.getDevName());
        historyAlarm.setFaultTime(currentAlarm.getFaultTime());
        historyAlarm.setLastArrivedTime(currentAlarm.getLastArrivedTime());
        historyAlarm.setAckedUser(currentAlarm.getAckedUser());
        historyAlarm.setAckedTime(currentAlarm.getAckedTime());
        historyAlarm.setClearedTime(currentAlarm.getClearedTime());
        historyAlarm.setClearedUser(currentAlarm.getClearedUser());
        historyAlarm.setParas(currentAlarm.getParas());
        historyAlarm.setStatus(currentAlarm.getStatus());
        historyAlarm.setAlarmConf(currentAlarm.getAlarmConf());

        return historyAlarm;
    }

}
