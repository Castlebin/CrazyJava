package com.tplink.nms.alarms.dao;

import com.tplink.nms.alarms.domain.Trap;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public class TrapDao extends BaseDao<Trap> {

    public Grid getTraps(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(FilterHql.getFilterHql(Trap.class, filter), grid);
    }

    public Trap getTrapById(Integer id) {
        return get(id);
    }

    public void deleteTrap(Long id) {
        Trap trap = new Trap();
        trap.setId(id);

        delete(trap);
    }

}
