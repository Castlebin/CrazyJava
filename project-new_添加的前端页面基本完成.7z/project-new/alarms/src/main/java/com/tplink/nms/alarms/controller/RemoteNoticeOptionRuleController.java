package com.tplink.nms.alarms.controller;

import com.tplink.nms.alarms.domain.RemoteNoticeOptionRule;
import com.tplink.nms.alarms.service.RemoteNoticeOptionRuleService;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/alarms")
public class RemoteNoticeOptionRuleController {

    @Autowired
    private RemoteNoticeOptionRuleService remoteNoticeOptionRuleService;

    @RequestMapping("/rn-rule")
    public String remoteNoticeRule() {
        return "/alarms/rn-rule";
    }

    @ResponseBody
    @RequestMapping(value = "/rn-rule-table", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public Grid<RemoteNoticeOptionRule> getRemoteNoticeOptionRule(Grid<RemoteNoticeOptionRule> grid) {
        remoteNoticeOptionRuleService.getRemoteNoticeOptionRule(grid);
        return grid;
    }

    @RequestMapping(value = "/delete-rn-rule", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    @ResponseBody
    public List<OperationResult> deleteRemoteNoticeOptionRule(@RequestBody List<Long> ids) {
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        return remoteNoticeOptionRuleService.deleteRemoteNoticeOptionRule(ids);
    }

    @RequestMapping(value = "/enable-rn-rule", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    @ResponseBody
    public List<OperationResult> enableRemoteNoticeOptionRule(@RequestBody List<Long> ids) {
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        return remoteNoticeOptionRuleService.enableRemoteNoticeOptionRule(ids);
    }

    @RequestMapping(value = "/disable-rn-rule", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    @ResponseBody
    public List<OperationResult> disableRemoteNoticeOptionRule(@RequestBody List<Long> ids) {
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        return remoteNoticeOptionRuleService.disableRemoteNoticeOptionRule(ids);
    }

}
