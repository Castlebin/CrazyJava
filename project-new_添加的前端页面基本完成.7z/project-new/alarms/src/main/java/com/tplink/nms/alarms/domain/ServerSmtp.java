package com.tplink.nms.alarms.domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "server_smtp")
public class ServerSmtp implements Serializable {
    private static final long serialVersionUID = -5612200607591919830L;

    private Long id;
    private String smtpServer;
    private Integer port;
    private String sender;
    private String password;
    private String userName;
    private boolean sslEnable;
    private boolean authEnable;
    private boolean checked;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @Column(name = "tbl_id")
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "smtp_server")
    public String getSmtpServer() {
        return smtpServer;
    }

    public void setSmtpServer(String smtpServer) {
        this.smtpServer = smtpServer;
    }

    @Column(name = "port")
    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    @Column(name = "sender")
    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    @Column(name = "username")
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Column(name = "password")
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Column(name = "ssl_enable")
    public boolean isSslEnable() {
        return sslEnable;
    }

    public void setSslEnable(boolean sslEnable) {
        this.sslEnable = sslEnable;
    }

    @Column(name = "auth_enable")
    public boolean isAuthEnable() {
        return authEnable;
    }

    public void setAuthEnable(boolean authEnable) {
        this.authEnable = authEnable;
    }

    @Column(name = "checked")
    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

}
