package com.tplink.nms.alarms.domain;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "rn_dev_type")
public class RemoteNoticeDevType implements Serializable {
    private static final long serialVersionUID = -9154657472330636383L;

    private Long id;
    private Integer optionId;
    private Integer devTypeId;

    private List<RemoteNoticeDev> devs;
    private List<RemoteNoticeDevAlarm> alarms;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tbl_id")
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "option_id")
    public Integer getOptionId() {
        return optionId;
    }

    public void setOptionId(Integer optionId) {
        this.optionId = optionId;
    }

    @Column(name = "dev_type_id")
    public Integer getDevTypeId() {
        return devTypeId;
    }

    public void setDevTypeId(Integer devTypeId) {
        this.devTypeId = devTypeId;
    }

    @OneToMany(fetch = FetchType.EAGER, targetEntity = RemoteNoticeDev.class, cascade = {
            CascadeType.ALL, CascadeType.REMOVE})
    @Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
    @JoinColumn(name = "type_tbl_id")
    public List<RemoteNoticeDev> getDevs() {
        return devs;
    }

    public void setDevs(List<RemoteNoticeDev> devs) {
        this.devs = devs;
    }

    @OneToMany(fetch = FetchType.EAGER, targetEntity = RemoteNoticeDevAlarm.class, cascade = {
            CascadeType.ALL, CascadeType.REMOVE})
    @Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
    @JoinColumn(name = "type_tbl_id")
    @Fetch(FetchMode.SUBSELECT)
    public List<RemoteNoticeDevAlarm> getAlarms() {
        return alarms;
    }

    public void setAlarms(List<RemoteNoticeDevAlarm> alarms) {
        this.alarms = alarms;
    }

}
