package com.tplink.nms.alarms.domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "rn_dev_alarm")
public class RemoteNoticeDevAlarm implements Serializable {
    private static final long serialVersionUID = -8432069197524794315L;

    private Long id;
    private Long alarmSn;
    private Integer typeTblId;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tbl_id")
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "alarm_sn")
    public Long getAlarmSn() {
        return alarmSn;
    }

    public void setAlarmSn(Long alarmSn) {
        this.alarmSn = alarmSn;
    }

    @Column(name = "type_tbl_id")
    public Integer getTypeTblId() {
        return typeTblId;
    }


    public void setTypeTblId(Integer typeTblId) {
        this.typeTblId = typeTblId;
    }

}
