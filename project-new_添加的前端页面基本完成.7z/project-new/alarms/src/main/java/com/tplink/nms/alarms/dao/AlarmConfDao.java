package com.tplink.nms.alarms.dao;

import com.tplink.nms.alarms.domain.AlarmConf;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public class AlarmConfDao extends BaseDao<AlarmConf> {

    public Grid getAlarmConf(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(FilterHql.getFilterHql(AlarmConf.class, filter), grid);
    }

    public void deleteAlarmConf(Long id) {
        AlarmConf tmp = new AlarmConf();
        tmp.setId(id);

        delete(tmp);
    }
}
