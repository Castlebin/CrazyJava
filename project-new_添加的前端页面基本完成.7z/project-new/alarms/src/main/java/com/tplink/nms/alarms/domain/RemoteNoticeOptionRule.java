package com.tplink.nms.alarms.domain;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "rn_option_rule")
public class RemoteNoticeOptionRule implements Serializable {
    private static final long serialVersionUID = -4070421612811941025L;

    private Long id;
    private String name;
    private Integer enable;
    private Integer severitytotal;
    private Integer sendCleared;

    private List<RemoteNoticeUserGroup> groups;
    private List<RemoteNoticeDevType> devTypes;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "option_id")
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "enable")
    public Integer getEnable() {
        return enable;
    }

    public void setEnable(Integer enable) {
        this.enable = enable;
    }

    @Column(name = "severitytotal")
    public Integer getSeveritytotal() {
        return severitytotal;
    }

    public void setSeveritytotal(Integer severitytotal) {
        this.severitytotal = severitytotal;
    }

    @Column(name = "sendcleared")
    public Integer getSendCleared() {
        return sendCleared;
    }

    public void setSendCleared(Integer sendCleared) {
        this.sendCleared = sendCleared;
    }

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @JoinTable(name = "rn_rule_group", inverseJoinColumns = @JoinColumn(name = "group_id"), joinColumns = @JoinColumn(name = "option_id"))
    public List<RemoteNoticeUserGroup> getGroups() {
        return groups;
    }

    public void setGroups(List<RemoteNoticeUserGroup> groups) {
        this.groups = groups;
    }

    @OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.ALL, CascadeType.REMOVE},
            targetEntity = RemoteNoticeDevType.class)
    @Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
    @JoinColumn(name = "option_id")
    @Fetch(FetchMode.SUBSELECT)
    public List<RemoteNoticeDevType> getDevTypes() {
        return devTypes;
    }

    public void setDevTypes(List<RemoteNoticeDevType> devTypes) {
        this.devTypes = devTypes;
    }

}
