/*
 * Copyright (C) 2014 TP-LINK Technologies Co., Ltd. All rights reserved.
 * 
 * Filename: FMException.java
 */

package com.tplink.nms.alarms.exception;

/**
 * @author taozi
 * 
 */

public class FMException extends Exception {
    private static final long serialVersionUID = 227700860836788980L;
    
    private String            id;
    
    public FMException() {
        super("");
    }
    
    public FMException(String message) {
        super(message);
    }
    
    public FMException(Throwable cause) {
        super(cause);
    }
    
    public FMException(String id, Throwable cause) {
        super(cause);
        setId(id);
    }
    
    public FMException(String id, String message) {
        super(message);
        setId(id);
    }
    
    public FMException(String id, String message, Throwable cause) {
        super(message, cause);
        setId(id);
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
}
