package com.tplink.nms.alarms.controller;

import com.tplink.nms.alarms.domain.Trap;
import com.tplink.nms.alarms.service.TrapService;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.OperationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/alarms")
public class TrapController {

    @Autowired
    private TrapService trapService;

    @RequestMapping("/trap")
    public String trap() {
        return "/alarms/trap";
    }

    @ResponseBody
    @RequestMapping(value = "/trap-table", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public Grid<Trap> getTraps(Grid<Trap> grid) {
        trapService.getTraps(grid);
        return grid;
    }

    @ResponseBody
    @RequestMapping(value = "/delete-trap", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public List<OperationResult> deleteTrap(@RequestBody List<Long> ids){
        List<OperationResult> operationResult = new ArrayList<>();
        if(ids == null || ids.size() < 1) {
            operationResult.add(new OperationResult("fail", "fm.ui.global.param", null));
            return operationResult;
        }

        return trapService.deleteTrap(ids);
    }

}
