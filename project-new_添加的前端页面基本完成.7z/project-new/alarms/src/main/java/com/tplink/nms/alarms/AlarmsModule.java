package com.tplink.nms.alarms;

import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;

public class AlarmsModule extends AbstractModule {
    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
    }
}
