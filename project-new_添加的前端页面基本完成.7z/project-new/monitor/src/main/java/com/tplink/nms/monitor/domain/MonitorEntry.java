package com.tplink.nms.monitor.domain;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import javax.persistence.*;
import java.util.Set;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_monitor_entry")
public class MonitorEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "`name`")
    private String name;

    @Column(name = "`describe`")
    private String describe;

    @Column(name = "enabled")
    private boolean enabled;

    @Column(name = "type")
    private String type;

    @Column(name = "`interval`")
    private int interval;

    @Column(name = "interval_type")
    private int intervalType;

    @Column(name = "device_all")
    private boolean deviceAll;
/*
    @OneToMany(targetEntity = EntryDeviceRel.class, fetch = FetchType.EAGER, mappedBy = "entryId")
    @Cascade(value = CascadeType.DELETE)
    private Set<EntryDeviceRel> entryDeviceRel;

    @OneToMany(targetEntity = EntryGroupRel.class, fetch = FetchType.EAGER, mappedBy = "entryId")
    @Cascade(value = CascadeType.DELETE)
    private Set<EntryGroupRel> entryGroupRels;

    @OneToMany(targetEntity = EntryIndicatorRel.class, fetch = FetchType.EAGER, mappedBy = "entryId")
    @Cascade(value = CascadeType.DELETE)
    private Set<EntryIndicatorRel> entryIndicatorRels;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }*/

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getInterval() {
        return interval;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }

    public int getIntervalType() {
        return intervalType;
    }

    public void setIntervalType(int intervalType) {
        this.intervalType = intervalType;
    }

/*    public void setEntryInterval(EntryInterval interval) {
        this.interval = interval.getInterval();
        this.intervalType = interval.getType().getValue();
    }

    public EntryInterval getEntryInterval() {
        return new EntryInterval(interval, EntryInterval.Type.valueOf(intervalType));
    }

    public Set<EntryDeviceRel> getEntryDeviceRel() {
        return entryDeviceRel;
    }

    public void setEntryDeviceRel(Set<EntryDeviceRel> entryDeviceRel) {
        this.entryDeviceRel = entryDeviceRel;
    }

    public Set<EntryIndicatorRel> getEntryIndicatorRels() {
        return entryIndicatorRels;
    }

    public void setEntryIndicatorRels(Set<EntryIndicatorRel> entryIndicatorRels) {
        this.entryIndicatorRels = entryIndicatorRels;
    }

    public Set<EntryGroupRel> getEntryGroupRels() {
        return entryGroupRels;
    }

    public void setEntryGroupRels(Set<EntryGroupRel> entryGroupRels) {
        this.entryGroupRels = entryGroupRels;
    }

    public boolean isDeviceAll() {
        return deviceAll;
    }

    public void setDeviceAll(boolean deviceAll) {
        this.deviceAll = deviceAll;
    }*/
}
