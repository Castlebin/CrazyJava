package com.tplink.nms.monitor.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_monitor_data")
public class MonitorData {

    @Id
    @GeneratedValue
    private int id;

    @ManyToOne(targetEntity = Indicator.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "indicator_id")
    private Indicator indicatorId;

    @Column(name = "dev_id")
    private int devId;

    @Column(name = "`value`")
    private String value;

    @Column(name = "`date`")
    private Date date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDevId() {
        return devId;
    }

    public void setDevId(int devId) {
        this.devId = devId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Indicator getIndicatorId() {
        return indicatorId;
    }

    public void setIndicatorId(Indicator indicatorId) {
        this.indicatorId = indicatorId;
    }
}
