package com.tplink.nms.monitor.domain;

import javax.persistence.*;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_entry_device_rel")
public class EntryDeviceRel {

    @Id
    @GeneratedValue
    private int id;

    @ManyToOne(targetEntity = MonitorEntry.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "entry_id")
    private MonitorEntry entryId;

    @Column(name = "dev_id")
    private int devId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public MonitorEntry getEntryId() {
        return entryId;
    }

    public void setEntryId(MonitorEntry entryId) {
        this.entryId = entryId;
    }

    public int getDevId() {
        return devId;
    }

    public void setDevId(int devId) {
        this.devId = devId;
    }
}
