package com.tplink.nms.monitor.domain;

import com.tplink.nms.i18n.L;

/**
 * @author yuhai
 */
public class EntryInterval {
    private L i18n = L.getInstance(EntryInterval.class);

    public enum Type {
        MIN(1), HOUR(2), DAY(3);

        private int value;

        private Type(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }

        public static Type valueOf(int value) {
            for (Type t : Type.values()) {
                if (t.getValue() == value) {
                    return t;
                }
            }

            throw new IllegalArgumentException("Unknown Type value: " + value);
        }
    }

    private int interval;
    private Type type;

    public EntryInterval(int interval, Type type) {
        this.interval = interval;
        this.type = type;
    }

    public int getInterval() {
        return interval;
    }

    public Type getType() {
        return type;
    }

    public String getI18nType() {
        switch(type) {
            case MIN: return i18n.get("monitor.interval.type.minute");
            case HOUR: return i18n.get("monitor.interval.type.hour");
            case DAY: return i18n.get("monitor.interval.type.day");
            default:
                throw new IllegalStateException("Unknown interval type");
        }
    }
}
