package com.tplink.nms.monitor.domain;

import javax.persistence.*;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_entry_group_rel")
public class EntryGroupRel {

    @Id
    @GeneratedValue
    private int id;

    @ManyToOne(targetEntity = MonitorEntry.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "entry_id")
    private MonitorEntry entryId;

    @Column(name = "group_id")
    private int groupId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public MonitorEntry getEntryId() {
        return entryId;
    }

    public void setEntryId(MonitorEntry entryId) {
        this.entryId = entryId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }
}
