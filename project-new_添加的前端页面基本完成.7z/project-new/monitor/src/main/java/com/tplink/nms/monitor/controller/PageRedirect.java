package com.tplink.nms.monitor.controller;

/**
 * Created by Administrator on 15-5-5.
 */
import com.tplink.nms.monitor.domain.DashboardView;
import com.tplink.nms.monitor.domain.MonitorEntry;
import com.tplink.nms.monitor.service.DashboardViewService;
import com.tplink.nms.monitor.service.MonitorEntryService;
import com.tplink.nms.mvc.bean.Grid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/monitor")
public class PageRedirect {
    private Map<String, String> pageMap;

    public PageRedirect() {
        pageMap = new HashMap<>();

        pageMap.put("index", "monitor/index");
        pageMap.put("topN-devices", "monitor/topN-devices");
        pageMap.put("topN-interfaces", "monitor/topN-interfaces");
        pageMap.put("monitor-entries", "monitor/monitor-entries");
        pageMap.put("dashBoard-view", "monitor/dashBoard-view");
        pageMap.put("test", "monitor/test");
    }

    @RequestMapping(value = "getpage")
    public String getPage(String page) {
        return pageMap.get(page);
    }

    @Autowired
    DashboardViewService dashboardViewService;

    @ResponseBody
    @RequestMapping(value = "/dashboard-view", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Grid<DashboardView> dashboardViewTable(Grid<DashboardView> grid) {
        dashboardViewService.getDashboardViewTemplates(grid);
        return grid;
    }

    @Autowired
    MonitorEntryService monitorEntryService;

    @ResponseBody
    @RequestMapping(value = "/monitor-entries", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Grid<MonitorEntry> monitorEntryTable(Grid<MonitorEntry> grid) {
        monitorEntryService.getMonitorEntryTemplates(grid);
        return grid;
    }
}

