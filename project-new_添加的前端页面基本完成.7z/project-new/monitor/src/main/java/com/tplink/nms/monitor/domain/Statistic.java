/*
 * Copyright (c) 2013-2014 Shenzhen TP-LINK Technologies Co., Ltd.
 */

package com.tplink.nms.monitor.domain;


import org.hibernate.annotations.*;
import org.hibernate.annotations.CascadeType;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Set;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_statistic")
public class Statistic {

    @Id
    @GeneratedValue
    private int id;

    @Column(name = "`name`")
    private String name;

    @Column(name = "`class`")
    private String clazz;

    @Column(name = "entry_type")
    private String entryType;

    @Column(name = "value_name")
    private String valueName;

    @OneToMany(targetEntity = TopNDeviceStatistic.class, fetch = FetchType.LAZY, mappedBy = "statisticId")
    @Cascade(value = CascadeType.DELETE)
    private Set<TopNDeviceStatistic> topNDeviceStatistics;

    @OneToMany(targetEntity = TopNInterfaceStatistic.class, fetch = FetchType.LAZY, mappedBy = "statisticId")
    @Cascade(value = CascadeType.DELETE)
    private Set<TopNInterfaceStatistic> topNInterfaceStatistics;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClazz() {
        return clazz;
    }

    public void setClazz(String clazz) {
        this.clazz = clazz;
    }

    public String getEntryType() {
        return entryType;
    }

    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }

    public String getValueName() {
        return valueName;
    }

    public void setValueName(String valueName) {
        this.valueName = valueName;
    }

    public Set<TopNDeviceStatistic> getTopNDeviceStatistics() {
        return topNDeviceStatistics;
    }

    public void setTopNDeviceStatistics(Set<TopNDeviceStatistic> topNDeviceStatistics) {
        this.topNDeviceStatistics = topNDeviceStatistics;
    }

    public Set<TopNInterfaceStatistic> getTopNInterfaceStatistics() {
        return topNInterfaceStatistics;
    }

    public void setTopNInterfaceStatistics(Set<TopNInterfaceStatistic> topNInterfaceStatistics) {
        this.topNInterfaceStatistics = topNInterfaceStatistics;
    }
}
