/*
 * Copyright (c) 2013-2014 Shenzhen TP-LINK Technologies Co., Ltd.
 */

package com.tplink.nms.monitor.domain;

import org.hibernate.annotations.*;
import org.hibernate.annotations.CascadeType;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Set;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_dashboard_view")
public class DashboardView {

    @Id
    @GeneratedValue
    private int id;

    @Column(name = "`name`")
    private String name;

    @Column(name = "interval_type")
    private int intervalType;

    @Column(name = "`interval`")
    private int interval;

    @Column(name = "`source`")
    private int source;

    @OneToMany(targetEntity = ViewDeviceRel.class, fetch = FetchType.EAGER, mappedBy = "viewId")
    @Cascade({CascadeType.DELETE})
    private Set<ViewDeviceRel> viewDeviceRels;

    @OneToMany(targetEntity = ViewIndicatorRel.class, fetch = FetchType.EAGER, mappedBy = "viewId")
    @Cascade({CascadeType.DELETE})
    private Set<ViewIndicatorRel> viewIndicatorRels;

    @OneToMany(targetEntity = ViewInterfaceRel.class, fetch = FetchType.EAGER, mappedBy = "viewId")
    @Cascade({CascadeType.DELETE})
    private Set<ViewInterfaceRel> viewInterfaceRels;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIntervalType() {
        return intervalType;
    }

    public void setIntervalType(int intervalType) {
        this.intervalType = intervalType;
    }

    public int getInterval() {
        return interval;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }

    public Set<ViewDeviceRel> getViewDeviceRels() {
        return viewDeviceRels;
    }

    public void setViewDeviceRels(Set<ViewDeviceRel> viewDeviceRels) {
        this.viewDeviceRels = viewDeviceRels;
    }

    public Set<ViewIndicatorRel> getViewIndicatorRels() {
        return viewIndicatorRels;
    }

    public void setViewIndicatorRels(Set<ViewIndicatorRel> viewIndicatorRels) {
        this.viewIndicatorRels = viewIndicatorRels;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public Set<ViewInterfaceRel> getViewInterfaceRels() {
        return viewInterfaceRels;
    }

    public void setViewInterfaceRels(Set<ViewInterfaceRel> viewInterfaceRels) {
        this.viewInterfaceRels = viewInterfaceRels;
    }
}
