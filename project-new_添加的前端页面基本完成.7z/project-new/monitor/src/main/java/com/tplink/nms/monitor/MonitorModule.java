package com.tplink.nms.monitor;

/**
 * Created by Administrator on 15-5-4.
 */
import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;

public class MonitorModule extends AbstractModule {
    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
    }
}