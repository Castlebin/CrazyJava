/*
 * Copyright (c) 2013-2014 Shenzhen TP-LINK Technologies Co., Ltd.
 */

package com.tplink.nms.monitor.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_monitor_interface_data")
public class MonitorInterfaceData {

    @Id
    @GeneratedValue
    private int id;

    @ManyToOne(targetEntity = Indicator.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "indicator_id")
    private Indicator indicatorId;

    @Column(name = "dev_id")
    private int devId;

    @Column(name = "dev_if_id")
    private int devIfId;

    @Column(name = "`value`")
    private String value;

    @Column(name = "`date`")
    private Date date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Indicator getIndicatorId() {
        return indicatorId;
    }

    public void setIndicatorId(Indicator indicatorId) {
        this.indicatorId = indicatorId;
    }

    public int getDevId() {
        return devId;
    }

    public void setDevId(int devId) {
        this.devId = devId;
    }

    public int getDevIfId() {
        return devIfId;
    }

    public void setDevIfId(int devIfId) {
        this.devIfId = devIfId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
