package com.tplink.nms.monitor.dao;

import com.tplink.nms.monitor.domain.MonitorEntry;
import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository("MonitorEntryDao")
public class MonitorEntryDao extends BaseDao<MonitorEntry> {

    public Grid getMonitorEntryTemplates(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(FilterHql.getFilterHql(MonitorEntry.class, filter), grid);
    }
}
