/*
 * Copyright (c) 2013-2014 Shenzhen TP-LINK Technologies Co., Ltd.
 */

package com.tplink.nms.monitor.domain;

import javax.persistence.*;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_topn_device_statistic")
public class TopNDeviceStatistic {

    @Id
    @GeneratedValue
    private int id;

    @ManyToOne(targetEntity = Statistic.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "statistic_id")
    private Statistic statisticId;

    @Column(name = "dev_id")
    private int devId;

    @Column(name = "dev_type")
    private String devType;

    @Column(name = "dev_name")
    private String devName;

    @Column(name = "`value`")
    private String value;

    @Column(name = "`top`")
    private int top;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Statistic getStatisticId() {
        return statisticId;
    }

    public void setStatisticId(Statistic statisticId) {
        this.statisticId = statisticId;
    }

    public int getDevId() {
        return devId;
    }

    public void setDevId(int devId) {
        this.devId = devId;
    }

    public String getDevType() {
        return devType;
    }

    public void setDevType(String devType) {
        this.devType = devType;
    }

    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getTop() {
        return top;
    }

    public void setTop(int top) {
        this.top = top;
    }
}
