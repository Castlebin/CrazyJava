/*
 * Copyright (c) 2013-2014 Shenzhen TP-LINK Technologies Co., Ltd.
 */

package com.tplink.nms.monitor.domain;

import javax.persistence.*;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_view_interface_rel")
public class ViewInterfaceRel {

    @Id
    @GeneratedValue
    private int id;

    @ManyToOne(targetEntity = DashboardView.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "view_id")
    private DashboardView viewId;

    @Column(name = "device_id")
    private int deviceId;

    @Column(name = "dev_if_id")
    private int devIfId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public DashboardView getViewId() {
        return viewId;
    }

    public void setViewId(DashboardView viewId) {
        this.viewId = viewId;
    }

    public int getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(int deviceId) {
        this.deviceId = deviceId;
    }

    public int getDevIfId() {
        return devIfId;
    }

    public void setDevIfId(int devIfId) {
        this.devIfId = devIfId;
    }
}
