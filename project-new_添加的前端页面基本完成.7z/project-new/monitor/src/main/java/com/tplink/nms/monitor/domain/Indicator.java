package com.tplink.nms.monitor.domain;

import org.hibernate.annotations.*;
import org.hibernate.annotations.CascadeType;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Set;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_indicator")
public class Indicator {

    @Id
    @GeneratedValue
    private int id;

    @Column(name = "`name`")
    private String name;

    @Column(name = "unit")
    private String unit;

    @Column(name = "cal_class")
    private String calClass;

    @Column(name = "cal_exp")
    private String calExp;

    @OneToMany(targetEntity = EntryIndicatorRel.class, fetch = FetchType.LAZY, mappedBy = "indicatorId")
    @Cascade(value = {CascadeType.DELETE})
    private Set<EntryIndicatorRel> entryIndicatorRels;

    @OneToMany(targetEntity = MonitorData.class, fetch = FetchType.LAZY, mappedBy = "indicatorId")
    @Cascade(value = {CascadeType.DELETE})
    private Set<MonitorData> monitorDatas;

    @OneToMany(targetEntity = MonitorInterfaceData.class, fetch = FetchType.LAZY, mappedBy = "indicatorId")
    @Cascade(value = {CascadeType.DELETE})
    private Set<MonitorInterfaceData> monitorInterfaceDatas;

    @OneToMany(targetEntity = ViewIndicatorRel.class, fetch = FetchType.LAZY, mappedBy = "indicatorId")
    @Cascade(value = {CascadeType.DELETE})
    private Set<ViewIndicatorRel> viewIndicatorRels;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getCalClass() {
        return calClass;
    }

    public void setCalClass(String calClass) {
        this.calClass = calClass;
    }

    public String getCalExp() {
        return calExp;
    }

    public void setCalExp(String calExp) {
        this.calExp = calExp;
    }

    public Set<EntryIndicatorRel> getEntryIndicatorRels() {
        return entryIndicatorRels;
    }

    public void setEntryIndicatorRels(Set<EntryIndicatorRel> entryIndicatorRels) {
        this.entryIndicatorRels = entryIndicatorRels;
    }

    public Set<MonitorData> getMonitorDatas() {
        return monitorDatas;
    }

    public void setMonitorDatas(Set<MonitorData> monitorDatas) {
        this.monitorDatas = monitorDatas;
    }

    public Set<MonitorInterfaceData> getMonitorInterfaceDatas() {
        return monitorInterfaceDatas;
    }

    public void setMonitorInterfaceDatas(Set<MonitorInterfaceData> monitorInterfaceDatas) {
        this.monitorInterfaceDatas = monitorInterfaceDatas;
    }

    public Set<ViewIndicatorRel> getViewIndicatorRels() {
        return viewIndicatorRels;
    }

    public void setViewIndicatorRels(Set<ViewIndicatorRel> viewIndicatorRels) {
        this.viewIndicatorRels = viewIndicatorRels;
    }
}
