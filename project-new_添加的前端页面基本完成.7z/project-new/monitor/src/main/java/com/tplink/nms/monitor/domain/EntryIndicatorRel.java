package com.tplink.nms.monitor.domain;

import javax.persistence.*;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_entry_indicator_rel")
public class EntryIndicatorRel {

    @Id
    @GeneratedValue
    private int id;

    @ManyToOne(targetEntity = MonitorEntry.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "entry_id")
    private MonitorEntry entryId;

    @ManyToOne(targetEntity = Indicator.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "indicator_id")
    private Indicator indicatorId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public MonitorEntry getEntryId() {
        return entryId;
    }

    public void setEntryId(MonitorEntry entryId) {
        this.entryId = entryId;
    }

    public Indicator getIndicatorId() {
        return indicatorId;
    }

    public void setIndicatorId(Indicator indicatorId) {
        this.indicatorId = indicatorId;
    }
}
