/*
 * Copyright (c) 2013-2014 Shenzhen TP-LINK Technologies Co., Ltd.
 */

package com.tplink.nms.monitor.domain;

import javax.persistence.*;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_view_indicator_rel")
public class ViewIndicatorRel {

    @Id
    @GeneratedValue
    private int id;

    @ManyToOne(targetEntity = DashboardView.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "view_id")
    private DashboardView viewId;

    @ManyToOne(targetEntity = Indicator.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "indicator_id")
    private Indicator indicatorId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public DashboardView getViewId() {
        return viewId;
    }

    public void setViewId(DashboardView viewId) {
        this.viewId = viewId;
    }

    public Indicator getIndicatorId() {
        return indicatorId;
    }

    public void setIndicatorId(Indicator indicatorId) {
        this.indicatorId = indicatorId;
    }
}
