
package com.tplink.nms.monitor.service;

import com.tplink.nms.monitor.dao.MonitorEntryDao;
import com.tplink.nms.monitor.domain.MonitorEntry;
import com.tplink.nms.mvc.bean.Grid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MonitorEntryService {
    @Autowired
    private MonitorEntryDao monitorEntryDao;


    public Grid<MonitorEntryDao> getMonitorEntryTemplates(Grid<MonitorEntry> grid) {
        return monitorEntryDao.getMonitorEntryTemplates(grid, grid.getQueryConditionList());
    }
}
