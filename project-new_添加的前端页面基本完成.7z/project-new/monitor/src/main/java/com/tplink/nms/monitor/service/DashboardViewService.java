
package com.tplink.nms.monitor.service;

import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.monitor.dao.DashboardViewDao;
import com.tplink.nms.monitor.domain.DashboardView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DashboardViewService {
    @Autowired
    private DashboardViewDao dashboardViewDao;


    public Grid<DashboardViewDao> getDashboardViewTemplates(Grid<DashboardView> grid) {
        return dashboardViewDao.getDashboardViewTemplates(grid, grid.getQueryConditionList());
    }
}
