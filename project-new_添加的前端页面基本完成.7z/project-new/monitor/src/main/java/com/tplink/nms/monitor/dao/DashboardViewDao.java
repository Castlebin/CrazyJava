package com.tplink.nms.monitor.dao;

import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.dao.BaseDao;
import com.tplink.nms.mvc.utils.FilterHql;
import com.tplink.nms.monitor.domain.DashboardView;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository("dashboardViewDao")
public class DashboardViewDao extends BaseDao<DashboardView> {

    public Grid getDashboardViewTemplates(Grid grid, ArrayList<QueryCondition> filter) {
        return pagedQuery(FilterHql.getFilterHql(DashboardView.class, filter), grid);
    }
}
