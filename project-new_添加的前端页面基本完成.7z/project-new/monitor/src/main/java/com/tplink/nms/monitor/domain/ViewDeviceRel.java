/*
 * Copyright (c) 2013-2014 Shenzhen TP-LINK Technologies Co., Ltd.
 */

package com.tplink.nms.monitor.domain;

import javax.persistence.*;

/**
 * @author yuhai
 */
@Entity
@Table(name = "pm_view_device_rel")
public class ViewDeviceRel {

    @Id
    @GeneratedValue
    private int id;

    @ManyToOne(targetEntity = DashboardView.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "view_id")
    private DashboardView viewId;

    @Column(name = "device_id")
    private int deviceId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public DashboardView getViewId() {
        return viewId;
    }

    public void setViewId(DashboardView viewId) {
        this.viewId = viewId;
    }

    public int getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(int deviceId) {
        this.deviceId = deviceId;
    }
}
