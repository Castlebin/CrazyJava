package com.tplink.nms.rmi;

import com.tplink.nms.facade.global.G;
import com.tplink.nms.rmi.bean.LaunchInfoBean;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 * Created by simon on 2015/5/5.
 */
public class LaunchInfo extends UnicastRemoteObject implements LaunchInfoBean {
    public LaunchInfo() throws RemoteException {
    }

    @Override
    public void sendMessage(InfoType type, String msg) throws RemoteException {
        G.sendCommand(type.toString(), msg);
    }
}
