package com.tplink.nms.rmi;

import com.tplink.nms.facade.global.Configuration;
import com.tplink.nms.facade.global.G;
import com.tplink.nms.facade.i18n.L;

import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Random;

/**
 * Created by simon on 2015/5/6.
 */
public class RMI {
    public static int RMI_PORT = 1099;
    private static int RMI_INIT_TRY_TIMES = 5;
    private static Registry registry;

    private static L l = L.getInstance(RMI.class);
    private static ArrayList<String> rmiUrls = new ArrayList<>();

    public static void init() {
        RMI_PORT = Integer.valueOf(Configuration.get("nms.rmi.port"));

        int i = 0;
        for (; i < RMI_INIT_TRY_TIMES; i++) {
            try {
                registry = LocateRegistry.createRegistry(RMI_PORT);
                break;
            } catch (RemoteException e) {
                RMI_PORT += (new Random().nextInt() % 100);
            }
        }

        if (i >= RMI_INIT_TRY_TIMES) {
            G.sendCommand(G.INFO_ERROR, l.get("ui.init.error"));
            return;
        }

        try {
            addRmiInterface(G.RMI_LAUNCH_INFO, new LaunchInfo());
        } catch (RemoteException e) {
            G.sendCommand(G.INFO_ERROR, l.get("ui.init.error"));
        }
    }

    public static void stop() {
        try {
            deleteRmiInterfaceAll(rmiUrls);
            UnicastRemoteObject.unexportObject(registry, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void addRmiInterface(String value, Remote remote) {
        try {
            String url = "rmi://localhost:" + RMI_PORT + "/" + value;
            Naming.bind(url, remote);
            rmiUrls.add(value);
        } catch (Exception e) {
        }
    }

    public static void deleteRmiInterface(String value) {
        try {
            Naming.unbind("rmi://localhost:" + RMI_PORT + "/" + value);
        } catch (Exception e) {
        }
    }

    public static void deleteRmiInterfaceAll(ArrayList<String> rmiUrls) {
        for (String url : rmiUrls) {
            deleteRmiInterface(url);
        }
    }
}
