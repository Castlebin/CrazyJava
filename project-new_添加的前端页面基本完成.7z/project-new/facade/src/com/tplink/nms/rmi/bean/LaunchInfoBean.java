package com.tplink.nms.rmi.bean;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Created by simon on 2015/5/5.
 */
public interface LaunchInfoBean extends Remote {
    public void sendMessage(InfoType type, String msg) throws RemoteException;

    public enum InfoType{
        MSG(0),ERROR(1),STOP(2),STARTED(3),HEARTBEAT(4);

        int value;
        InfoType(int value){
            this.value = value;
        }

        @Override
        public String toString() {
            switch (value){
                case 0:return "Message";
                case 1:return "Error";
                case 2:return "Stop";
                case 3:return "Started";
                case 4:return "Heartbeat";
                default :return "Message";
            }
        }
    }
}
