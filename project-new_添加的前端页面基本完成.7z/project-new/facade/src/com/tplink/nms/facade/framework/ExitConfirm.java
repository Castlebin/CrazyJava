package com.tplink.nms.facade.framework;

import com.tplink.nms.facade.Deployer;
import com.tplink.nms.facade.i18n.L;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ExitConfirm {
    private Stage confirmStage = new Stage();
    public StackPane rootPane = new StackPane();
    public Handler handler = null;

    private double mouseDragOffsetX;
    private double mouseDragOffsetY;
    private boolean isPressed = false;

    private L l = L.getInstance(ExitConfirm.class);

    public ExitConfirm() {
        rootInit();
        initMove();
        stageInit();
    }

    private void rootInit() {
        AnchorPane mainPane = new AnchorPane();
        mainPane.setId("confirm-pane");

        Label text = new Label(l.get("ui.exit.confirm.msg"));
        text.setTextFill(Color.web("#626262"));
        text.setFont(Font.font("Arial", FontWeight.NORMAL, 13));
        AnchorPane.setLeftAnchor(text, 20.0);
        AnchorPane.setTopAnchor(text, 5.0);

        Button hide = new Button(l.get("ui.exit.hide"));
        Button exit = new Button(l.get("ui.exit.directly"));
        hide.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                handler.handle(CONFIRM_TYPE.HIDE);
            }
        });
        hide.setPrefWidth(110.0);
        hide.setPrefHeight(32.0);
        exit.setPrefWidth(110.0);
        exit.setPrefHeight(32.0);
        AnchorPane.setBottomAnchor(exit, 10.0);
        AnchorPane.setBottomAnchor(hide, 10.0);
        AnchorPane.setLeftAnchor(exit, 20.0);
        AnchorPane.setRightAnchor(hide, 20.0);

        exit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                handler.handle(CONFIRM_TYPE.CLOSE);
            }
        });

        mainPane.getChildren().addAll(exit, hide, text);
        rootPane.setStyle("-fx-padding: 15;");
        rootPane.getChildren().add(mainPane);
    }

    private void stageInit() {
        Scene scene = new Scene(rootPane, 300, 120);
        scene.getStylesheets().add(
                Deployer.class.getResource("stylesheets/nms.css")
                        .toExternalForm());
        scene.setFill(Color.TRANSPARENT);

        confirmStage.setScene(scene);
        confirmStage.setResizable(false);
        confirmStage.getIcons().add(
                new Image(Deployer.class
                        .getResourceAsStream("images/eap-icon.png")));
        confirmStage.setTitle("Exit Confirm");
        confirmStage.initModality(Modality.APPLICATION_MODAL);
    }

    private void initMove() {
        rootPane.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                mouseDragOffsetX = mouseEvent.getSceneX();
                mouseDragOffsetY = mouseEvent.getSceneY();
                isPressed = true;
            }
        });

        rootPane.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (isPressed) {
                    confirmStage.setX(mouseEvent.getScreenX()
                            - mouseDragOffsetX);
                    confirmStage.setY(mouseEvent.getScreenY()
                            - mouseDragOffsetY);
                }
            }
        });

        rootPane.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent arg0) {
                isPressed = false;
            }
        });
    }

    public void show() {
        confirmStage.show();
    }

    public void hide() {
        confirmStage.hide();
    }

    public void exit() {
        handler = null;
        confirmStage.close();
    }

    public void addHandler(Handler handler) {
        this.handler = handler;
    }

    public interface Handler {
        public void handle(CONFIRM_TYPE type);
    }

    public enum CONFIRM_TYPE {
        HIDE, CLOSE;
    }
}
