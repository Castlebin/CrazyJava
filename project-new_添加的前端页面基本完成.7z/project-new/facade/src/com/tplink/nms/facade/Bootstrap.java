package com.tplink.nms.facade;

import com.tplink.nms.facade.global.Configuration;
import com.tplink.nms.facade.global.G;
import com.tplink.nms.facade.global.Log;
import com.tplink.nms.facade.i18n.L;
import com.tplink.nms.rmi.RMI;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

import java.io.File;

public class Bootstrap extends Service<Object> {
    private L l = L.getInstance(Bootstrap.class);
    private boolean isSetError = false;

    @Override
    protected Task<Object> createTask() {
        return new Task<Object>() {

            @Override
            protected Object call() throws Exception {
                RMI.init();

                String command = Configuration.get("nms.home.bin") + File.separator
                        + Configuration.get("nms.start.command");
                Log.d(command);
                Runtime.getRuntime().exec(command);

                System.gc();

                int interval = Integer.valueOf(Configuration.get("nms.heartbeat")) * 1000;
                int timeout = interval * 2 + 1000;
                while (true) {
                    if (G.lastHeartBeatTime != 0 && ((System.currentTimeMillis() - G.lastHeartBeatTime) > timeout)) {
                        if (!isSetError) {
                            G.sendCommand("Error", l.get("msg.service.error"));
                            isSetError = true;
                        }
                    } else {
                        isSetError = false;
                    }
                    Thread.currentThread().sleep(interval);
                }
            }
        };
    }
}
