package com.tplink.nms.facade;

import com.tplink.nms.facade.framework.ExitConfirm;
import com.tplink.nms.facade.framework.FrameStore;
import com.tplink.nms.facade.framework.RootPane;
import com.tplink.nms.facade.global.Configuration;
import com.tplink.nms.facade.global.G;
import com.tplink.nms.facade.global.Log;
import com.tplink.nms.facade.i18n.L;
import com.tplink.nms.rmi.RMI;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Deployer extends Application {
    L l = L.getInstance(Deployer.class);

    private TrayIcon trayIcon;
    private Stage primaryStage;
    private ExitConfirm confirm;

    @Override
    public void start(Stage primaryStage) throws Exception {
        List<String> args = new ArrayList<>(getParameters().getRaw());
        String helpMsg = "Usage: nms.exe [-adew]\n"
                + "  -a open all log information\n" + "  -d open debug log\n"
                + "  -e open error log\n" + "  -w open warning log\n";

        if (args.size() > 0) {
            for (String arg : args) {
                if (arg.equals("-d")) {
                    System.out.println("OPEN DEBUG");
                    Log.open(Log.LogType.DEBUG);
                } else if (arg.equals("-e")) {
                    System.out.println("OPEN ERROR");
                    Log.open(Log.LogType.ERROR);
                } else if (arg.equals("-w")) {
                    System.out.println("OPEN WARNING");
                    Log.open(Log.LogType.WARNING);
                } else if (arg.equals("-a")) {
                    System.out.println("OPEN ALL DEBUG");
                    Log.open();
                } else if (arg.equals("-h") || arg.equals("--help")) {
                    System.out.print(helpMsg);
                } else {
                    System.out.printf("invalid option %s\n", arg);
                }
            }
        }

        L.setLanguageType(Configuration.get("nms.language"));

        this.primaryStage = primaryStage;
        FrameStore.setPrimarySate(primaryStage);

        RootPane rootPane = new RootPane();
        Scene scene = new Scene(rootPane, FrameStore.Layout.ROOT_WIDTH_INIT,
                FrameStore.Layout.ROOT_HEIGHT_INIT);
        scene.getStylesheets().add(
                this.getClass().getResource("stylesheets/nms.css")
                        .toExternalForm());
        scene.setFill(Color.TRANSPARENT);

        confirm = new ExitConfirm();
        confirm.addHandler(new ExitConfirm.Handler() {
            @Override
            public void handle(ExitConfirm.CONFIRM_TYPE type) {
                if (type.equals(ExitConfirm.CONFIRM_TYPE.CLOSE)) {
                    Platform.exit();
                } else if (type.equals(ExitConfirm.CONFIRM_TYPE.HIDE)) {
                    FrameStore.getPrimarySate().hide();
                    confirm.hide();
                }
            }
        });

        primaryStage.setHeight(FrameStore.Layout.ROOT_HEIGHT_INIT);
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.getIcons().add(
                new Image(Deployer.class
                        .getResourceAsStream("images/eap-icon.png")));
        primaryStage.setTitle(l.get("nms.title", Configuration.get("nms.version")));
        primaryStage.show();
        primaryStage.addEventFilter(WindowEvent.WINDOW_CLOSE_REQUEST,
                new EventHandler<WindowEvent>() {
                    @Override
                    public void handle(WindowEvent event) {
                        confirm.show();
                        event.consume();
                    }
                });

        enableTray();

        G.sendCommand(G.INFO_MESSAGE, l.get("msg.start"));
        new Bootstrap().start();
    }


    @Override
    public void stop() throws Exception {
        RMI.stop();
        SystemTray.getSystemTray().remove(trayIcon);
        Platform.setImplicitExit(true);
        confirm.exit();

        System.exit(0);

        super.stop();
    }

    private void enableTray() {
        Platform.setImplicitExit(false);
        SystemTray tray = SystemTray.getSystemTray();
        try {
            BufferedImage image = ImageIO.read(Deployer.class
                    .getResourceAsStream("images/eap-icon-mini.png"));

            trayIcon = new TrayIcon(image, l.get("nms.title"), new TrayMenu());
            trayIcon.addMouseListener(new MouseListener() {
                @Override
                public void mouseReleased(MouseEvent arg0) {
                }

                @Override
                public void mousePressed(MouseEvent arg0) {
                }

                @Override
                public void mouseExited(MouseEvent arg0) {
                }

                @Override
                public void mouseEntered(MouseEvent arg0) {
                }

                @Override
                public void mouseClicked(MouseEvent event) {
                    if (event.getButton() == MouseEvent.BUTTON1) {
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                if (primaryStage.isShowing()) {
                                    primaryStage.hide();
                                } else {
                                    primaryStage
                                            .setHeight(FrameStore.isRootMax ? FrameStore.Layout.ROOT_HEIGHT_MAX
                                                    : FrameStore.Layout.ROOT_HEIGHT_INIT);
                                    primaryStage.show();
                                    primaryStage.setIconified(false);
                                }
                            }
                        });
                    }
                }
            });
            tray.add(trayIcon);
        } catch (IOException | AWTException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    private class TrayMenu extends PopupMenu {
        public TrayMenu() {
            super();
            MenuItem defaultItem = new MenuItem(l.get("ui.tray.show"));
            defaultItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            if (!primaryStage.isShowing()) {
                                primaryStage.show();
                            }
                            if (primaryStage.isIconified()) {
                                primaryStage.setIconified(false);
                            }
                        }
                    });
                }
            });
            MenuItem exitItem = new MenuItem(l.get("ui.tray.exit"));
            exitItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            primaryStage.fireEvent(new WindowEvent(
                                    primaryStage,
                                    WindowEvent.WINDOW_CLOSE_REQUEST));
                        }
                    });
                }
            });
            add(defaultItem);
            add(exitItem);
        }
    }
}
