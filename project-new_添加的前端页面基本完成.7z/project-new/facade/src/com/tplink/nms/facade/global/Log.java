package com.tplink.nms.facade.global;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author yuhai
 */
public class Log {
    
    private static boolean debug = false;
    private static boolean server  = false;
    private static boolean warning = false;
    private static boolean error   = false;
    private static boolean file    = true;
    private static boolean line    = true;
    private static boolean date    = true;
    private static String  logDir  = new File("../logs").getAbsolutePath();
    
    /* debug */
    public static void d(String fmt, Object... arg) {
        if (!debug)
            return;
        
        if (fmt == null) {
            fmt = "*Input null.*";
        }
        
        LogFields logFields = new LogFields();
        
        logFields.type = LogType.DEBUG;
        logFields.fileName = Thread.currentThread().getStackTrace()[2].getFileName();
        logFields.line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        logFields.log = arg.length==0?fmt:String.format(fmt, arg);

        msgFormat(logFields);
    }
    
    /* warning */
    public static void w(String fmt, Object... arg) {
        if (!warning)
            return;
        
        LogFields logFields = new LogFields();
        
        logFields.type = LogType.WARNING;
        logFields.fileName = Thread.currentThread().getStackTrace()[2].getFileName();
        logFields.line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        logFields.log = arg.length==0?fmt:String.format(fmt, arg);

        msgFormat(logFields);
    }
    
    /* error */
    public static void e(String fmt, Object... arg) {
        if (!error)
            return;
        
        LogFields logFields = new LogFields();
        
        logFields.type = LogType.ERROR;
        logFields.fileName = Thread.currentThread().getStackTrace()[2].getFileName();
        logFields.line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        logFields.log = arg.length==0?fmt:String.format(fmt, arg);

        msgFormat(logFields);
    }
    
    /* server debug */
    public static void s(String fmt, Object... arg) {
        if (!server)
            return;

        LogFields logFields = new LogFields();
        
        logFields.type = LogType.SERVER;
        logFields.fileName = Thread.currentThread().getStackTrace()[2].getFileName();
        logFields.line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        logFields.log = arg.length==0?fmt:String.format(fmt, arg);
        
        msgFormat(logFields);
    }
    
    private static void msgFormat(LogFields logFields) {
        logFields.date = Calendar.getInstance().getTime();
        
        StringBuilder outString = new StringBuilder();
        
        /* print file name */
        if (file) {
            outString.append("[").append(logFields.fileName).append("]");
        }
        
        if (date)
            outString.append("[")
                .append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(logFields.date))
                .append("]");
        
        outString.append("[").append(logFields.type.toString()).append("] ");
        /* print debug message */
        outString.append(logFields.log);
        
        /* print line number */
        if (line) {
            outString.append(" [line ").append(logFields.line).append("]");
        }
        
        if (logFields.type == LogType.ERROR || logFields.type == LogType.WARNING) {
            System.err.println(outString);
        } else {
            System.out.println(outString);
        }
        saveToFile(outString.toString());
    }
    
    private static void saveToFile(String s) {
        try {
            String fileName = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance()
                .getTime());
            String path = logDir + "\\facade-" + fileName + ".log";
            
            File file = new File(path);
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) {
                boolean mkdirs = parent.mkdirs();
                if (!mkdirs) {
                    return;
                }
            }
            FileWriter fileWriter = new FileWriter(file, true);
            
            fileWriter.write(s + "\n");
            fileWriter.flush();
            fileWriter.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void open() {
        open(LogType.ALL);
    }
    
    public static void open(LogType type) {
        switch (type) {
        case DEBUG:
            debug = true;
            break;
        case WARNING:
            warning = true;
            break;
        case ERROR:
            error = true;
            break;
        case SERVER:
            server = true;
            break;
        case ALL:
        default:
            debug = warning = error = server = true;
        }
    }
    
    public static void close() {
        close(LogType.ALL);
    }
    
    public static void close(LogType type) {
        switch (type) {
        case DEBUG:
            debug = false;
            break;
        case WARNING:
            warning = false;
            break;
        case ERROR:
            error = false;
            break;
        case SERVER:
            server = false;
            break;
        case ALL:
        default:
            debug = warning = error = server = false;
        }
    }
    
    public enum LogType {
        DEBUG, WARNING, ERROR, SERVER, ALL;
        
        @Override
        public String toString() {
            switch (this) {
            case DEBUG:
                return "DEBUG";
            case WARNING:
                return "WARNING";
            case ERROR:
                return "ERROR";
            case SERVER:
                return "SERVER";
            case ALL:
                return "LOG";
            default:
                return "UNKNOWN";
            }
        }
    }
    
    public static class LogFields {
        public String  fileName;
        public int     line;
        public LogType type;
        public Date    date;
        public String  log;
    }
}
