package com.tplink.nms.facade.global;

import java.io.*;
import java.net.URL;
import java.util.Properties;

public class Configuration {
    private static Configuration configuration = new Configuration();

    private Properties properties;

    static {
        File file = null;
        boolean isDebug = "true".equals(System.getProperty("debug"));

        String path = isDebug ? G.CONFIG_FILE : G.CONFIG_FILE_PATH + File.separator + G.CONFIG_FILE;

        URL url = Configuration.class.getProtectionDomain().getCodeSource().getLocation();
        String exePath = null;
        try {
            exePath = java.net.URLDecoder.decode(url.getPath(), "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        Log.d("EXE PATH: " + exePath);
        String binPath = isDebug ? exePath : getParentPath(exePath);
        Log.d("BIN PATH:" + binPath);

        System.setProperty("nms.home.bin", binPath);
        System.setProperty("nms.home", getParentPath(binPath));
        path = isDebug ? (binPath + File.separator + path) : (System.getProperty("nms.home")
                + File.separator + path);

        Log.d("file path:" + path);

        file = new File(path);

        if (file.exists()) {
            Properties properties = new Properties();
            FileInputStream inputStream = null;
            try {
                inputStream = new FileInputStream(file);
                properties.load(inputStream);
                configuration.setProperties(properties);
            } catch (IOException e) {
            } finally {
                try {
                    inputStream.close();
                } catch (IOException e) {

                }
            }
        } else {
            Log.d("System Properties File Not Exist.");
            InputStream inputStream = Configuration.class.getClassLoader().getResourceAsStream(G.CONFIG_FILE);
            Properties propertiesFile = new Properties();
            try {
                propertiesFile.load(inputStream);
                configuration.setProperties(propertiesFile);
            } catch (IOException e) {
            }
        }

        getJettyPort();
    }

    public static String get(String key) {
        return configuration.getProperty(key);
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public String getProperty(String key) {
        String value = null;
        if (properties != null) {
            value = (String) properties.get(key);
        }
        if (value == null) {
            return System.getProperty(key);
        }
        return value;
    }

    private static String getParentPath(String path) {
        String parentPath = path.replaceAll("\\/[\\.a-zA-Z\\-\\_\\s]*$", "");
        Log.d("ParentPath:" + parentPath);
        if (parentPath.endsWith(path))
            return path.replaceAll("\\" + File.separator + "[\\.a-zA-Z\\-\\_\\s]*$", "");
        return parentPath;
    }

    private static void getJettyPort() {
        Properties jettyProperties = new Properties();
        String jettyPropertyiesPath = System.getProperty("nms.home") + File.separator
                + "conf" + File.separator + "jetty.properties";
        File file = new File(jettyPropertyiesPath);
        if (!file.exists())
            return;
        FileInputStream inputStream = null;
        try {
            inputStream = new FileInputStream(file);
            jettyProperties.load(inputStream);
            System.setProperty("jetty.port", jettyProperties.getProperty("http.connector.port"));

        } catch (IOException e) {
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
            }
        }

    }
}
