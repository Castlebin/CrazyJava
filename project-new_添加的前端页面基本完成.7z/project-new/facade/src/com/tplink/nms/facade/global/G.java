package com.tplink.nms.facade.global;

import com.tplink.nms.facade.framework.FrameStore;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class G {
    public static final String   ROOT_PATH        = "/com/tplink/nms/facade/";
    public static final String   CONFIG_FILE      = "nms.properties";
    public static final String   CONFIG_FILE_PATH = "properties";

    public static final String INFO_MESSAGE = "Message";
    public static final String INFO_ERROR = "Error";
    public static final String INFO_STOP = "Stop";
    public static final String INFO_STARTED = "Started";
    public static final String INFO_HEARTBEAT = "Heartbeat";

    public static final String RMI_LAUNCH_INFO = "facade-launch-info";

    
    public static final StringProperty output           = new SimpleStringProperty();
    public static long lastHeartBeatTime = 0;

    public static void sendCommand(String type, String info){
        if(type.equals(INFO_HEARTBEAT)){
            lastHeartBeatTime = System.currentTimeMillis();
        }else if(type.equals(INFO_MESSAGE)){
            logValue(info);
        }else if(type.equals(INFO_ERROR)){
            FrameStore.getBodyPane().setError();
            logValue("Error:" + info);
        }else if(type.equals(INFO_STOP)){
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    Platform.exit();
                }
            });
        }else if(type.equals(INFO_STARTED)){
            FrameStore.getBodyPane().setBrowser(false);
            G.logValue(info);
        }
    }
    
    private static void logValue(String logRecord) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        StringBuilder sb = new StringBuilder();
        
        sb.append("[").append(dateFormat.format(new Date())).append("] ");
        sb.append(logRecord);
        setValue(sb.toString());
    }
    
    private static void setValue(String logRecord) {
        synchronized (output) {
            output.setValue(logRecord);
        }
    }
}
