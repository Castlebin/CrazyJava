package com.tplink.nms.facade.framework;

import javafx.scene.layout.BorderPane;

public class MainPane extends BorderPane {
	public MainPane() {
		FrameStore.setMainPane(this);
		init();
	}

	private void init() {
		setId("main");
		setTop(new HeaderPane());
		setCenter(new BodyPane());
	}
}
