package com.tplink.nms.facade.i18n;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * Created by Simon Wei on 2015/4/7.
 */
public class LanguageProperty {
    private static String DEFAULT_I18N_FILE_NAME = "i18n";
    private static String DEFAULT_I18N_FILE_FOLDER = "i18n/";
    private static ResourceBundle grb = null;
    private ResourceBundle lrb = null;

    public LanguageProperty(Class clzz) {
        this(DEFAULT_I18N_FILE_NAME, clzz);
    }

    public LanguageProperty(String fileName, Class clazz) {
        loadLanguageFile(fileName, clazz);
    }

    public String get(String key) {
        try {
            String value = lrb.getString(key);
            return value;
        } catch (Exception e) {
            try {
                String value = grb.getString(key);
                return value;
            } catch (Exception e1) {
                return "[NULL]";
            }
        }
    }

    private void loadLanguageFile(String fileName, Class clazz) {
        loadGlobleLanguageFile();

        String lI18nFilePath = DEFAULT_I18N_FILE_FOLDER +
                fileName + "_" + L.getLanguageType().toString() + ".properties";

        InputStream inputStream = getI18nFile(clazz, lI18nFilePath);

        try {
            lrb = new PropertyResourceBundle(inputStream);
        } catch (Exception e) {
            return;
        }
    }

    private void loadGlobleLanguageFile() {
        if (grb != null)
            return;

        String gI18nFilePath = DEFAULT_I18N_FILE_FOLDER +
                DEFAULT_I18N_FILE_NAME + "_" + L.getLanguageType().toString() + ".properties";

        InputStream inputStream = getI18nFile(getClass(), gI18nFilePath);

        try {
            grb = new PropertyResourceBundle(inputStream);
        } catch (IOException e) {
            return;
        }
    }

    private InputStream getI18nFile(Class clazz, String i18nFilePath) {
        URL url = clazz.getProtectionDomain().getCodeSource().getLocation();
        try {
            String filePath = java.net.URLDecoder.decode(url.getPath(), "utf-8");
            if (filePath.endsWith(".jar")) {
                JarFile jarFile = new JarFile(filePath);
                JarEntry jarEntry = jarFile.getJarEntry(i18nFilePath);

                return jarFile.getInputStream(jarEntry);
            } else if (filePath.endsWith(".exe")) {
                return clazz.getClassLoader().getResourceAsStream(i18nFilePath);
            } else {
                return new FileInputStream(filePath + i18nFilePath);
            }
        } catch (Exception e) {
            return null;
        }
    }
}
