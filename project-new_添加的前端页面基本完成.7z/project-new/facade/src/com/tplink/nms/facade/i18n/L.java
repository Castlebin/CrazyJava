package com.tplink.nms.facade.i18n;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Simon Wei on 2015/4/7.
 */
public class L {
    private static LanguageType languageType = LanguageType.EN;
    private static Map<String, L> languageFiles = new HashMap<String, L>();

    private static boolean hasLoadPropertyFile = false;
    private LanguageProperty languageProperty = null;
    private Class clazz = null;

    public static void setLanguageType(LanguageType type) {
        languageType = type;
        hasLoadPropertyFile = false;
    }

    public static void setLanguageType(String type){
        setLanguageType(LanguageType.asType(type));
    }

    public static LanguageType getLanguageType() {
        return languageType;
    }

    public static L getInstance(Class clazz) {
        String path = clazz.getProtectionDomain().getCodeSource().getLocation().getPath();
        L l = languageFiles.get(path);
        if (l != null)
            return l;

        l = new L();
        l.clazz = clazz;
        languageFiles.put(path, l);

        l.reloadPropertyFile();

        return l;
    }

    public void reloadPropertyFile(){
        if(hasLoadPropertyFile) return;

        LanguageProperty languageProperty = new LanguageProperty(clazz);
        this.languageProperty = languageProperty;

        hasLoadPropertyFile = true;
    }

    public String get(String key) {
        reloadPropertyFile();
        return languageProperty.get(key);
    }

    public String get(String key, Object ... o){
        return String.format(get(key), o);
    }
}
