package com.tplink.nms.facade.framework;

import javafx.stage.Stage;

public class FrameStore {
    public static boolean isRootMax = false;

    private static RootPane rootPane;
	private static MainPane mainPane;
	private static HeaderPane headerPane;
	private static BodyPane bodyPane;
	private static Stage primarySate;

	public class Layout {
        public static final double ROOT_WIDTH_INIT = 440.0;
		public static final double ROOT_HEIGHT_MAX = 350.0;
		public static final double ROOT_HEIGHT_INIT = 235.0;

		public static final double HEADER_HEIGHT_INIT = 75.0;

        public static final double HEADER_LOGO_LEFT = 30.0;
		public static final double HEADER_LOGO_TOP = 17.0;
		public static final double HEADER_WINDOW_BUTTON_TOP = 8.0;
		public static final double HEADER_WINDOW_BUTTON_RIGHT = 6.0;
		
		public static final double BODY_BROWSER_BOTTOM = 20.0;
	}

	public static RootPane getRootPane() {
		return rootPane;
	}

	public static void setRootPane(RootPane rootPane) {
		FrameStore.rootPane = rootPane;
	}

	public static MainPane getMainPane() {
		return mainPane;
	}

	public static void setMainPane(MainPane mainPane) {
		FrameStore.mainPane = mainPane;
	}

	public static HeaderPane getHeaderPane() {
		return headerPane;
	}

	public static void setHeaderPane(HeaderPane headerPane) {
		FrameStore.headerPane = headerPane;
	}

	public static BodyPane getBodyPane() {
		return bodyPane;
	}

	public static void setBodyPane(BodyPane bodyPane) {
		FrameStore.bodyPane = bodyPane;
	}

	public static Stage getPrimarySate() {
		return primarySate;
	}

	public static void setPrimarySate(Stage primarySate) {
		FrameStore.primarySate = primarySate;
	}

}
