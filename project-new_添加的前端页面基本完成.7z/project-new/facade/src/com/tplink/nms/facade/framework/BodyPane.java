package com.tplink.nms.facade.framework;

import com.tplink.nms.facade.global.Configuration;
import com.tplink.nms.facade.global.G;
import com.tplink.nms.facade.i18n.L;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

import java.net.URI;

public class BodyPane extends AnchorPane {
    private Button browser;
    private ImageView waiting;
    private ImageView detailsImg;
    private Label statusText;
    private final TextArea output = new TextArea();
    private final Button details;

    private L l = L.getInstance(BodyPane.class);

    public BodyPane() {
        FrameStore.setBodyPane(this);
        details = new Button(l.get("ui.details"));
        init();
    }

    private void init() {
        setId("body");

        HBox hBox = new HBox();
        statusText = new Label(l.get("ui.init", Configuration.get("nms.version")));
        statusText.setId("status-text");
        statusText.setTextFill(Color.web("#626262"));
        statusText.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        waiting = new ImageView();
        waiting.setImage(new Image(getClass().getResourceAsStream(
                G.ROOT_PATH + "images/waiting.gif")));

        hBox.getChildren().addAll(statusText, waiting);
        hBox.setSpacing(15.0);
        hBox.setAlignment(Pos.CENTER_LEFT);
        AnchorPane.setLeftAnchor(hBox, 35.0);

        details.setId("details");
        details.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        details.getChildrenUnmodifiable();
        details.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent arg0) {
                handleDetails(details);
            }
        });
        detailsImg = new ImageView();
        detailsImg.setImage(new Image(getClass().getResourceAsStream(
                G.ROOT_PATH + "images/details.png")));
        detailsImg.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent arg0) {
                handleDetails(details);
            }
        });
        detailsImg.setStyle("-fx-cursor: hand;");
        AnchorPane.setLeftAnchor(detailsImg, 35.0);
        AnchorPane.setTopAnchor(detailsImg, 30.0);
        AnchorPane.setLeftAnchor(details, 57.0);
        AnchorPane.setTopAnchor(details, 30.0);


        Button button = new Button(l.get("ui.launch"));
        button.setPrefWidth(FrameStore.Layout.ROOT_WIDTH_INIT - 60);
        button.setPrefHeight(35);
        button.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                openUrl();
            }
        });
        button.setDisable(true);
        this.browser = button;
        AnchorPane.setLeftAnchor(button, 35.0);
        AnchorPane.setBottomAnchor(button,
                FrameStore.Layout.BODY_BROWSER_BOTTOM);

        output.setEditable(false);
        output.setFocusTraversable(false);
        output.setId("output");
        output.setPrefWidth(FrameStore.Layout.ROOT_WIDTH_INIT - 60);
        output.setPrefRowCount(7);
        output.setVisible(FrameStore.isRootMax);
        output.setWrapText(true);
        G.output.addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> arg0, String oldS,
                                final String newStr) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        output.appendText(newStr);
                        output.appendText("\n");
                    }
                });
            }
        });
        AnchorPane.setTopAnchor(output, 60.0);
        AnchorPane.setLeftAnchor(output, 35.0);

        getChildren().addAll(hBox, detailsImg, details, output, button);
    }

    private void handleDetails(final Button details) {
        FrameStore.isRootMax = !FrameStore.isRootMax;
        if (!FrameStore.isRootMax) {
            output.setVisible(FrameStore.isRootMax);
        }
        details.setDisable(true);

        final Timeline timeline = new Timeline();
        final int timeout = 300;
        final Double height = FrameStore.Layout.ROOT_HEIGHT_MAX
                - FrameStore.Layout.ROOT_HEIGHT_INIT;

        IntegerProperty timeLeft = new SimpleIntegerProperty(timeout);
        timeLeft.addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> arg0, Number arg1, Number arg2) {

                Double h = ((double) (timeout - arg2.intValue()) / timeout) * height;
                h = FrameStore.isRootMax ? (FrameStore.Layout.ROOT_HEIGHT_INIT + h)
                        : (FrameStore.Layout.ROOT_HEIGHT_MAX - h);

                FrameStore.getPrimarySate().setHeight(h);

                if (arg2.intValue() == 0) {
                    output.setVisible(FrameStore.isRootMax);
                    details.setDisable(false);
                    timeline.stop();
                }
            }
        });

        timeline.setCycleCount(10);
        timeline.setAutoReverse(false);
        timeline.getKeyFrames().add(
                new KeyFrame(Duration.millis(timeout), new KeyValue(timeLeft, 0)));
        timeline.play();
        detailsImgRotate();
    }

    private void detailsImgRotate() {
        RotateTransition rotateTransition = RotateTransitionBuilder.create().node(detailsImg)
                .duration(Duration.seconds(0.3))
                .fromAngle(FrameStore.isRootMax ? 0 : 180)
                .toAngle(FrameStore.isRootMax ? 180 : 360).cycleCount(1)
                .build();
        rotateTransition.play();
    }

    public void setBrowser(final boolean disable) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                browser.setDisable(disable);
                statusText.setText(l.get("ui.inited"));
                waiting.setVisible(false);
                openUrl();
            }

        });
    }

    public void setError() {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                statusText.setTextFill(Color.web("#ed5565"));
                statusText.setText(browser.isDisable() ? l.get("ui.init.err") : l.get("ui.running.err"));
                waiting.setVisible(false);
                if(!output.isVisible()) {
                    handleDetails(details);
                }
            }

        });
    }

    private void openUrl() {
        String url = "http://127.0.0.1";

        String jettyPort = System.getProperty("jetty.port");
        if (jettyPort != null && !jettyPort.isEmpty() && !jettyPort.equals("80")) {
            url += ":" + jettyPort;
        }

        try {
            java.awt.Desktop.getDesktop().browse(new URI(url));
        } catch (Exception e) {
            try {
                Runtime.getRuntime().exec("cmd /c start iexplore " + url);
            } catch (Exception e2) {
            }
        }
    }
}
