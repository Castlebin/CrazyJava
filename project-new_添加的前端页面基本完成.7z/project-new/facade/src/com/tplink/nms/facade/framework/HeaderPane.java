package com.tplink.nms.facade.framework;

import com.tplink.nms.facade.global.Configuration;
import com.tplink.nms.facade.global.G;
import com.tplink.nms.facade.i18n.L;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class HeaderPane extends AnchorPane {
    private L l = L.getInstance(HeaderPane.class);

    public HeaderPane() {
        FrameStore.setHeaderPane(this);
        init();
    }

    private void init() {
        setId("header");
        setMinHeight(FrameStore.Layout.HEADER_HEIGHT_INIT);
        setHeight(FrameStore.Layout.HEADER_HEIGHT_INIT);
        setPrefHeight(FrameStore.Layout.HEADER_HEIGHT_INIT);

        ImageView logo = new ImageView();
        logo.setImage(new Image(getClass().getResourceAsStream(G.ROOT_PATH + "images/logo.png")));
        logo.setCursor(Cursor.HAND);
        logo.setOnMouseClicked(new EventHandler<Event>() {
            @Override
            public void handle(Event even) {
                if (even instanceof MouseEvent) {
                    MouseEvent mouseEvent = (MouseEvent) even;
                    if (!(mouseEvent.getButton() == MouseButton.PRIMARY)) {
                        return;
                    }
                }
                try {
                    String url = "http://www.tp-link.com";
                    java.awt.Desktop.getDesktop().browse(new URI(url));
                } catch (IOException | URISyntaxException e) {
                }
            }
        });

        AnchorPane.setLeftAnchor(logo, FrameStore.Layout.HEADER_LOGO_LEFT);
        AnchorPane.setTopAnchor(logo, FrameStore.Layout.HEADER_LOGO_TOP);

        Label appName = new Label(l.get("nms.title.ignoreLogo", Configuration.get("nms.version")));
        appName.setId("app-name");
        AnchorPane.setLeftAnchor(appName, 35.0);
        AnchorPane.setTopAnchor(appName, 37.0);

        Button hideButton = new Button(l.get("ui.hide"));
        hideButton.setId("hide-btn");
        hideButton.setPrefHeight(35.0);
        hideButton.setPrefWidth(40.0);
        hideButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent arg0) {
                FrameStore.getPrimarySate().hide();
            }
        });
        AnchorPane.setRightAnchor(hideButton, 35.0);
        AnchorPane.setTopAnchor(hideButton, 5.0);

        getChildren().addAll(logo, appName, hideButton);
    }
}
