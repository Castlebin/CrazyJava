package com.tplink.nms.facade.framework;

import javafx.scene.layout.StackPane;

public class RootPane extends StackPane {
	public RootPane() {
		super();
		FrameStore.setRootPane(this);
		setId("root");
        this.getChildren().addAll(new MainPane());
	}
}
