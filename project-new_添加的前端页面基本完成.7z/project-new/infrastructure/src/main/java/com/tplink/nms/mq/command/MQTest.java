package com.tplink.nms.mq.command;

import com.tplink.nms.mq.*;
import com.tplink.nms.mq.message.MQException;
import com.tplink.nms.mq.message.Message;
import com.tplink.smb.command.annotion.Command;
import com.tplink.smb.command.annotion.Test;
import com.tplink.smb.command.io.CommandIO;

/**
 * Created by Simon Wei on 2015/4/20.
 */
@Test(scope = "mqt")
public class MQTest {
    @Command
    public void init() {
        MQModule module = MQManager.newModule("test");
        try {
            MQManager.addMessageListener("test.str", new MessageListener() {
                @Override
                public Message onAction(Message message) {
                    System.out.println(message.getMessageBody());
                    return message;
                }
            });

        }catch (MQException e){
            CommandIO.COUT.println("Add listener error.");
        }
        module.start();
    }

    @Command
    public void send(String message){
        MQ.push(MQ.newMessage("test.str", message));
    }
}
