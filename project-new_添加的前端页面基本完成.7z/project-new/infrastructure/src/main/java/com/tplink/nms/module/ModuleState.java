package com.tplink.nms.module;

/**
 * Created by Simon Wei on 2015/3/31.
 */
public enum ModuleState {
    INIT(0), INITIALING(1), RUNNING(2), ERROR(3), STOPED(4);
    

    int value = 0;
    ModuleState(int value){
        this.value = value;
    }

    public int getValue(){
        return value;
    }
}
