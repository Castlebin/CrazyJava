package com.tplink.nms.mq;


import com.tplink.nms.mq.message.Message;
import com.tplink.nms.mq.message.MessageState;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by simon on 2015/1/26.
 */
public class SimpleMessagePipeline implements MessagePipeline {
    private static final String DEFAULT_NAME = "default";
    private Map<String, ArrayList<MessageListener>> listeners = new HashMap<>();

    public SimpleMessagePipeline() {
        listeners.put(DEFAULT_NAME, new ArrayList<MessageListener>());
    }

    @Override
    public Message process(Message message) {
        String methodName = message.getMethodName();
        ArrayList<MessageListener> msgListeners = listeners.get(methodName);
        if (msgListeners == null || msgListeners.isEmpty()) {
            message.switchState(MessageState.FAILED);
            return message;
        }

        for (MessageListener l : msgListeners) {
            l.onAction(message);
        }

        return message;
    }

    @Override
    public void addMessageListener(String name, MessageListener listener) {
        if (name == null || name.isEmpty()) {
            name = DEFAULT_NAME;
        }

        if (listeners.get(name) == null) {
            listeners.put(name, new ArrayList<MessageListener>());
        }

        ArrayList messageListeners = listeners.get(name);
        messageListeners.add(listener);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<String, ArrayList<MessageListener>> entry : listeners.entrySet()) {
            builder.append("\t")
                    .append(entry.getKey())
                    .append(" [size:")
                    .append(entry.getValue() == null ? 0 : entry.getValue().size())
                    .append("]\r\n");
        }

        return builder.toString();
    }
}
