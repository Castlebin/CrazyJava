package com.tplink.nms.mq;

import com.tplink.nms.mq.message.MQException;

import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by simon on 2015/1/26.
 */
public class MQManager {
	private static ConcurrentHashMap<String, MQModule> modules = new ConcurrentHashMap<>();

	public static MQModule newModule(String moduleName) {
		MQModule mqModule = new MQModule(moduleName);
		modules.put(moduleName, mqModule);

		return mqModule;
	}

	public static MQModule newModule(String moduleName,
			Class<? extends MessagePipeline> piplineClass) {
		if (modules.containsKey(moduleName)) {
			return modules.get(moduleName);
		}
		MQModule mqModule = new MQModule(moduleName, piplineClass);
		modules.put(moduleName, mqModule);

		return mqModule;
	}

	public static MQModule getModule(String moduleName) {
		return modules.get(moduleName);
	}

	public static void removeModule(String moduleName) {
		modules.remove(moduleName);
	}

	public static ArrayList<MQModule> getModules() {
		ArrayList<MQModule> moduleList = new ArrayList<>();
		for (Map.Entry<String, MQModule> entity : modules.entrySet()) {
			moduleList.add(entity.getValue());
		}
		return moduleList;
	}

	public static void addMessageListener(String messageName,
			MessageListener messageLisner) throws MQException {
		String firstName = null, secondName = null;
		int dotIndex = messageName.indexOf(".");
		if (dotIndex < 0) {
			firstName = messageName;
		} else {
			firstName = messageName.substring(0, dotIndex);
			secondName = messageName.substring(dotIndex + 1);
		}

		MQModule module = modules.get(firstName);
		if (module == null) {
			throw new MQException(String.format("MQ Module %s not exist!",
					firstName));
		} else {
			module.addMessageListener(secondName, messageLisner);
		}
	}
}
