package com.tplink.nms.mq;

import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;
import com.tplink.nms.mq.message.Message;
import com.tplink.nms.mq.message.MessageState;

import java.util.ArrayList;

/**
 * Created by Simon Wei on 2015/4/2.
 */
public class MessageQueueModule extends AbstractModule {
    MQModule mqModule = MQManager.newModule("module");

    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
        mqModule.addMessageListener("new", new MessageListener() {
            @Override
            public Message onAction(Message message) {
                Module module = (Module) message.getMessageBody();

                Class pipelineClass = module.getPipelineClass();
                if(pipelineClass == null)
                    pipelineClass = SimpleMessagePipeline.class;

                MQManager.newModule(module.getModuleName(), pipelineClass);
                message.switchState(MessageState.SUCCESS);
                return message;
            }
        });
        mqModule.addMessageListener("stop", new MessageListener() {
            @Override
            public Message onAction(Message message) {
                String moduleName = (String) message.getMessageBody();
                MQManager.getModule(moduleName).stop();
                MQManager.removeModule(moduleName);
                return message;
            }
        });
        mqModule.addMessageListener("stopAll", new MessageListener() {
            @Override
            public Message onAction(Message message) {
                ArrayList<MQModule> mqModules = MQManager.getModules();
                for (MQModule module : mqModules) {
                    module.stop();
                }
                return message;
            }
        });
        mqModule.start();
    }

    @Override
    public void stop() {
        mqModule.stop();
    }
}

