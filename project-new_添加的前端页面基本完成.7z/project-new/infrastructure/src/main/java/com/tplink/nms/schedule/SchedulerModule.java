package com.tplink.nms.schedule;

import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;

/**
 * Created by Simon Wei on 2015/4/8.
 */
public class SchedulerModule extends AbstractModule {
    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
        TaskManager.init();

//        TaskInfo info = new TaskInfo();
//        info.setTaskName("test");
//        info.setTaskClass(HelloJob.class);
//        info.setIntervalTime(TaskInfo.IntervalType.SEC, 1);
//        info.setRepeatCount(-1);
//
//        TaskManager.addTask(info);
    }

    @Override
    public void stop() {
        TaskManager.stop();
    }
}
