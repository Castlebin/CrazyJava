package com.tplink.nms.module;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by Simon Wei on 2015/3/31.
 */
public class ModuleContext implements Iterable<String>{
    private static ModuleContext moduleContext = new ModuleContext();

    private HashMap<String, Module> moduleList = new HashMap<String, Module>();
    private ArrayList<String> moduleSequence = new ArrayList<String>();

    public static ModuleContext getModuleContextInstance() {
        return moduleContext;
    }

    public Module getModuleByName(String moduleName) {
        return moduleList.get(moduleName);
    }

    public void putModule(Module module) {
        moduleSequence.add(module.getModuleName());
        moduleList.put(module.getModuleName(), module);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("[\n");
        for(String name : moduleSequence){
            builder.append("  ");
            builder.append(moduleList.get(name));
            builder.append("\n");
        }
        builder.append("]");
        return builder.toString();
    }

    @Override
    public Iterator<String> iterator() {
        return moduleSequence.iterator();
    }
}
