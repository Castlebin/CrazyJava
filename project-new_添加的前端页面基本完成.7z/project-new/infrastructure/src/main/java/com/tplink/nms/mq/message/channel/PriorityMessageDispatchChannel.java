package com.tplink.nms.mq.message.channel;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.tplink.nms.mq.message.Message;

public class PriorityMessageDispatchChannel implements MessageDispatchChannel {
    private final Object                mutex = new Object();
    private final LinkedList<Message>[] lists;
    private boolean                     closed;
    private boolean                     running;
    private int                         size  = 0;
    
    @SuppressWarnings("unchecked")
    public PriorityMessageDispatchChannel() {
        this.lists = new LinkedList[Message.MAX_PRIORITY];
        for (int i = 0; i < Message.MAX_PRIORITY; i++) {
            lists[i] = new LinkedList<Message>();
        }
    }
    
    @Override
    public void enqueue(Message message) {
        synchronized (mutex) {
            getList(message).addLast(message);
            this.size++;
            mutex.notify();
        }
    }

    @Override
    public void enqueueFirst(Message message) {
        synchronized (mutex) {
            getList(message).addFirst(message);
            this.size++;
            mutex.notify();
        }
    }
    
    @Override
    public boolean isEmpty() {
        return this.size == 0;
    }
    
    @Override
    public Message dequeue(long timeout) throws InterruptedException {
        synchronized (mutex) {
            while (timeout != 0 && !closed && (isEmpty() || !running)) {
                if (timeout == -1) {
                    mutex.wait();
                } else {
                    mutex.wait(timeout);
                    break;
                }
            }
            if (closed || !running || isEmpty()) {
                return null;
            }
            return removeFirst();
        }
    }
    
    @Override
    public Message dequeueNoWait() {
        synchronized (mutex) {
            if (closed || !running || isEmpty()) {
                return null;
            }
            return removeFirst();
        }
    }

    @Override
    public Message peek() {
        synchronized (mutex) {
            if (closed || !running || isEmpty()) {
                return null;
            }
            return getFirst();
        }
    }

    @Override
    public void start() {
        synchronized (mutex) {
            running = true;
            mutex.notifyAll();
        }
    }

    @Override
    public void stop() {
        synchronized (mutex) {
            running = false;
            mutex.notifyAll();
        }
    }

    @Override
    public void close() {
        synchronized (mutex) {
            if (!closed) {
                running = false;
                closed = true;
            }
            mutex.notifyAll();
        }
    }

    @Override
    public void clear() {
        synchronized (mutex) {
            for (int i = 0; i < Message.MAX_PRIORITY; i++) {
                lists[i].clear();
            }
            this.size = 0;
        }
    }

    @Override
    public boolean isClosed() {
        return closed;
    }

    @Override
    public int size() {
        synchronized (mutex) {
            return this.size;
        }
    }

    @Override
    public Object getMutex() {
        return mutex;
    }

    @Override
    public boolean isRunning() {
        return running;
    }

    @Override
    public List<Message> removeAll() {
        synchronized (mutex) {
            ArrayList<Message> result = new ArrayList<Message>(size());
            for (int i = Message.MAX_PRIORITY - 1; i >= 0; i--) {
                List<Message> list = lists[i];
                result.addAll(list);
                size -= list.size();
                list.clear();
            }
            return result;
        }
    }
    
    @Override
    public String toString() {
        String result = "";
        for (int i = Message.MAX_PRIORITY - 1; i >= 0; i--) {
            result += i + ":{" + lists[i].toString() + "}";
        }
        return result;
    }
    
    protected int getPriority(Message message) {
        int priority = Message.DEFAULT_PRIORITY;
        if (message != null) {
            priority = Math.max(message.getPriority(), 0);
            priority = Math.min(priority, 9);
        }
        return priority;
    }
    
    protected LinkedList<Message> getList(Message md) {
        return lists[getPriority(md)];
    }
    
    private final Message removeFirst() {
        if (this.size > 0) {
            for (int i = Message.MAX_PRIORITY - 1; i >= 0; i--) {
                LinkedList<Message> list = lists[i];
                if (!list.isEmpty()) {
                    this.size--;
                    return list.removeFirst();
                }
            }
        }
        return null;
    }
    
    private final Message getFirst() {
        if (this.size > 0) {
            for (int i = Message.MAX_PRIORITY - 1; i >= 0; i--) {
                LinkedList<Message> list = lists[i];
                if (!list.isEmpty()) {
                    return list.getFirst();
                }
            }
        }
        return null;
    }
}
