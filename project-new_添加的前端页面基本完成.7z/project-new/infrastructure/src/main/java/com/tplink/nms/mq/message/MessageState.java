package com.tplink.nms.mq.message;

/**
 * Created by simon on 2015/1/27.
 */
public enum MessageState {
    INIT, ONQUEUE, ONPIPELINE, SUCCESS, FAILED, TIMEOUT,CONSUMED;
}
