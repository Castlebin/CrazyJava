package com.tplink.nms.mvc.dao;

import com.tplink.nms.mvc.bean.Grid;
import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.utils.FilterHql;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.util.Assert;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Simon Wei on 2015/4/22.
 */
public abstract class BaseDao<T> {
    private Class<T> entityClass;
    private Session session;

    @Autowired
    private HibernateTemplate hibernateTemplate;

    public BaseDao() {
        Type genType = getClass().getGenericSuperclass();
        Type[] params = ((ParameterizedType) genType).getActualTypeArguments();
        entityClass = (Class) params[0];
    }

    public T load(Serializable id) {
        return getTemplate().load(entityClass, id);
    }

    public T get(Serializable id) {
        return getTemplate().get(entityClass, id);
    }

    public List<T> loadAll() {
        return getTemplate().loadAll(entityClass);
    }

    public void add(Serializable t) {
        getTemplate().save(t);
    }

    public void addAll(List<T> l) {
        getTemplate().saveOrUpdate(l);
    }


    public void delete(T t) {
        getTemplate().delete(t);
    }

    public void deleteAll(List<T> l) {
        getTemplate().deleteAll(l);
    }

    public void update(T t) {
        getTemplate().update(t);
    }

    public void saveOrUpdate(T t) {
        getTemplate().saveOrUpdate(t);
    }

    public List<T> find(T t) {
        return getTemplate().findByExample(t);
    }

    public List<?> find(String hql) {
        return getTemplate().find(hql);
    }

    public List<?> find(String hql, Object... values) {
        return getTemplate().find(hql, values);
    }

    public void initialize(Object entity) {
        getTemplate().initialize(entity);
    }

    public Session getSession() {
        session = SessionFactoryUtils.getSession(getTemplate().getSessionFactory(), true);
        return session;
    }
    public void releaseSession(){
        SessionFactoryUtils.releaseSession(session, getTemplate().getSessionFactory());
        session = null;
    }

    public HibernateTemplate getTemplate() {
        return hibernateTemplate;
    }

    public Grid pagedQuery(Class domainClass, Grid grid, ArrayList<QueryCondition> filter){
        return pagedQuery(FilterHql.getFilterHql(domainClass, filter), grid, FilterHql.getFilterValues(filter));
    }
    /**
     * 分页查询函数，使用hql.
     */
    public Grid pagedQuery(String hql, Grid grid, Object... values) {
        Assert.hasText(hql);
        if (grid == null)
            grid = new Grid();

        try {
            // Count查询
            String countQueryString = " select count (*) " + removeSelect(removeOrders(hql));
            List countlist = getTemplate().find(countQueryString, values);
            grid.setTotalRows((long)countlist.get(0));

            // 实际查询返回分页对象
            long startIndex = grid.getStart();
            Query query = createQuery(hql, values);
            List list = query.setFirstResult((int) startIndex).setMaxResults(grid.getPageSize()).list();
            grid.setRows(list);
            releaseSession();
        }catch (Exception e){
            e.printStackTrace();
        }

        return grid;
    }

    /**
     * 创建Query对象. 对于需要first,max,fetchsize,cache,cacheRegion等诸多设置的函数,可以在返回Query后自行设置.
     * 留意可以连续设置,如下：
     * <pre>
     * dao.getQuery(hql).setMaxResult(100).setCacheable(true).list();
     * </pre>
     * 调用方式如下：
     * <pre>
     *        dao.createQuery(hql)
     *        dao.createQuery(hql,arg0);
     *        dao.createQuery(hql,arg0,arg1);
     *        dao.createQuery(hql,new Object[arg0,arg1,arg2])
     * </pre>
     *
     * @param values 可变参数.
     */
    public Query createQuery(String hql, Object... values) {
        Assert.hasText(hql);
        Query query = getSession().createQuery(hql);
        for (int i = 0; i < values.length; i++) {
            query.setParameter(i, values[i]);
        }
        return query;
    }

    /**
     * 去除hql的select 子句，未考虑union的情况,用于pagedQuery.
     */
    private static String removeSelect(String hql) {
        Assert.hasText(hql);
        int beginPos = hql.toLowerCase().indexOf("from");
        Assert.isTrue(beginPos != -1, " hql : " + hql + " must has a keyword 'from'");
        return hql.substring(beginPos);
    }

    /**
     * 去除hql的orderby 子句，用于pagedQuery.
     */
    private static String removeOrders(String hql) {
        Assert.hasText(hql);
        Pattern p = Pattern.compile("order\\s*by[\\w|\\W|\\s|\\S]*", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(hql);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            m.appendReplacement(sb, "");
        }
        m.appendTail(sb);
        return sb.toString();
    }
}
