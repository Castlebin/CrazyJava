package com.tplink.nms.schedule;

import com.tplink.nms.module.ModuleRunException;
import org.quartz.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Simon Wei on 2015/4/8.
 */
public class TaskManager {
    public static Scheduler scheduler;
    public static Map<String, TaskInfo> taskList = new HashMap<String, TaskInfo>();

    public static void init() throws ModuleRunException {

        SchedulerFactory schedFact = new org.quartz.impl.StdSchedulerFactory();

        try {
            scheduler = schedFact.getScheduler();
            scheduler.start();
        } catch (SchedulerException e) {
            throw new ModuleRunException("Scheduler start error.", e);
        }
    }

    public static void stop() {
        if (scheduler != null) {
            try {
                scheduler.shutdown();
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized static void addTask(TaskInfo taskInfo) {
        assert taskInfo == null;

        taskList.put(taskInfo.getTaskName(), taskInfo);
    }

    public synchronized static void addAndExecTask(TaskInfo taskInfo) throws TaskExecException {
        addTask(taskInfo);
        execTask(taskInfo.getTaskName());
    }

    public synchronized static void execTask(String taskName) throws TaskExecException {
        TaskInfo info = taskList.get(taskName);
        if (info == null) return;

        try {
            scheduler.scheduleJob(info.generateJobDetail(), info.generateJobTrigger());
        } catch (SchedulerException e) {
            throw new TaskExecException(e.getMessage());
        }
    }

    public synchronized static void cancelTask(String taskName) {
        TaskInfo info = taskList.get(taskName);
        try {
            TriggerKey key = new TriggerKey(info.getKeyName(), info.getKeyGroup());

            scheduler.pauseTrigger(key);
            scheduler.unscheduleJob(key);
            scheduler.deleteJob(new JobKey(info.getKeyName(), info.getKeyGroup()));
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
    }

    public static void deleteTask(String taskName) {

    }
}
