package com.tplink.nms.config;

import com.tplink.nms.utils.FileUtil;
import com.tplink.nms.utils.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.SystemPropertyUtils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ConfigurationFactory {
    private static final String PROPERTIES_SUFFIX = ".properties";
    private static Logger logger = LoggerFactory
            .getLogger(ConfigurationFactory.class);
    private static final Map<String, Configuration> configurations = new HashMap<String, Configuration>();

    /**
     * Load configuration by File, if file doesn't exist or is directory , return null
     *
     * @param file
     * @return
     */
    private static synchronized Configuration loadConfiguration(File file) {
        if (file == null || !file.exists() || file.isDirectory()) {
            return null;
        }

        if (!configurations.containsKey(file.getName())) {
            Configuration configuration = new Configuration(file);
            if (configuration.isValid()) {
                configurations.put(file.getName(), configuration);
                logger.info("success to load configuration : " + file.getName());
            }
            return configuration;
        } else {
            return configurations.get(file.getName());
        }
    }


    /**
     * Returns Configuration related to file with specified path , path can be resource in classpath
     * or OS path or relative path
     *
     * @param path
     * @return
     */
    public static Configuration loadConfiguration(String path) {
        if (StringUtil.isNull(path)) {
            return null;
        }
        if (configurations.containsKey(path)) {
            return configurations.get(path);
        }

        File file = FileUtil.getConfFile(path);

        return loadConfiguration(file);
    }

    /**
     * Load Configurations from a directory
     *
     * @param file
     * @throws java.io.IOException
     */
    public static void loadConfigurationDir(File file) throws IOException {
        if (file.exists() && file.isDirectory()) {
            for (File subFile : file.listFiles()) {
                if (!subFile.isDirectory() && subFile.getName().endsWith(PROPERTIES_SUFFIX)) {
                    loadConfiguration(subFile);
                } else if (subFile.isDirectory()) {
                    loadConfigurationDir(subFile);
                }
            }
        }
    }

    /**
     * Load Configurations from a directory
     *
     * @param path
     * @throws java.io.IOException
     */
    public static void loadConfigurationDir(String path) throws IOException {
        logger.debug("start to load configurations from dir :" + path);
        File file = FileUtil.getFile(path);
        loadConfigurationDir(file);
    }

}
