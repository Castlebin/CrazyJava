package com.tplink.nms.commons;

import com.tplink.nms.i18n.L;
import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;
import com.tplink.nms.rmi.bean.LaunchInfoBean;
import com.tplink.nms.utils.FacadeUtil;

/**
 * Created by simon on 2015/5/6.
 */
public class NmsStartedModule extends AbstractModule {
    private L l = L.getInstance(NmsStartedModule.class);

    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
        FacadeUtil.sendCommand(LaunchInfoBean.InfoType.STARTED, l.get("launch.started"));
    }
}
