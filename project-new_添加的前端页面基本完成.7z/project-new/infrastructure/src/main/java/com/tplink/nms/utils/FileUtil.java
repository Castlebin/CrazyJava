package com.tplink.nms.utils;

import com.tplink.nms.config.PropertyKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * @author Rocky Li
 */
public class FileUtil {
    private static final Logger logger = LoggerFactory.getLogger(FileUtil.class);

    public static File getFile(String filePath, Class clazz) {
        File file = null;
        URL url = getUrlByClassLoader(filePath);
        if (null == url) {
            String filePathWithDir = "conf" + File.separator + filePath;
            url = getUrlByClassLoader(filePathWithDir);
        }

        if (null != url) {
            try {
                file = new File(url.toURI());
            } catch (URISyntaxException e) {
                logger.warn("exception .", e);
            }
        }

        if (file == null || !file.exists()) {
            String pathTemp = FileUtil.getClassPath(clazz) + File.separator + filePath;
            file = new File(pathTemp);
        }

        if (null == file || !file.exists()) {
            file = new File(filePath);
        }

        return file;
    }

    public static File getFile(String filePath) {
        return getFile(filePath, FileUtil.class);
    }

    public static File getConfFile(String path, Class clazz) {
        File file = FileUtil.getFile(path);

        if (file == null || !file.exists()) {
            String pathTemp = System.getProperty(PropertyKey.HOME_KEY_SUFFIX) + File.separator + "conf" + File.separator
                    + path;
            file = FileUtil.getFile(pathTemp);
        }

        if (file == null || !file.exists()) {
            String pathTemp = FileUtil.getClassPath(clazz) + File.separator + "conf" + File.separator + path;
            file = FileUtil.getFile(pathTemp);
        }
        return (file != null && file.exists()) ? file : null;
    }

    public static File getConfFile(String path) {
        return getConfFile(path, FileUtil.class);
    }

    private static URL getUrlByClassLoader(String filePath) {
        URL url = Thread.currentThread().getContextClassLoader().getResource(filePath);
        if (null == url) {
            url = FileUtil.class.getClassLoader().getResource(filePath);
        }
        if (null == url) {
            url = ClassLoader.getSystemClassLoader().getResource(filePath);
        }
        return url;
    }

    public static String getClassPath(Class cls) {
        if (cls == null)
            return null;

        String path = "";

        ClassLoader loader = cls.getClassLoader();
        String clsName = cls.getName() + ".class";
        Package pack = cls.getPackage();
        if (pack != null) {
            String packName = pack.getName();
            if (packName.startsWith("java.") || packName.startsWith("javax."))
                return null;
            clsName = clsName.substring(packName.length() + 1);

            if (packName.indexOf(".") < 0)
                path = packName + "/";
            else {
                int start = 0, end = 0;
                end = packName.indexOf(".");
                while (end != -1) {
                    path = path + packName.substring(start, end) + "/";
                    start = end + 1;
                    end = packName.indexOf(".", start);
                }
                path = path + packName.substring(start) + "/";
            }
        }
        java.net.URL url = loader.getResource(path + clsName);
        String realPath = url.getPath();
        int pos = realPath.indexOf("file:");
        if (pos > -1)
            realPath = realPath.substring(pos + 5);
        pos = realPath.indexOf(path + clsName);
        realPath = realPath.substring(0, pos - 1);
        if (realPath.endsWith("!"))
            realPath = realPath.substring(0, realPath.lastIndexOf("/"));
        try {
            realPath = java.net.URLDecoder.decode(realPath, "utf-8");
        } catch (UnsupportedEncodingException e) {
        }

        return realPath;
    }

    public static String getParentPath(String path) {
        return path.substring(0, path.lastIndexOf('/'));
    }
}
