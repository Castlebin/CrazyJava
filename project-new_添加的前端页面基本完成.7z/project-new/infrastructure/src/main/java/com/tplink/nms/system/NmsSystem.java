package com.tplink.nms.system;

import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Simon Wei on 2015/4/13.
 */
public class NmsSystem {
    private static long fileModifyTime = 0;
    private static Map<String, Handler> handlers = new HashMap<>();

    public static long getModifyTime() {
        if (fileModifyTime == 0) {
            try {
                PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
                String path = "classpath:" + NmsSystem.class.getName().replace(".", File.separator)
                        + ".class";
                Resource resource = resolver.getResource(path);

                fileModifyTime = resource.lastModified();
            } catch (Exception e) {
                fileModifyTime = System.currentTimeMillis();
            }
        }

        return fileModifyTime;
    }

    public static void addHandler(String name, Handler handler) {
        if (handler != null && name != null) {
            handlers.put(name, handler);
        }
    }

    public static void executeHandler(String name, Object... objects) {
        Handler handler = handlers.get(name);
        if (handler != null) {
            handler.handle(objects);
        }
    }
}
