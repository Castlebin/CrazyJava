package com.tplink.nms.mq;


import com.tplink.nms.mq.message.Message;
import com.tplink.nms.mq.message.SimpleMessage;

/**
 * Created by simon on 2015/1/26.
 */
public class MQ {
    public static Message newMessage(String name, Object o) {
        /* Add Message Cache */
        return new SimpleMessage(name, o);
    }

    public static void call(Message message) {
        push(message);
    }

    public static void call(String name, Message message) {
        message.setMessageName(name);
        call(message);
    }

    public static void push(Message message) {
        MQModule module = MQManager.getModule(message.getModuleName());
        if(module == null) {
            return;
        }

        module.processMessage(message);
    }
}
