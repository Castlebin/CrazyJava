package com.tplink.nms.schedule;

/**
 * Created by Simon Wei on 2015/4/9.
 */
public class TaskExecException extends Exception{
    public TaskExecException(){}

    public TaskExecException(String msg) {
        super(msg);
    }
}
