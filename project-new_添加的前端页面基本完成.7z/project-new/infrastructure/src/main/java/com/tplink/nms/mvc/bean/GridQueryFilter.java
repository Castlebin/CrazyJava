package com.tplink.nms.mvc.bean;

import java.util.ArrayList;
import java.util.Map;

/**
 * Created by Simon Wei on 2015/4/23.
 */
public interface GridQueryFilter {
    public void filter(Map<String, Object> query, ArrayList<QueryCondition> queryConditions);
}
