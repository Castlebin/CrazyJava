package com.tplink.nms.utils;

import com.tplink.nms.rmi.bean.LaunchInfoBean;

import java.rmi.RemoteException;

/**
 * Created by simon on 2015/5/6.
 */
public class FacadeUtil {
    private static LaunchInfoBean launchInfo = null;

    public static void setLaunchInfo(LaunchInfoBean launchInfo){
        FacadeUtil.launchInfo = launchInfo;
    }

    public static void sendCommand(LaunchInfoBean.InfoType type, String msg){
        if(launchInfo != null){
            try {
                launchInfo.sendMessage(type, msg);
            } catch (RemoteException e) {
            }
        }
    }

    public static void sendHeartbeat() throws RemoteException {
        if(launchInfo != null){
            launchInfo.sendMessage(LaunchInfoBean.InfoType.HEARTBEAT, null);
        }
    }
}
