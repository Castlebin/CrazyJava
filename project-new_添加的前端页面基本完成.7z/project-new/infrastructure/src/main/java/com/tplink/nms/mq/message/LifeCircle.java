package com.tplink.nms.mq.message;

/**
 * Created by simon on 2015/1/27.
 */
public interface LifeCircle {
    public void recycle();
    public void switchState(MessageState state);
}
