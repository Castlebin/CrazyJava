package com.tplink.nms.debug;

import com.tplink.nms.config.PropertyKey;
import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;
import com.tplink.nms.utils.FileUtil;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

/**
 * Created by Simon Wei on 2015/4/2.
 */
public class DebugModule extends AbstractModule {
    private Logger logger = LoggerFactory.getLogger(DebugModule.class);

    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
        initLog4j();
    }

    private void initLog4j() {
        File log4jFile = FileUtil.getConfFile(PropertyKey.LOG4J_PROPERTIES_FILE_NAME);

        if (log4jFile != null && log4jFile.exists()) {
            PropertyConfigurator.configure(log4jFile.getAbsolutePath());
            logger.debug("Log4j init OK");
        }else{
            logger.debug("Log4j configuration file lost.");
        }
    }
}
