/**
 * Copyright(c) 2008-2013 Shenzhen TP-LINK Technologies Co.Ltd.
 */
package com.tplink.nms.mvc.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Simon Wei
 * @date 2014-3-10
 */
public class Grid<T> {
    private int page = 1;
    private int pageSize = 10;
    private long pageNum = 0;
    private String sortName = "";
    private String sortOrder = "asc";

    private List<T> rows = null;

    private Map<String, Object> filter = null;

    public Grid() {

    }

    /**
     *
     */
    public Grid(int page, int pageSize, String sortname, String sortorder) {
        this.page = page;
        this.pageSize = pageSize;
        this.sortName = sortname;
        this.sortOrder = sortorder;
    }

    public long getStart() {
        return (getPage() - 1) * pageSize;
    }
    public void setTotalRows(long totalRows){
        pageNum = (totalRows % pageSize == 0) ? (totalRows / pageSize) : (totalRows / pageSize + 1);
    }

    public ArrayList<QueryCondition> getQueryConditionList() {
        return getQueryConditionList(null, null);
    }

    public ArrayList<QueryCondition> getQueryConditionList(GridQueryFilter filter){
        return getQueryConditionList(null, filter);
    }

    public ArrayList<QueryCondition> getQueryConditionList(Map<String, String> sortNameSwitch) {
        return getQueryConditionList(sortNameSwitch, null);
    }

    public ArrayList<QueryCondition> getQueryConditionList(Map<String, String> sortNameSwitch, GridQueryFilter filter) {
        ArrayList<QueryCondition> queryConditions = new ArrayList<>();
        if (!getSortName().equals("false")) {
            QueryCondition.QueryType qt = getSortOrder().equals("asc") ? QueryCondition.QueryType.asc : QueryCondition.QueryType.desc;
            queryConditions.add(new QueryCondition(sortNameSwitch == null ? getSortName() : sortNameSwitch.get(getSortName()), "", qt));
        }

        if (filter != null && this.filter != null) {
            filter.filter(this.filter, queryConditions);
        }

        return queryConditions;
    }

    public boolean isHasNextPage() {
        return page < pageNum;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("[");
        builder.append("Page:").append(pageNum).append("/").append(page).append(";");
        builder.append("Page Size:").append(pageSize).append(";");
        builder.append("Sort:").append(sortName).append(",").append(sortOrder).append(";");

        if (filter != null && filter.size() != 0) {
            builder.append("Query:");
            for (Map.Entry<String, Object> entry : filter.entrySet()) {
                builder.append(entry.getKey()).append("=").append(entry.getValue()).append(",");
            }
            builder.append(";");
        }

        builder.append("Rows size:").append(rows.size()).append("]");

        return builder.toString();
    }

    /**
     * @return the page
     */
    public long getPage() {
        return page;
    }

    /**
     * @param page the page to set
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * @return the pageSize
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * @param pageSize the pageSize to set
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * @return the pageNum
     */
    public long getPageNum() {
        return pageNum;
    }

    /**
     * @param pageNum the pageNum to set
     */
    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    /**
     * @return the sortName
     */
    public String getSortName() {
        return sortName;
    }

    /**
     * @param sortName the sortName to set
     */
    public void setSortName(String sortName) {
        this.sortName = sortName;
    }

    /**
     * @return the sortOrder
     */
    public String getSortOrder() {
        return sortOrder;
    }

    /**
     * @param sortOrder the sortOrder to set
     */
    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    /**
     * @return the rows
     */
    public List<T> getRows() {
        return rows;
    }

    /**
     * @param rows the rows to set
     */
    public void setRows(List<T> rows) {
        this.rows = rows;
    }

    public void addRow(T row) {
        this.rows.add(row);
    }

    /**
     * @return the filter
     */
    public Map<String, Object> getFilter() {
        return filter;
    }

    /**
     * @param filter the filter to set
     */
    public void setFilter(Map<String, Object> filter) {
        this.filter = filter;
    }

    public Object getFilterByName(String name) {
        return this.filter.get(name);
    }
}
