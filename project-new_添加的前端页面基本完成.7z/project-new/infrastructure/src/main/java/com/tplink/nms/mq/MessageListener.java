package com.tplink.nms.mq;


import com.tplink.nms.mq.message.Message;

/**
 * Created by simon on 2015/1/27.
 */
public interface MessageListener {
    public Message onAction(Message message);
}
