package com.tplink.nms.mq.message;

/**
 * Created by simon on 2015/1/27.
 */
public class MQException extends Exception {

    public MQException(String message) {
        super(message);
    }
}
