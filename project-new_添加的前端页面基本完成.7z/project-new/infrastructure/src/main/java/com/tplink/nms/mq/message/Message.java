package com.tplink.nms.mq.message;

/**
 * Created by simon on 2015/1/27.
 */
public interface Message extends LifeCircle {
    public static final Integer DEFAULT_PRIORITY = 5;
    public static final Integer MAX_PRIORITY     = 10;
    
    public void init(String name, Object o);
    
    public void setMessageName(String name);
    
    public String getMessageName();
    
    public String getModuleName();
    
    public String getMethodName();
    
    public MessageCallType getMessageCallType();
    
    public void setMessageCallType(MessageCallType type);
    
    public Object getMessageBody();
    
    public void setMessageBody(Object body);
    
    public void lock();
    
    public void unlock();
    
    public long getTimestamp();
    
    public boolean isExit();
    
    public void setExit(boolean isExit);
    
    public int getPriority();
    
    void setPriority(int priority);
}
