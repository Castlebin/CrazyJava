package com.tplink.nms.mq.command;

import com.tplink.nms.mq.MQ;
import com.tplink.nms.mq.MQManager;
import com.tplink.nms.mq.MQModule;
import com.tplink.nms.mq.MessageListener;
import com.tplink.nms.mq.message.MQException;
import com.tplink.nms.mq.message.Message;
import com.tplink.smb.command.annotion.Cli;
import com.tplink.smb.command.annotion.Command;
import com.tplink.smb.command.io.CommandIO;

import java.util.ArrayList;

/**
 * Created by Simon Wei on 2015/4/20.
 */
@Cli(scope = "mq")
public class MQCommand {

    @Command
    public void newModule(String name) {
        MQManager.newModule(name);
    }

    @Command
    public void newListener(String name) throws MQException {
        MQManager.addMessageListener(name, new MessageListener() {
            @Override
            public Message onAction(Message message) {

                CommandIO.COUT.println(message.getMessageBody());

                return message;
            }
        });
    }

    @Command
    public void newMessage(String name, String body) {
        MQ.push(MQ.newMessage(name, body));
    }

    @Command
    public void mqStop() {
        newMessage("module.stop", "");
    }

    @Command
    public void showModules() {
        ArrayList<MQModule> mqModules = MQManager.getModules();
        StringBuilder builder = new StringBuilder("MQ Modules : \r\n");
        for (MQModule module : mqModules) {
            builder.append(module.toString());
        }
        CommandIO.COUT.println(builder.toString());
    }
}
