package com.tplink.nms.mvc.bean;


/**
 * @author fdj
 */
public class QueryCondition {
    public enum QueryType {
        equal, unequal, great, less, like, asc, desc
    }

    private String queryName;
    private Object queryValue;
    private QueryType queryType;

    public String getQueryName() {
        return queryName;
    }

    public void setQueryName(String queryName) {
        this.queryName = queryName;
    }

    public Object getQueryValue() {
        return queryValue;
    }

    public void setQueryValue(Object queryValue) {
        this.queryValue = queryValue;
    }

    public QueryType getQueryType() {
        return queryType;
    }

    public void setQueryType(QueryType queryType) {
        this.queryType = queryType;
    }

    public QueryCondition() {

    }

    public QueryCondition(String queryName, Object queryValue, QueryType queryType) {
        this.queryName = queryName;
        this.queryValue = queryValue;
        this.queryType = queryType;
    }
}
