package com.tplink.nms.debug;

import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;
import com.tplink.smb.command.Command;

/**
 * Created by Simon Wei on 2015/4/2.
 */
public class CommandModule extends AbstractModule {
    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
        Command.init();
        Command.start("ssh");
    }
}


