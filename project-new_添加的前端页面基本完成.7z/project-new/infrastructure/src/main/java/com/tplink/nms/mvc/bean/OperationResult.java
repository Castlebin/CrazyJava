package com.tplink.nms.mvc.bean;

/**
 * @author fdj
 */
public class OperationResult {
    private String operStatus;
    private String description;
    private Object relativeInfo;

    public static OperationResult DEFAULT_SUCCESS = new OperationResult("success", "", null);
    public static OperationResult DEFAULT_FAIL = new OperationResult("fail", "", null);

    public String getOperStatus() {
        return operStatus;
    }

    public void setOperStatus(String operStatus) {
        this.operStatus = operStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Object getRelativeInfo() {
        return relativeInfo;
    }

    public void setRelativeInfo(Object relativeInfo) {
        this.relativeInfo = relativeInfo;
    }

    public OperationResult(String operStatus, String description, Object relativeInfo) {
        this.operStatus = operStatus;
        this.description = description;
        this.relativeInfo = relativeInfo;
    }
}
