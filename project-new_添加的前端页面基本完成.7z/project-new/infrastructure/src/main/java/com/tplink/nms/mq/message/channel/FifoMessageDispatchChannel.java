package com.tplink.nms.mq.message.channel;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.tplink.nms.mq.message.Message;

public class FifoMessageDispatchChannel implements MessageDispatchChannel {

    private final Object mutex = new Object();
    private final LinkedList<Message> list;
    private boolean closed;
    private boolean running;

    public FifoMessageDispatchChannel() {
        this.list = new LinkedList<Message>();
    }

    public void enqueue(Message message) {
        synchronized (mutex) {
            list.addLast(message);
            mutex.notify();
        }
    }

    public void enqueueFirst(Message message) {
        synchronized (mutex) {
            list.addFirst(message);
            mutex.notify();
        }
    }

    public boolean isEmpty() {
        synchronized (mutex) {
            return list.isEmpty();
        }
    }


    public Message dequeue(long timeout) throws InterruptedException {
        synchronized (mutex) {
            while (timeout != 0 && !closed && (list.isEmpty() || !running)) {
                if (timeout == -1) {
                    mutex.wait();
                } else {
                    mutex.wait(timeout);
                    break;
                }
            }
            if (closed || !running || list.isEmpty()) {
                return null;
            }
            return list.removeFirst();
        }
    }

    public Message dequeueNoWait() {
        synchronized (mutex) {
            if (closed || !running || list.isEmpty()) {
                return null;
            }
            return list.removeFirst();
        }
    }

    public Message peek() {
        synchronized (mutex) {
            if (closed || !running || list.isEmpty()) {
                return null;
            }
            return list.getFirst();
        }
    }

    public void start() {
        synchronized (mutex) {
            running = true;
            mutex.notifyAll();
        }
    }

    public void stop() {
        synchronized (mutex) {
            running = false;
            mutex.notifyAll();
        }
    }

    public void close() {
        synchronized (mutex) {
            if (!closed) {
                running = false;
                closed = true;
            }
            mutex.notifyAll();
        }
    }

    public void clear() {
        synchronized (mutex) {
            list.clear();
        }
    }

    public boolean isClosed() {
        return closed;
    }

    public int size() {
        synchronized (mutex) {
            return list.size();
        }
    }

    public Object getMutex() {
        return mutex;
    }


    public boolean isRunning() {
        return running;
    }


    public List<Message> removeAll() {
        synchronized (mutex) {
            ArrayList<Message> rc = new ArrayList<Message>(list);
            list.clear();
            return rc;
        }
    }

    @Override
    public String toString() {
        synchronized (mutex) {
            return list.toString();
        }
    }
}
