package com.tplink.nms.mq;

import com.tplink.nms.mq.message.Message;
import com.tplink.nms.mq.message.channel.MessageDispatch;

/**
 * Created by simon on 2015/1/26.
 */
public class MQModule {
    private String          moduleName = "nul";
    private MessageDispatch dispatch   = new MessageDispatch();
    private MessagePipeline pipeline   = null;
    private boolean         isRunning  = false;
    
    protected MQModule(String name) {
        this(name, SimpleMessagePipeline.class);
    }
    
    protected MQModule(String name, Class<? extends MessagePipeline> pipelineClass) {
        moduleName = name;
        try {
            pipeline = pipelineClass.newInstance();
        } catch (Exception e) {
        } finally {
            if (pipeline == null) {
                pipeline = new SimpleMessagePipeline();
            }
        }
        
        dispatch.setMessagePipeline(pipeline);
    }
    
    public void start() {
        if (isRunning)
            return;
        
        isRunning = true;
        dispatch.start();
    }
    
    public void stop() {
        if (!isRunning)
            return;
        dispatch.stop();
        isRunning = false;
    }
    
    public void stopWaitProcessed() {
        
    }
    
    public void setPipeline(MessagePipeline pipeline) {
        this.pipeline = pipeline;
    }
    
    public String getModuleName() {
        return moduleName;
    }
    
    public void processMessage(Message message) {
        dispatch.push(message);
    }
    
    public void addMessageListener(String name, MessageListener listener) {
        pipeline.addMessageListener(name, listener);
    }
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("Module name : ");
        builder.append(moduleName).append("\r\n");
        builder.append(pipeline.toString());
        return builder.toString();
    }
}
