package com.tplink.nms.schedule.command;

import com.tplink.nms.schedule.TaskExecException;
import com.tplink.nms.schedule.TaskInfo;
import com.tplink.nms.schedule.TaskManager;
import com.tplink.smb.command.annotion.Cli;
import com.tplink.smb.command.annotion.Command;
import com.tplink.smb.command.io.CommandIO;

import java.util.Map;

/**
 * Created by Simon Wei on 2015/4/9.
 */
@Cli(scope = "task")
public class TaskCommand {

    @Command
    public void startTask(String taskName) {
        try {
            TaskManager.execTask(taskName);
        } catch (TaskExecException e) {
            e.printStackTrace();
        }
    }

    @Command
    public void cancelTask(String taskName) {
        TaskManager.cancelTask(taskName);
    }

    @Command
    public void showTask() {
        StringBuilder builder = new StringBuilder("[\n");

        for (Map.Entry<String, TaskInfo> taskInfo : TaskManager.taskList.entrySet()) {
            builder.append(" [task:");
            builder.append(taskInfo.getValue().getTaskName());
            builder.append("]\n");
        }

        builder.append("]");
        CommandIO.COUT.println(builder.toString());
    }
}
