package com.tplink.nms.mq.exception;

public class MessageException extends RuntimeException {
    
    public MessageException(String message) {
        super(message);
    }
    
    public MessageException(String message, Throwable cause) {
        super(message, cause);
    }
    
    /**
     * 
     */
    private static final long serialVersionUID = -7532990544772493975L;
    
}
