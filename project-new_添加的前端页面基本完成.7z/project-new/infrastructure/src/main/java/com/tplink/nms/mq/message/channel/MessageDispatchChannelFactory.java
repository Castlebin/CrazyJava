package com.tplink.nms.mq.message.channel;

public class MessageDispatchChannelFactory {
    public static MessageDispatchChannel createFifoMessageDispatchChannel() {
        return new FifoMessageDispatchChannel();
    }
    
    public static MessageDispatchChannel createPriorityMessageDispatchChannel() {
        return new PriorityMessageDispatchChannel();
    }
}
