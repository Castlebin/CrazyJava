package com.tplink.nms.config;

import com.tplink.nms.utils.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

public class Configuration {

    private final Properties originalProperties;
    private boolean isValid = false;
    private final Map<String, String> resolvedPropertiesMap;
    private static final String PLACEHOLDER_START = "${";
    public static final Logger logger = LoggerFactory
            .getLogger(Configuration.class);

    /**
     * new a Configuration with specific file
     *
     * @param file
     */
    public Configuration(File file) {
        originalProperties = new Properties();
        resolvedPropertiesMap = new HashMap<String, String>();
        loadProperties(file);
    }

    /**
     * load properties and resolve key-value in this file .
     *
     * @param file
     */
    private void loadProperties(File file) {
        FileInputStream inpf = null;
        try {
            inpf = new FileInputStream(file);
            originalProperties.load(inpf);
            resolve();
            isValid = true;
        } catch (IOException e) {
            logger.warn("load properties file failed .", e);
        } finally {
            try {
                if (null != inpf) {
                    inpf.close();
                }
            } catch (IOException e) {
                logger.warn("load properties file failed .", e);
            }
            inpf = null;
        }
    }

    /**
     * resolve properties which may contains placeholder , replace ${home} with a string defined
     * above
     */
    private void resolve() {
        Iterator<Entry<Object, Object>> it = originalProperties.entrySet().iterator();
        while (it.hasNext()) {
            final Entry<Object, Object> entry = it.next();
            final String key = (String) entry.getKey();
            final String toBeResolved = (String) entry.getValue();
            String resolved = resolvePlaceHolder(toBeResolved);
            if (null == resolved) {
                logger.warn("can't get resolve value for key: " + key);
            } else {
                resolvedPropertiesMap.put(key, resolved);
            }
        }
    }

    /**
     * return value by key from resolved key-value map , if invalid return null
     *
     * @param key
     * @return
     */
    public String getProperty(String key) {
        String value = isValid ? resolvedPropertiesMap.get(key) : null;
        return (value == null) ? System.getProperty(key) : value;
    }

    /**
     * replace ${key} with known value by key
     *
     * @param toBeResolved
     * @return
     */
    private String resolvePlaceHolder(String toBeResolved) {
        if (toBeResolved.indexOf(PLACEHOLDER_START) < 0) {
            return toBeResolved;
        }
        StringBuffer buff = new StringBuffer();
        char[] chars = toBeResolved.toCharArray();
        for (int pos = 0; pos < chars.length; pos++) {
            if (chars[pos] == '$') {
                if (chars[pos + 1] == '{') {
                    String resolvedKey = "";
                    int x = pos + 2;
                    for (; x < chars.length && chars[x] != '}'; x++) {
                        resolvedKey += chars[x];
                        if (x == chars.length - 1) {
                            throw new IllegalArgumentException("unmatched placeholder start ["
                                    + toBeResolved + "]");
                        }
                    }
                    String resolvedValue = resolvedPropertiesMap.get(resolvedKey);
                    if (null == resolvedValue) {
                        if (null != System.getProperty(resolvedKey)) {
                            resolvedValue = System.getProperty(resolvedKey);
                        } else {
                            String parentOriginalValue = (String) originalProperties
                                    .get(resolvedKey);
                            if (null == parentOriginalValue) {
                                return null;
                            } else {
                                resolvedValue = resolvePlaceHolder(parentOriginalValue);
                            }
                        }
                    }
                    buff.append(resolvedValue);
                    pos = x + 1;
                    if (pos >= chars.length) {
                        break;
                    }
                }
            }
            buff.append(chars[pos]);
        }
        String rtn = buff.toString();
        return StringUtil.isNull(rtn) ? null : rtn;
    }

    /**
     * @return
     */
    public boolean isValid() {
        return isValid;
    }

}
