package com.tplink.nms.module.command;

import com.tplink.nms.module.ModuleContext;
import com.tplink.smb.command.annotion.Cli;
import com.tplink.smb.command.annotion.Command;
import com.tplink.smb.command.io.CommandIO;

/**
 * Created by Simon Wei on 2015/4/2.
 */
@Cli(scope = "module")
public class ModuleCommand {

    @Command
    public void showModules(){
        String modules = ModuleContext.getModuleContextInstance().toString();
        CommandIO.COUT.println(modules);
    }
}
