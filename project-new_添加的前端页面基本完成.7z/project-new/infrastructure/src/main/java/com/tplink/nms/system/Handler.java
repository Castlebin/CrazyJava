package com.tplink.nms.system;

/**
 * Created by simon on 2015/5/7.
 */
public interface Handler {
    public void handle(Object ... objects);
}
