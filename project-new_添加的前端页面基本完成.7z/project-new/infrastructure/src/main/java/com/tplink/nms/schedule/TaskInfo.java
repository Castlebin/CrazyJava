package com.tplink.nms.schedule;

import org.quartz.*;

import java.util.Date;

/**
 * Created by Simon Wei on 2015/4/8.
 */
public class TaskInfo {
    private Class<? extends Task> taskClass;
    private String taskName;
    private String keyName = null;
    private String keyGroup = null;


    private int repeatCount = 0;
    private IntervalType intervalType = IntervalType.H;
    private long intervalNum = 0;
    private Date startDate = null;


    public Class<? extends Task> getTaskClass() {
        return taskClass;
    }

    public void setTaskClass(Class<? extends Task> taskClass) {
        this.taskClass = taskClass;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
        String[] names = taskName.split("\\.");

        assert (names != null && (names.length == 1 || names.length == 2));

        if (names.length == 2) {
            keyName = names[1];
            keyGroup = names[0];
        } else {
            keyName = taskName;
        }
    }

    public void setRepeatCount(int repeatCount) {
        this.repeatCount = repeatCount;
    }

    public void setIntervalTime(IntervalType intervalType, long intervalNum){
        this.intervalNum = intervalNum;
        this.intervalType = intervalType;
    }

    public String getKeyName() {
        return keyName;
    }

    public String getKeyGroup() {
        return keyGroup;
    }

    JobDetail generateJobDetail() {
        JobBuilder jobBuilder = JobBuilder.newJob(getTaskClass());
        jobBuilder.withIdentity(keyName, keyGroup);

        return jobBuilder.build();
    }

    Trigger generateJobTrigger() {
        TriggerBuilder triggerBuilder = TriggerBuilder.newTrigger();
        triggerBuilder.withIdentity(keyName, keyGroup);

        SimpleScheduleBuilder scheduleBuilder = SimpleScheduleBuilder.simpleSchedule();
        if (repeatCount == -1) {
            scheduleBuilder.repeatForever();
        } else {
            scheduleBuilder.withRepeatCount(repeatCount);
        }

        if (intervalNum > 0) {
            if(intervalType.equals(IntervalType.MSEC))
                scheduleBuilder.withIntervalInMilliseconds(intervalNum);
            else if(intervalType.equals(IntervalType.SEC))
                scheduleBuilder.withIntervalInSeconds((int)intervalNum);
            else if(intervalType.equals(IntervalType.MIN))
                scheduleBuilder.withIntervalInMinutes((int)intervalNum);
            else
                scheduleBuilder.withIntervalInHours((int)intervalNum);
        }
        triggerBuilder.withSchedule(scheduleBuilder);

        if(startDate != null){
            triggerBuilder.startAt(startDate);
        }else{
            triggerBuilder.startNow();
        }

        return triggerBuilder.build();
    }

    public enum IntervalType {
        MSEC,SEC,MIN,H;
    }
}
