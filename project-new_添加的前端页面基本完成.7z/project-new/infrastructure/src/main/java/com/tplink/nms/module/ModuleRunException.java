package com.tplink.nms.module;

/**
 * Created by Simon Wei on 2015/4/1.
 */
public class ModuleRunException extends Exception{
    private Exception oldException = null;

    public ModuleRunException(String msg){
        super(msg);
    }

    public ModuleRunException(String msg, Exception e){
        super(msg);
        this.oldException = e;
    }
}
