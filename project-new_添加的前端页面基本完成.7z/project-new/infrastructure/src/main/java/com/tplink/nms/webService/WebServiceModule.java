package com.tplink.nms.webService;

import com.tplink.nms.config.Configuration;
import com.tplink.nms.config.ConfigurationFactory;
import com.tplink.nms.config.PropertyKey;
import com.tplink.nms.i18n.L;
import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;
import com.tplink.nms.rmi.bean.LaunchInfoBean;
import com.tplink.nms.utils.FacadeUtil;

/**
 * Created by Simon Wei on 2015/4/3.
 */
public class WebServiceModule extends AbstractModule{
    private L l = L.getInstance(WebServiceModule.class);

    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
        Configuration jettyConfiguration = ConfigurationFactory.loadConfiguration(PropertyKey.JETTY_PROPERTIES_FILE_NAME);
        JettyServer jettyServer = new JettyServer();
        jettyServer.start(jettyConfiguration);
        FacadeUtil.sendCommand(LaunchInfoBean.InfoType.MSG, l.get("launch.webServer"));
    }
}
