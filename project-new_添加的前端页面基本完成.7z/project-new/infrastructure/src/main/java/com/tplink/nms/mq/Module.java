package com.tplink.nms.mq;

/**
 * Created by simon on 2015/1/27.
 */
public class Module {
    private String moduleName;
    private Class<? extends MessagePipeline> pipelineName = null;

    public Module(String name){
        this.moduleName = name;
    }

    public Module(String name, Class<? extends MessagePipeline> pipelineClass) {
        this.moduleName = name;
        this.pipelineName = pipelineClass;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String name) {
        this.moduleName = name;
    }

    public Class<? extends MessagePipeline> getPipelineClass() {
        return pipelineName;
    }
}
