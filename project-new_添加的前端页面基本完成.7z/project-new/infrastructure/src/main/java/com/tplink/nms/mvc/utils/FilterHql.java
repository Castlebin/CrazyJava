package com.tplink.nms.mvc.utils;

import com.tplink.nms.mvc.bean.QueryCondition;
import com.tplink.nms.mvc.bean.QueryCondition.QueryType;

import javax.management.Query;
import java.util.ArrayList;


/**
 * @author fdj
 */
public class FilterHql {
    public static String getFilterHql(Class clazz, ArrayList<QueryCondition> filter) {
        return getFilterHql(clazz, filter, null);
    }

    public static String getFilterHql(Class clazz, ArrayList<QueryCondition> filter, String hql) {
        String[] clazzPackage = clazz.getCanonicalName().split("\\.");
        String domainName = clazzPackage[clazzPackage.length - 1];
        String tableName = domainName.toLowerCase();

        hql = (hql == null) ? "" : hql;
        hql += "from " + domainName + " " + tableName;

        hql += getSortHql(tableName, filter);

        if (filter == null || filter.isEmpty()) {
            return hql;
        } else {
            try {
                boolean isFirstCondition = true;
                for (int index = 0; index < filter.size(); index++) {
                    QueryCondition qc = filter.get(index);
                    if (qc.getQueryType().equals(QueryType.asc)
                            || qc.getQueryType().equals(QueryType.desc)) {
                        continue;
                    }
                    String fieldStr = qc.getQueryName();

                    if (fieldStr.indexOf(".") >= 0) {
                        String[] children = fieldStr.split("\\.");
                        if (isFirstCondition) {
                            hql += (" where " + tableName + ".");
                            hql += (children[0] + ".");
                            for (int i = 1; i < (children.length - 1); i++) {
                                hql += ("." + children[i]);
                            }
                            hql += children[children.length - 1];
                            hql += getOperatorFormQueryType(qc.getQueryType());

                            isFirstCondition = false;
                        } else {
                            hql += (" and " + tableName + ".");
                            hql += (children[0] + ".");
                            for (int i = 1; i < (children.length - 1); i++) {
                                hql += ("." + children[i]);
                            }
                            hql += children[children.length - 1];
                            hql += getOperatorFormQueryType(qc.getQueryType());
                        }
                    } else {
                        if (isFirstCondition) {
                            hql += (" where " + tableName + ".");
                            hql += (fieldStr + getOperatorFormQueryType(qc
                                    .getQueryType()));

                            isFirstCondition = false;
                        } else {
                            hql += (" and " + tableName + ".");
                            hql += (fieldStr + getOperatorFormQueryType(qc
                                    .getQueryType()));
                        }
                    }
                }

                return hql;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

    }

    public static Object[] getFilterValues(ArrayList<QueryCondition> filter){
        ArrayList<Object> values = new ArrayList<>();
        if(filter != null && filter.size()>0) {
            for (QueryCondition qc : filter) {
                QueryType type = qc.getQueryType();
                if (type.equals(QueryType.asc)
                        || type.equals(QueryType.desc)) {
                    continue;
                }
                if (type.equals(QueryType.like)) {
                    values.add("%" + qc.getQueryValue() + "%");
                } else {
                    values.add(qc.getQueryValue());
                }
            }
        }

        return values.toArray();
    }

    private static String getOperatorFormQueryType(QueryCondition.QueryType queryType) {
        if (queryType.equals(QueryCondition.QueryType.equal)) {
            return " = ?";
        } else if (queryType.equals(QueryType.unequal)) {
            return " != ?";
        } else if (queryType.equals(QueryCondition.QueryType.great)) {
            return " > ?";
        } else if (queryType.equals(QueryType.less)) {
            return " < ?";
        } else if (queryType.equals(QueryType.like)) {
            return " like ?";
        } else {
            return null;
        }
    }

    private static String getSortHql(String tableName,
                                     ArrayList<QueryCondition> filter) {
        String sortHql = "";
        if (filter == null || filter.isEmpty()) {
            return sortHql;
        }

        boolean isFirstSortCondition = true;
        for (int i = 0; i < filter.size(); i++) {
            QueryCondition qc = filter.get(i);
            QueryType queryType = qc.getQueryType();
            if (queryType.equals(QueryType.asc)) {
                if (isFirstSortCondition) {
                    sortHql += " order by " + tableName + "."
                            + resolveQueryName(qc.getQueryName()) + " asc";
                    isFirstSortCondition = false;
                } else {
                    sortHql += ", " + tableName + "."
                            + resolveQueryName(qc.getQueryName()) + " asc";
                }
            } else if (queryType.equals(QueryType.desc)) {
                if (isFirstSortCondition) {
                    sortHql += " order by " + tableName + "."
                            + resolveQueryName(qc.getQueryName()) + " desc";
                    isFirstSortCondition = false;
                } else {
                    sortHql += ", " + tableName + "."
                            + resolveQueryName(qc.getQueryName()) + " desc";
                }
            }
        }

        return sortHql;
    }

    private static String resolveQueryName(String queryName) {
        String rs = "";
        if (queryName == null) {
            return rs;
        }

        if (queryName.lastIndexOf(".") >= 0) {
            String[] strs = queryName.split("\\.");
            for (int i = 0; i < strs.length; i++) {
                rs += (strs[i] + ".");
            }

            return rs.substring(0, rs.length() - 1);
        } else {
            return queryName;
        }
    }
}
