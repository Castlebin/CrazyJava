package com.tplink.nms.mq;


import com.tplink.nms.mq.message.Message;

/**
 * Created by simon on 2015/1/26.
 */
public interface MessagePipeline {
    public Message process(Message message);
    public void addMessageListener(String name, MessageListener listener);
}
