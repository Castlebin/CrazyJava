package com.tplink.nms.module;

/**
 * Created by Simon Wei on 2015/3/31.
 */
public interface Module extends Iterable<String>{
    public void run(ModuleContext moduleContext) throws ModuleRunException;

    public void execute(ModuleContext moduleContext) throws ModuleRunException;
    public void failed();
    public void stop();
    public void setModuleName(String moduleName);
    public String getModuleName();
    public void setModuleDescription(String description);
    public String getModuleDescription();
    public void pushDependencyModule(String moduleName);
    public ModuleState getModuleState();

    public boolean isStarted();
    public boolean isStoped();
    public boolean hasError();
}
