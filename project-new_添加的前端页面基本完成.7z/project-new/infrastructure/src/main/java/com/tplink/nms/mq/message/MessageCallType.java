package com.tplink.nms.mq.message;

/**
 * Created by simon on 2015/1/27.
 */
public enum MessageCallType {
    SYNC(0x01), ASYN(0x02), SUB(0x04), DIRECT(0x08), HIIGHPRI(0x10);

    private int value = 0;

    MessageCallType(int value) {
        this.value = value;
    }

    public void mix(MessageCallType type) {
        this.value = value | type.getValue();
    }

    public void remove(MessageCallType type) {
        this.value = value & ~type.getValue();
    }

    public int getValue() {
        return value;
    }

    public boolean contains(MessageCallType type) {
        return (value & type.getValue()) != 0;
    }
}
