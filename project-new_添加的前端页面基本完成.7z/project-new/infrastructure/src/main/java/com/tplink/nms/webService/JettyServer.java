package com.tplink.nms.webService;

import com.tplink.nms.config.Configuration;
import com.tplink.nms.config.PropertyKey;
import com.tplink.nms.i18n.L;
import com.tplink.nms.module.ModuleRunException;
import com.tplink.nms.utils.FileUtil;
import com.tplink.nms.utils.StringUtil;
import com.tplink.nms.utils.SystemUtil;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.ContextHandlerCollection;
import org.eclipse.jetty.server.nio.SelectChannelConnector;
import org.eclipse.jetty.server.ssl.SslSelectChannelConnector;
import org.eclipse.jetty.util.ssl.SslContextFactory;
import org.eclipse.jetty.util.thread.QueuedThreadPool;
import org.eclipse.jetty.webapp.WebAppContext;

import java.io.File;

/**
 * Created by Simon Wei on 2015/4/7.
 */
public class JettyServer {
    private Configuration conf = null;
    private L l = L.getInstance(JettyServer.class);

    private int httpPort = 80;
    private int httpsPort = 443;

    private Server jettyServer;
    private String              contextPath;
    private String              warApps;
    private String              tmpDir;

    public void start(Configuration jettyConfiguration) throws ModuleRunException {
        this.conf = jettyConfiguration;
        jettyServer = new Server();

        envCheck();

        setWebEnv();
        setWebParams();
        applyHandle();

        try {
            jettyServer.start();
        } catch (Exception e) {
            e.printStackTrace();
            throw new ModuleRunException(l.get("err.env.jetty.startError"), e);
        }
    }

    public void stop() {

    }

    private void envCheck() throws ModuleRunException {
        String httpPort = conf.getProperty(PropertyKey.HTTP_CONNECTOR_PORT_KEY);
        String httpsPort = conf.getProperty(PropertyKey.HTTPS_CONNECTOR_PORT_KEY);
        this.httpPort = Integer.valueOf(httpPort);
        this.httpsPort = Integer.valueOf(httpsPort);

        SystemUtil.portOccupiedCheck(httpPort);
        SystemUtil.portOccupiedCheck(httpsPort);
    }

    private void setWebParams() {
        SelectChannelConnector selectConnector = new SelectChannelConnector();
        selectConnector.setPort(httpPort);
        jettyServer.addConnector(selectConnector);

        SslContextFactory sslContext = new SslContextFactory();
        sslContext.setKeyStorePath(System.getProperty(PropertyKey.HOME_KEY_SUFFIX)
                + conf.getProperty(PropertyKey.KEY_STORE_PATH_KEY));
        sslContext.setKeyStorePassword(conf.getProperty(PropertyKey.SSL_KEY_STORE_PASSWORD_KEY));
        sslContext.setKeyManagerPassword(conf.getProperty(PropertyKey.SSL_MANAGER_PASSWORD_KEY));
        sslContext.setTrustStore(System.getProperty(PropertyKey.HOME_KEY_SUFFIX)
                + conf.getProperty(PropertyKey.TRUST_STORE_PATH_KEY));
        sslContext.setTrustStorePassword(conf.getProperty(PropertyKey.SSL_TRUST_STORE_PASSWORD_KEY));

        SslSelectChannelConnector sslConnector = new SslSelectChannelConnector(sslContext);
        sslConnector.setPort(httpsPort);
        sslConnector.setMaxIdleTime(Integer.valueOf(conf.getProperty(PropertyKey.MAX_IDLE_TIME_KEY)));
        sslConnector.setAcceptors(Integer.valueOf(conf.getProperty(PropertyKey.CONNECTOR_ACCEPTORS_KEY)));
        sslConnector.setAcceptQueueSize(Integer.valueOf(conf.getProperty(PropertyKey.CONNECTOR_ACCEPT_QUEUE_SIZE_KEY)));
        sslConnector.setLowResourcesMaxIdleTime(Integer.valueOf(conf.getProperty(PropertyKey.CONNECTOR_ACCEPT_QUEUE_SIZE_KEY)));
        sslConnector.setLowResourcesConnections(Integer.valueOf(conf.getProperty(PropertyKey.LOW_RESOURCES_CONNECTIONS_KEY)));
        jettyServer.addConnector(sslConnector);


        QueuedThreadPool threadPool = new QueuedThreadPool();
        threadPool.setMinThreads(Integer.valueOf(conf.getProperty(PropertyKey.MIN_THREADS_KEY)));
        threadPool.setMaxThreads(Integer.valueOf(conf.getProperty(PropertyKey.MAX_THREADS_KEY)));
        threadPool.setDetailedDump(Boolean.getBoolean(conf
                .getProperty(PropertyKey.DETAILED_DUMP_KEY)));

        jettyServer.setStopAtShutdown(Boolean.getBoolean(conf.getProperty(PropertyKey.STOP_AT_SHUTDOWN_KEY)));
        jettyServer.setSendServerVersion(Boolean.getBoolean(conf.getProperty(PropertyKey.SEND_SERVER_VERSION_KEY)));
        jettyServer.setSendDateHeader(Boolean.getBoolean(conf.getProperty(PropertyKey.SEND_DATE_HEADER_KEY)));
        jettyServer.setDumpAfterStart(Boolean.getBoolean(conf.getProperty(PropertyKey.DUMP_AFTER_START_KEY)));
        jettyServer.setDumpBeforeStop(Boolean.getBoolean(conf.getProperty(PropertyKey.DUMP_BEFORE_STOP_KEY)));
        jettyServer.setGracefulShutdown(Integer.valueOf(conf.getProperty(PropertyKey.GRACEFUL_SHUTDOWN_KEY)));
    }

    private void setWebEnv() throws ModuleRunException {
        String tmpDir = conf.getProperty(PropertyKey.EAP_TMP_DIR_KEY);
        String warApps = conf.getProperty(PropertyKey.WEBAPPS_KEY);
        String contextPath = conf.getProperty(PropertyKey.EAP_CONTEXT_PATH_KEY);
        if (!StringUtil.isNull(tmpDir)) {
            File file = new File(tmpDir);
            if (!file.exists()) {
                if (!file.mkdir()) {
                    throw new ModuleRunException(l.get("err.env.jetty.workDir"));
                }
            } else {
                if (!file.isDirectory()) {
                    if (!file.delete() || !file.mkdir()) {
                        throw new ModuleRunException(l.get("err.env.jetty.workDir"));
                    }
                } else {
                    if (!deleteDir(file) || !file.mkdir()) {
                        throw new ModuleRunException(l.get("err.env.jetty.workDir"));
                    }
                }
            }
            this.tmpDir = tmpDir;
        }
        if (!StringUtil.isNull(warApps)) {
            this.warApps = warApps;
            if (!StringUtil.isNull(contextPath)) {
                this.contextPath = contextPath;
            }
        }
    }

    private boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        return dir.delete();
    }

    private void applyHandle() {
        ContextHandlerCollection handler = new ContextHandlerCollection();
        File wars = FileUtil.getFile(warApps);
        if (null != wars && wars.isDirectory()) {
            for (String warName : wars.list()) {
                WebAppContext webapp = new WebAppContext();
                webapp.setContextPath(contextPath);
                webapp.setWar(warApps + File.separator + warName);
                webapp.setTempDirectory(FileUtil.getFile(tmpDir + File.separator
                        + getWorkName(warName)));
                handler.addHandler(webapp);
                jettyServer.setHandler(handler);
            }
        }else{
            WebAppContext webapp = new WebAppContext();
            webapp.setContextPath(contextPath);

            String path = FileUtil.getClassPath(JettyServer.class);
            path = FileUtil.getParentPath(path);
            path = FileUtil.getParentPath(path);
            path = FileUtil.getParentPath(path);
            String resourceBase = path + "/web/src/main/webapp";
            webapp.setResourceBase(resourceBase);
            handler.addHandler(webapp);
            jettyServer.setHandler(handler);
        }
    }

    private String getWorkName(String warName) {
        return warName.substring(0, warName.length() - 4);
    }
}
