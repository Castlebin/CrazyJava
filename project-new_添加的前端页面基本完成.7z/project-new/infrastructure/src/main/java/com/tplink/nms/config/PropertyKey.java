package com.tplink.nms.config;

public class PropertyKey {
    // nms
    public static final String HOME_KEY_SUFFIX                       = "nms.home";
    public static final String NMS_HOME_BIN_KEY                      = "/bin";
    public static final String NMS_HOME_DATA_KEY                     = "/data";
    public static final String NMS_PROPERTIES_FILE_NAME              = "nms.properties";
    public static final String INI_DEFAULT_NAME_KEY                  = "start.ini";
    public static final String NMS_SYSTEM_GC_ENABLE                  = "nms.system.gc.enable";
    
    // jetty properties key
    public static final String JETTY_PROPERTIES_FILE_NAME            = "jetty.properties";
    public static final String EAP_CONTEXT_PATH_KEY                  = "context.path";
    public static final String WEBAPPS_KEY                           = "webapps";
    public static final String EAP_TMP_DIR_KEY                       = "tmp.dir";
    public static final String GRACEFUL_SHUTDOWN_KEY                 = "graceful.shutdown";
    public static final String DUMP_BEFORE_STOP_KEY                  = "dump.before.stop";
    public static final String DUMP_AFTER_START_KEY                  = "dump.after.start";
    public static final String SEND_DATE_HEADER_KEY                  = "send.date.header";
    public static final String SEND_SERVER_VERSION_KEY               = "send.server.version";
    public static final String STOP_AT_SHUTDOWN_KEY                  = "stop.at.shutdown";
    public static final String DETAILED_DUMP_KEY                     = "detailed.dump";
    public static final String MAX_THREADS_KEY                       = "max.threads";
    public static final String MIN_THREADS_KEY                       = "min.threads";
    public static final String LOW_RESOURCES_CONNECTIONS_KEY         = "low.resources.connections";
    public static final String CONNECTOR_ACCEPT_QUEUE_SIZE_KEY       = "connector.accept.queue.size";
    public static final String CONNECTOR_ACCEPTORS_KEY               = "connector.acceptors";
    public static final String MAX_IDLE_TIME_KEY                     = "max.idle.time";
    public static final String HTTPS_CONNECTOR_PORT_KEY              = "https.connector.port";
    public static final String SSL_TRUST_STORE_PASSWORD_KEY          = "ssl.trust.store.password";
    public static final String TRUST_STORE_PATH_KEY                  = "trust.store.path";
    public static final String KEY_STORE_PATH_KEY                    = "key.store.path";
    public static final String SSL_MANAGER_PASSWORD_KEY              = "ssl.manager.password";
    public static final String SSL_KEY_STORE_PASSWORD_KEY            = "ssl.key.store.password";
    public static final String HTTP_CONNECTOR_PORT_KEY               = "http.connector.port";

    //Log4j
    public static final String LOG4J_PROPERTIES_FILE_NAME            = "log4j.properties";

}
