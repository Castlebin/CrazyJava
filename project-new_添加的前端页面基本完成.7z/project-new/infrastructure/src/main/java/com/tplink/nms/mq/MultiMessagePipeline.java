package com.tplink.nms.mq;

/**
 * Created by simon on 2015/1/27.
 */
public class MultiMessagePipeline extends  SimpleMessagePipeline{

}
