package com.tplink.nms.mq.message.channel;

import com.tplink.nms.mq.MessagePipeline;
import com.tplink.nms.mq.message.Message;

/**
 * Created by simon on 2015/1/26.
 */
public class MessageDispatch {
    private MessageDispatchChannel messageDispatchChannel;
    private MessagePipeline        messagePipeline = null;
    
    private Thread                 thread          = null;
    
    public MessageDispatch() {
        messageDispatchChannel = MessageDispatchChannelFactory.createFifoMessageDispatchChannel();
    }
    
    public MessageDispatch(MessageDispatchChannel messageDispatchChannel) {
        this.messageDispatchChannel = messageDispatchChannel;
    }
    
    public void start() {
        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                messageDispatchChannel.start();
                while (true) {
                    if (messageDispatchChannel.isClosed() || messageDispatchChannel.isEmpty()) {
                        break;
                    } else {
                        Message message = messageDispatchChannel.dequeueNoWait();
                        
                        if (message != null) {
                            if (message.isExit()) {
                                messageDispatchChannel.stop();
                                break;
                            }
                            messagePipeline.process(message);
                        }
                    }
                }
            }
        });
        thread.start();
    }
    
    public void setMessagePipeline(MessagePipeline pipeline) {
        this.messagePipeline = pipeline;
    }
    
    public void push(Message msg) {
        messageDispatchChannel.enqueue(msg);
    }
    
    public void stop() {
        messageDispatchChannel.close();
    }
    
}
