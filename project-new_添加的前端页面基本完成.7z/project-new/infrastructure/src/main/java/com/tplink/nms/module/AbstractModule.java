package com.tplink.nms.module;

import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.util.CollectionUtils;

/**
 * Created by Simon Wei on 2015/3/31.
 */
public abstract class AbstractModule implements Module {
	protected String moduleName = "";
	protected String moduleDescription = "";
	protected ModuleState moduleState = ModuleState.INIT;
	protected ArrayList<String> dependencyModuleNames = new ArrayList<String>();

	@Override
	public final void run(ModuleContext moduleContext)
			throws ModuleRunException {
		if (isStarted() || isInitialing())
			return;
		switchState(ModuleState.INITIALING);
		for (String moduleName : this) {
			Module module = moduleContext.getModuleByName(moduleName);
			if (module == null) {
				switchState(ModuleState.ERROR);
				failed();
				throw new ModuleRunException("Necessary Module " + moduleName
						+ " not exist.");
			}
			if (module.isStarted()) {
				continue;
			}
			try {
				module.run(moduleContext);
			} catch (ModuleRunException e) {
				failed();
				throw e;
			}
		}

		execute(moduleContext);
		switchState(ModuleState.RUNNING);
	}

	@Override
	public void stop() {

	}

	@Override
	public void failed() {

	}

	@Override
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	@Override
	public String getModuleName() {
		return moduleName;
	}

	@Override
	public void setModuleDescription(String moduleDescription) {
		this.moduleDescription = moduleDescription;
	}

	@Override
	public String getModuleDescription() {
		return moduleDescription;
	}

	@Override
	public ModuleState getModuleState() {
		return moduleState;
	}

	@Override
	public boolean isStarted() {
		return moduleState.getValue() >= ModuleState.RUNNING.getValue();
	}

	@Override
	public boolean hasError() {
		return moduleState.equals(ModuleState.ERROR);
	}

	@Override
	public boolean isStoped() {
		return moduleState.equals(ModuleState.STOPED);
	}

	private boolean isInitialing() {
		return moduleState.equals(ModuleState.INITIALING);
	}

	@Override
	public Iterator<String> iterator() {
		return dependencyModuleNames.iterator();
	}

	public void switchState(ModuleState state) {
		if (moduleState.equals(ModuleState.ERROR)
				&& state.equals(ModuleState.RUNNING)) {
			return;
		}
		this.moduleState = state;
	}

	@Override
	public void pushDependencyModule(String moduleName) {
		dependencyModuleNames.add(moduleName);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("[");

		builder.append(getModuleName()).append(" : ")
				.append(getClass().getName()).append(";dependency:");

		for (String name : dependencyModuleNames) {
			builder.append(name).append(",");
		}
		if (dependencyModuleNames.size() > 0) {
			builder.deleteCharAt(builder.length() - 1);
		}
		builder.append(";description:").append(getModuleDescription())
				.append("]");

		return builder.toString();
	}
}
