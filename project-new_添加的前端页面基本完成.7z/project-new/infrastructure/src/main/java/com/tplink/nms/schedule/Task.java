package com.tplink.nms.schedule;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * Created by Simon Wei on 2015/4/8.
 */
public abstract class Task implements Job{
    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        TaskExecContext context = new TaskExecContext();


        try {
            execute(context);
        } catch (TaskExecException e) {
            throw new JobExecutionException(e.getMessage());
        }
    }

    public abstract void execute(TaskExecContext taskExecContext) throws TaskExecException;
}
