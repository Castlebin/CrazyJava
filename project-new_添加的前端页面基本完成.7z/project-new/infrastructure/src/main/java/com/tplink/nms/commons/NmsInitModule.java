package com.tplink.nms.commons;

import com.tplink.nms.config.Configuration;
import com.tplink.nms.config.ConfigurationFactory;
import com.tplink.nms.i18n.L;
import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;
import com.tplink.nms.rmi.bean.LaunchInfoBean;
import com.tplink.nms.system.NmsSystem;
import com.tplink.nms.utils.FacadeUtil;

import java.rmi.Naming;
import java.rmi.RemoteException;

/**
 * Created by simon on 2015/4/30.
 */
public class NmsInitModule extends AbstractModule {

    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
        multiLanguzgeInit();
        rmiInit();
        systemHeartbeat();
    }

    private void multiLanguzgeInit() {
        Configuration configuration = ConfigurationFactory.loadConfiguration("nms.properties");
        L.setLanguageType(configuration.getProperty("nms.language"));
    }

    private void rmiInit() {
        String port = System.getProperty("nms.rmi.port");
        if (port == null || port.isEmpty()) {
            Configuration configuration = ConfigurationFactory.loadConfiguration("nms.properties");
            port = configuration.getProperty("nms.rmi.port");
        }

        try {
            String rmiUrl = "rmi://localhost:" + port + "/facade-launch-info";
            LaunchInfoBean launchInfoBean = (LaunchInfoBean) Naming.lookup(rmiUrl);
            FacadeUtil.setLaunchInfo(launchInfoBean);
        } catch (Exception e) {
        }
    }

    private void systemHeartbeat() {
        new Thread(new Runnable() {
            private int errorNum = 0;

            @Override
            public void run() {
                Configuration configuration = ConfigurationFactory.loadConfiguration("nms.properties");
                int interval = Integer.valueOf(configuration.getProperty("nms.heartbeat")) * 1000;

                while (true) {
                    try {
                        FacadeUtil.sendHeartbeat();
                    } catch (RemoteException e) {
                        if (++errorNum >= 2) {
                            NmsSystem.executeHandler("bootstrap.stop");
                            System.exit(0);
                        }
                    }
                    try {
                        Thread.currentThread().sleep(interval);
                    } catch (InterruptedException e) {
                    }
                }
            }
        }).start();
    }
}
