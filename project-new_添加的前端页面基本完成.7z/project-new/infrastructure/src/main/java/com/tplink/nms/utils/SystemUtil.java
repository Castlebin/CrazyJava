package com.tplink.nms.utils;

import com.tplink.nms.i18n.L;
import com.tplink.nms.module.ModuleRunException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SystemUtil {
    private static final String NETSTAT_TYPE_LISTENING = "LISTENING";
    private static final String COMMAND_NETSTAT_ANO = "netstat -ano";
    private static final String WINDOWS_COMMAND_TASKLIST = "tasklist";
    private static final String WINDOWS_COMMAND_TASKLIST_KILL = "taskkill /F /PID ";
    private static final String WINDOWS_COMMAND_TASKLIST_KILL_IM = "taskkill /F /IM ";
    private static final Logger logger = LoggerFactory.getLogger(SystemUtil.class);

    private static L l = L.getInstance(SystemUtil.class);

    // cache ipInterfaceAddress
    private static List<InterfaceAddress> NETWORK_INTERFACES_LIST = new ArrayList<InterfaceAddress>();
    private static final String LOCAL_HOST_IP = "127.0.0.1";
    private static final String IP_PATTERN = "^([01]?\\\\d{1,2}|2[0-4]\\\\d|25[0-5])(\\\\.([01]?\\\\d{1,2}|2[0-4]\\\\d|25[0-5])){3}$";
    private static final Pattern PATTERN = Pattern.compile(IP_PATTERN);
    private static ReadWriteLock _lock = new ReentrantReadWriteLock();

    public static String getCurrentSystemProcessID() {
        String processName = java.lang.management.ManagementFactory.getRuntimeMXBean().getName();
        return processName.split("@")[0];
    }

    /**
     * return true if process is running on windows OS
     *
     * @return
     */
    public static boolean isWindowsOS() {
        boolean isWindowsOS = false;
        String osName = System.getProperty("os.name");
        if (osName.toLowerCase().indexOf("windows") > -1) {
            isWindowsOS = true;
        }
        return isWindowsOS;
    }

    /**
     * check if process is running by image name of process
     *
     * @param name
     * @return
     * @throws java.io.IOException
     */
    public static boolean checkProcess(String name) throws IOException {
        if (StringUtil.isNull(name)) {
            return false;
        }
        if (isWindowsOS()) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(execute(
                    WINDOWS_COMMAND_TASKLIST).getInputStream()));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.indexOf(name) > -1) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
            return false;
        } else {
            // TODO
            return false;
        }
    }

    /**
     * get port related process id
     *
     * @param port
     * @return
     * @throws java.io.IOException
     */
    public static String getPidByPort(String port) throws IOException {
        String netstat = getNetstatInfoByPort(port);
        if (StringUtil.isNull(netstat)) {
            return null;
        }
        String[] splits = netstat.split(" ");
        return splits[splits.length - 1];
    }

    private static String getNetstatInfoByPort(String port) {
        String netstat = null;
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(execute(COMMAND_NETSTAT_ANO)
                    .getInputStream()));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.indexOf(port) > -1 && line.indexOf(NETSTAT_TYPE_LISTENING) > -1) {
                    netstat = line;
                    break;
                }
            }
        } catch (IOException e) {

        } finally {
            if (null != reader) {
                try {
                    reader.close();
                } catch (IOException e) {
                }
            }
        }
        return netstat;
    }

    /**
     * check if specific port is occupied or not
     *
     * @param port
     * @return
     * @throws java.io.IOException
     */
    public static boolean portOccupied(String port) throws IOException {
        return !StringUtil.isNull(getNetstatInfoByPort(port));
    }

    public static void portOccupiedCheck(String port, String type) throws ModuleRunException {
        int p = Integer.valueOf(port);
        try {
            if (type == null || type.equalsIgnoreCase("udp")) {
                DatagramSocket socket = new DatagramSocket(p);
                socket.close();
            }
            if (type == null || type.equalsIgnoreCase("tcp")) {
                ServerSocket tcp = new ServerSocket(p);
                tcp.close();
            }
        } catch (BindException e) {
            throw new ModuleRunException(l.get("err.env.port.inuse", p));
        } catch (IOException e) {
            throw new ModuleRunException(l.get("err.env.networkErr"));
        }
    }

    public static void portOccupiedCheck(String port) throws ModuleRunException {
        portOccupiedCheck(port, "tcp");
    }

    /**
     * execute runtime command
     *
     * @param command
     * @return
     * @throws java.io.IOException
     */
    public static Process execute(String command) throws IOException {
        return Runtime.getRuntime().exec(command);
    }

    /**
     * kill process by process id
     *
     * @param pid
     * @throws java.io.IOException
     */
    public static void killProcessByProcessID(String pid) throws IOException {
        if (!StringUtil.isNull(pid)) {
            execute(WINDOWS_COMMAND_TASKLIST_KILL + pid);
        }
    }

    /**
     * kill process by image name
     *
     * @param imageName
     * @throws java.io.IOException
     */
    public static void killProcessByImageName(String imageName) throws IOException {
        execute(WINDOWS_COMMAND_TASKLIST_KILL_IM + imageName);
    }

    /**
     * automatic open web url in browsers
     *
     * @param ip
     * @param port
     * @return
     */
    public static boolean openUrl(String ip, Integer port) {
        String url = "http://" + ip + ":" + port;
        String osName = System.getProperty("os.name");
        try {
            if (osName.startsWith("Mac OS")) {
                // Mac
                // TODO
            } else if (osName.startsWith("Windows")) {
                // Windows
                Desktop.getDesktop().browse(new URI(url));
            } else {
                // assume Unix or Linux
                // TODO
            }
            return true;
        } catch (Exception e) {
            logger.warn("open url exception : ", e);
            return false;
        }
    }

    public static List<InterfaceAddress> getAllInterfaceAddress() {
        _lock.readLock().lock();
        List<InterfaceAddress> list = new ArrayList<InterfaceAddress>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface ni = interfaces.nextElement();
                List<InterfaceAddress> addresses = ni.getInterfaceAddresses();
                for (InterfaceAddress addr : addresses) {
                    String ip = addr.getAddress().getHostAddress();
                    if (ip != null) {
                        Matcher matcher = PATTERN.matcher(ip);
                        if (matcher.find() && !ip.equals(LOCAL_HOST_IP)) {
                            list.add(addr);
                        }
                    }

                }
            }
        } catch (SocketException e) {
            logger.warn("get local net interface address exception : ", e);
        }
        sortAddressBySubnetMask(list);
        NETWORK_INTERFACES_LIST = list;
        _lock.readLock().unlock();
        return list;
    }

    /**
     * address which has longer mask will be in front
     *
     * @param interfaceAddresses
     */

    private static void sortAddressBySubnetMask(List<InterfaceAddress> interfaceAddresses) {
        Collections.sort(interfaceAddresses, new Comparator<InterfaceAddress>() {
            @Override
            public int compare(InterfaceAddress o1, InterfaceAddress o2) {
                if (o1.getNetworkPrefixLength() > o2.getNetworkPrefixLength()) {
                    return -1;
                } else {
                    return 1;
                }
            }
        });
    }

    public static List<String> getAllLocalIps() {
        List<String> list = new ArrayList<String>();
        List<InterfaceAddress> interfaceAddresses = getAllInterfaceAddress();
        for (InterfaceAddress ifa : interfaceAddresses) {
            list.add(ifa.getAddress().getHostAddress());
        }
        return list;
    }

    public static String getHomePath() {
        URL url = SystemUtil.class.getProtectionDomain().getCodeSource().getLocation();

        try {
            String filePath = URLDecoder.decode(url.getFile(), "utf-8");
            return filePath;
        } catch (Exception e) {
            return "/";
        }
    }
}
