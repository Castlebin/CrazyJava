package com.tplink.nms.mq.message;

import java.util.concurrent.Semaphore;

/**
 * Created by simon on 2015/1/27.
 */
public class SimpleMessage implements Message {
    private String             name         = "nul";
    private String             firstName;
    private String             secondName;
    private int                priority;
    private long               timestamp    = 0;
    private Object             body         = null;
    
    private MessageCallType    callType     = MessageCallType.SYNC;
    private MessageState       messageState = MessageState.INIT;
    
    private volatile Semaphore msgLock      = new Semaphore(1);
    
    boolean                    isExit       = false;
    
    public SimpleMessage() {
        this.priority = Message.DEFAULT_PRIORITY;
    }
    
    public SimpleMessage(String name, Object o) {
        this.priority = Message.DEFAULT_PRIORITY;
        init(name, o);
        recycle();
    }
    
    @Override
    public void init(String name, Object o) {
        setMessageName(name);
        this.body = o;
    }
    
    @Override
    public void setMessageName(String name) {
        this.name = name;
        
        int dotIndex = name.indexOf(".");
        if (dotIndex < 0) {
            firstName = name;
        } else {
            firstName = name.substring(0, dotIndex);
            secondName = name.substring(dotIndex + 1);
        }
    }
    
    @Override
    public String getMessageName() {
        return null;
    }
    
    @Override
    public String getModuleName() {
        return firstName;
    }
    
    @Override
    public String getMethodName() {
        return secondName;
    }
    
    @Override
    public Object getMessageBody() {
        return body;
    }
    
    @Override
    public void setMessageBody(Object o) {
        body = o;
    }
    
    @Override
    public void lock() {
        try {
            msgLock.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void unlock() {
        msgLock.release();
    }
    
    @Override
    public long getTimestamp() {
        return timestamp;
    }
    
    @Override
    public boolean isExit() {
        return isExit;
    }
    
    public void setExit(boolean isExit) {
        this.isExit = isExit;
    }
    
    @Override
    public MessageCallType getMessageCallType() {
        return callType;
    }
    
    @Override
    public void setMessageCallType(MessageCallType type) {
        this.callType = type;
    }
    
    @Override
    public void recycle() {
        timestamp = System.nanoTime();
    }
    
    @Override
    public void switchState(MessageState state) {
        this.messageState = state;
    }
    
    @Override
    public String toString() {
        return "[Message:" + name + "] " + body.toString();
    }
    
    @Override
    public int getPriority() {
        return priority;
    }
    
    @Override
    public void setPriority(int priority) {
        this.priority = priority;
    }
}
