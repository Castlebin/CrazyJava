package com.tplink.nms.mq.message.channel;

import java.util.List;

import com.tplink.nms.mq.message.Message;

/**
 * Created by simon on 2015/1/26.
 */
public interface MessageDispatchChannel {
    public abstract void enqueue(Message message);
    
    public abstract void enqueueFirst(Message message);
    
    public abstract boolean isEmpty();
    
    public abstract Message dequeue(long timeout) throws InterruptedException;
    
    public abstract Message dequeueNoWait();
    
    public abstract Message peek();
    
    public abstract void start();
    
    public abstract void stop();
    
    public abstract void close();
    
    public abstract void clear();
    
    public abstract boolean isClosed();
    
    public abstract int size();
    
    public abstract Object getMutex();
    
    public abstract boolean isRunning();
    
    public abstract List<Message> removeAll();
}
