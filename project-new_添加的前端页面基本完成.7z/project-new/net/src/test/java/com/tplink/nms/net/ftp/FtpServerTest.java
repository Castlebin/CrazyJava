package com.tplink.nms.net.ftp;

import org.apache.ftpserver.ftplet.FtpException;
import org.junit.Test;

public class FtpServerTest {
    @Test
    public void testStartFtpServer() throws FtpException{
        NmsFtpServer server=new NmsFtpServer("properties/ftp.properties");
        server.start();
        try {
            Thread.currentThread().join();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
