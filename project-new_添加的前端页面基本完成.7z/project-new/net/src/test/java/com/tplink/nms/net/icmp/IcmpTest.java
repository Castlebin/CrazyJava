package com.tplink.nms.net.icmp;

import static org.junit.Assert.*;

import org.junit.Test;

import com.tplink.nms.net.util.IcmpUtil;

public class IcmpTest {
    @Test
    public void testReachable(){
        boolean reachable = IcmpUtil.isReachable("192.168.0.1");
        assertTrue(reachable);
        
    }
}
