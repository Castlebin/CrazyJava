package com.tplink.nms.net.snmp;

import static org.junit.Assert.*;

import org.junit.Test;
import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.SecureTarget;
import org.snmp4j.Target;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.OctetString;

import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.net.module.NetModule;
import com.tplink.nms.net.snmp.common.SnmpBuilder;
import com.tplink.nms.net.snmp.domain.SnmpPDU;
import com.tplink.nms.net.snmp.domain.SnmpParam;
import com.tplink.nms.net.snmp.domain.SnmpParamV3;
import com.tplink.nms.net.snmp.gateway.GatewayResponse;
import com.tplink.nms.net.snmp.gateway.SnmpGateway;
import com.tplink.nms.net.snmp.gateway.SnmpGatewayRequest;
import com.tplink.nms.net.snmp.proxy.EquipmentProxy;
import com.tplink.nms.net.snmp.proxy.EquipmentProxyManage;

public class SnmpTest {
    @Test
    public void testSendSnmp() throws Exception {
        NetModule netModule = new NetModule();
        netModule.setModuleName("NetModule");
        ModuleContext context = new ModuleContext();
        netModule.run(context);
        SnmpGateway gateway = new SnmpGateway();
        String[] oids = { "1.3.6.1.2.1.1.3.0" };
        EquipmentProxy proxy = EquipmentProxyManage.getInstance().createEquipmentProxy(
            "192.168.0.1");
        SnmpParam paramV3 = getTestSnmpParamV3();
        proxy.setSnmpParam(SnmpConstants.version3, paramV3);
        SnmpPDU pduv1 = SnmpBuilder.generateSnmpPDU(PDU.GET, SnmpConstants.version1, proxy, oids);
        SnmpPDU pduv3 = SnmpBuilder.generateSnmpPDU(PDU.GET, SnmpConstants.version3, proxy, oids);
        Target targetv1 = SnmpBuilder.newTarget(CommunityTarget.class, proxy);
        Target targetv3 = SnmpBuilder.newTarget(SecureTarget.class, proxy);
        SnmpGatewayRequest requestv1 = new SnmpGatewayRequest(pduv1, targetv1);
        // SnmpGatewayRequest requestv3 = new SnmpGatewayRequest(pduv3, targetv3);
        GatewayResponse responsev1 = gateway.sendRequest(requestv1);
        assertTrue(responsev1.isSuccess());
        // GatewayResponse responsev3 = gateway.sendRequest(requestv3);
        // assertTrue(responsev3.isSuccess());
        Thread.currentThread().join();
    }
    
    public SnmpParam getTestSnmpParamV3() {
        SnmpParamV3 snmpParam = new SnmpParamV3(SnmpParam.SecurityLevel.AUTH_PRIV,
            SnmpParam.AuthMode.MD5, new OctetString("rocky"), new OctetString("11111111"),
            SnmpParam.PrivacyMode.DES, new OctetString("11111111"), new OctetString(""),
            new OctetString(""));
        return snmpParam;
    }
    
    @Test
    public void trapTest() {
        
    }
}
