package com.tplink.nms.net.snmp.proxy;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.tplink.nms.net.snmp.proxy.EquipmentProxy.EquipmentProxyState;
import com.tplink.nms.net.util.IcmpUtil;

public class EquipmentProxyManage {
    private static EquipmentProxyManage        instance          = new EquipmentProxyManage();
    private static Map<String, EquipmentProxy> EquipmentProxyMap = new ConcurrentHashMap<String, EquipmentProxy>();
    private ScheduledExecutorService           executor;
    
    private Object                             mutex             = new Object();
    
    public static EquipmentProxyManage getInstance() {
        return instance;
    }
    
    private EquipmentProxyManage() {
        executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleAtFixedRate(new CheckProxyOnlineTask(), 10, 60, TimeUnit.SECONDS);
    }
    
    public void addEquipmentProxy(String key, EquipmentProxy proxy) {
        synchronized (mutex) {
            EquipmentProxyMap.put(key, proxy);
        }
    }
    
    public void deleteEquipmentProxy(String key) {
        synchronized (mutex) {
            EquipmentProxyMap.remove(key);
        }
    }
    
    public EquipmentProxy getEquipmentProxy(String key) {
        return EquipmentProxyMap.get(key);
    }
    
    public boolean checkEquipment(String key) {
        if (null == EquipmentProxyMap.get(key)) {
            return false;
        } else {
            EquipmentProxy proxy = EquipmentProxyMap.get(key);
            if (proxy.getState() == EquipmentProxyState.ONLINE) {
                return true;
            }
            return false;
        }
    }
    
    public EquipmentProxy createEquipmentProxy(String ip) {
        synchronized (mutex) {
            if (null != EquipmentProxyMap.get(ip)) {
                return EquipmentProxyMap.get(ip);
            }
            EquipmentProxy proxy = new EquipmentProxy(ip);
            EquipmentProxyMap.put(ip, proxy);
            return proxy;
        }
    }
    
    public void shutdownDetectTask() {
        executor.shutdown();
    }
    
    class CheckProxyOnlineTask implements Runnable {
        @Override
        public void run() {
            synchronized (mutex) {
                if (EquipmentProxyMap.size() == 0) {
                    return;
                }
                for (String ip : EquipmentProxyMap.keySet()) {
                    EquipmentProxy equipmentProxy = EquipmentProxyMap.get(ip);
                    equipmentProxy.setLastHearbeatTime(System.currentTimeMillis());
                    boolean reachable = IcmpUtil.isReachable(ip);
                    if (!reachable) {
                        equipmentProxy.setState(EquipmentProxyState.OFFLINE);
                    } else {
                        equipmentProxy.setHasConnectedBefore(true);
                        equipmentProxy.setState(EquipmentProxyState.ONLINE);
                        equipmentProxy.setLastConnectedTime(System.currentTimeMillis());
                    }
                }
            }
        }
    }
}
