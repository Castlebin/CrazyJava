package com.tplink.nms.net.snmp.connector;

import java.io.IOException;

import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.Target;
import org.snmp4j.TransportMapping;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.security.AuthMD5;
import org.snmp4j.security.PrivDES;
import org.snmp4j.security.SecurityModels;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.security.UsmUser;
import org.snmp4j.transport.DefaultUdpTransportMapping;

import com.tplink.nms.i18n.L;
import com.tplink.nms.net.snmp.domain.SnmpParam;
import com.tplink.nms.net.snmp.domain.SnmpParamV3;
import com.tplink.nms.net.snmp.exception.SnmpException;
import com.tplink.nms.net.snmp.exception.SnmpParamException;
import com.tplink.nms.net.snmp.gateway.SnmpGatewayResponse;
import com.tplink.nms.net.snmp.proxy.EquipmentProxy;

/**
 * Created by Simon Wei on 2015/4/15.
 */
public class SnmpConnector implements Connector {
    private static L         l      = L.getInstance(SnmpConnector.class);
    private EquipmentProxy   equipmentProxy;
    private Snmp             snmp;
    private String           ip;
    private volatile boolean isInit = false;
    
    public SnmpConnector(EquipmentProxy equipmentProxy) {
        this.equipmentProxy = equipmentProxy;
        build();
    }
    
    public SnmpGatewayResponse get(PDU pdu, Target target) throws SnmpException, SnmpParamException {
        build();
        try {
            ResponseEvent responseEvent = snmp.send(pdu, target);
            if (responseEvent == null || responseEvent.getResponse() == null)
                return null;
            return new SnmpGatewayResponse(responseEvent.getResponse());
        } catch (IOException e) {
            throw new SnmpException(l.get("snmp.err.execute"));
        }
    }
    
    private void build() throws SnmpException {
        if (isInit)
            return;
        try {
            TransportMapping transport = new DefaultUdpTransportMapping();
            snmp = new org.snmp4j.Snmp(transport);
            SnmpParam snmpParamV3 = equipmentProxy.getSnmpParam(SnmpConstants.version3);
            if (null != snmpParamV3) {
                // TODO what's local engine id
                SnmpParamV3 snmpV3 = (SnmpParamV3) snmpParamV3;
                USM usm = new USM(SecurityProtocols.getInstance(), snmpV3.getLocalEngineId(), 0);
                SecurityModels.getInstance().addSecurityModel(usm);
                
                UsmUser user = new UsmUser(snmpV3.getSecurityName(), AuthMD5.ID,
                    snmpV3.getAuthPassword(), PrivDES.ID, snmpV3.getPrivacyPassword());
                snmp.getUSM().addUser(snmpV3.getSecurityName(), user);
            }
            transport.listen();
            isInit = true;
        } catch (Exception e) {
            e.printStackTrace();
            throw new SnmpException(l.get("snmp.err.init"));
        }
    }
    
    public String getIp() {
        return ip;
    }
    
    public void setIp(String ip) {
        this.ip = ip;
    }
    
    public void destroy() {
        if (isInit) {
            try {
                snmp.close();
                isInit = false;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public ConnectorType getConnectorType() {
        return ConnectorType.SNMP;
    }
}
