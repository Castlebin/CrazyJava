package com.tplink.nms.net.snmp.gateway;

public interface Gateway {
    public GatewayResponse sendRequest(GatewayRequest request);
    
    public GatewayType getGatewayType();
    
    enum GatewayType {
        Snmp
    }
}
