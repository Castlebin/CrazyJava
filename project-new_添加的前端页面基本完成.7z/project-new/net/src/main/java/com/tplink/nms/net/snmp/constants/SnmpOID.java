package com.tplink.nms.net.snmp.constants;

import org.snmp4j.smi.OID;

public class SnmpOID {
    public static final OID SNMP_TRAP   = new OID("1.3.6.1.6.3.1.1.4.1.0");

    /* PUBLIC MIB */

    /* System */
    public static final OID SYS_DESCR = new OID("1.3.6.1.2.1.1.1.0");
    public static final OID SYS_OBJECT_ID = new OID("1.3.6.1.2.1.1.2.0");
    public static final OID SYS_UP_TIME = new OID("1.3.6.1.2.1.1.3.0");
    public static final OID SYS_CONTACT = new OID("1.3.6.1.2.1.1.4.0");
    public static final OID SYS_NAME = new OID("1.3.6.1.2.1.1.5.0");
    public static final OID SYS_LOCATION = new OID("1.3.6.1.2.1.1.6.0");
    public static final OID SYS_SERVICES = new OID("1.3.6.1.2.1.1.7.0");


    /* Interfaces (no instance) */
    public static final OID IF_INDEX = new OID("1.3.6.1.2.1.2.2.1.1");
    public static final OID IF_DESCR = new OID("1.3.6.1.2.1.2.2.1.2");
    public static final OID IF_TYPE = new OID("1.3.6.1.2.1.2.2.1.3");
    public static final OID IF_MTU = new OID("1.3.6.1.2.1.2.2.1.4");
    public static final OID IF_SPEED = new OID("1.3.6.1.2.1.2.2.1.5");
    public static final OID IF_PHYS_ADDR = new OID("1.3.6.1.2.1.2.2.1.6");
    public static final OID IF_ADMIN_STATUS = new OID("1.3.6.1.2.1.2.2.1.7");
    public static final OID IF_OPER_STATUS = new OID("1.3.6.1.2.1.2.2.1.8");
    public static final OID IF_LAST_CHANGE = new OID("1.3.6.1.2.1.2.2.1.9");
    public static final OID IF_IN_OCTETS = new OID("1.3.6.1.2.1.2.2.1.10");
    public static final OID IF_IN_UCAST_PKTS = new OID("1.3.6.1.2.1.2.2.1.11");
    public static final OID IF_IN_NUCAST_PKTS = new OID("1.3.6.1.2.1.2.2.1.12");
    public static final OID IF_IN_DISCARDS = new OID("1.3.6.1.2.1.2.2.1.13");
    public static final OID IF_IN_ERRORS = new OID("1.3.6.1.2.1.2.2.1.14");
    public static final OID IF_IN_UK_PROTOS = new OID("1.3.6.1.2.1.2.2.1.15");
    public static final OID IF_OUT_OCTETS = new OID("1.3.6.1.2.1.2.2.1.16");
    public static final OID IF_OUT_UCAST_PKTS = new OID("1.3.6.1.2.1.2.2.1.17");
    public static final OID IF_OUT_NUCAST_PKTS = new OID("1.3.6.1.2.1.2.2.1.18");
    public static final OID IF_OUT_DISCARDS = new OID("1.3.6.1.2.1.2.2.1.19");
    public static final OID IF_OUT_ERRORS = new OID("1.3.6.1.2.1.2.2.1.20");
    public static final OID IF_OUT_UK_PROTOS = new OID("1.3.6.1.2.1.2.2.1.21");
    public static final OID IF_SPECIFIC = new OID("1.3.6.1.2.1.2.2.1.22");

    /* IP */
    public static final OID IP_IN_RECEIVES = new OID("1.3.6.1.2.1.4.3.0");
    public static final OID IP_IN_HDR_ERRORS = new OID("1.3.6.1.2.1.4.4.0");
    public static final OID IP_IN_ADDR_ERRORS = new OID("1.3.6.1.2.1.4.5.0");
    public static final OID IP_FORWARD_DATAGRAMS = new OID("1.3.6.1.2.1.4.6.0");
    public static final OID IP_IN_UK_PROTOS = new OID("1.3.6.1.2.1.4.7.0");
    public static final OID IP_IN_DISCARDS = new OID("1.3.6.1.2.1.4.8.0");
    public static final OID IP_IN_DELIVERS = new OID("1.3.6.1.2.1.4.9.0");
    public static final OID IP_OUT_REQUESTS = new OID("1.3.6.1.2.1.4.10.0");
    public static final OID IP_OUT_DISCARDS = new OID("1.3.6.1.2.1.4.11.0");
    public static final OID IP_OUT_NO_ROUTES = new OID("1.3.6.1.2.1.4.12.0");

    /* ICMP */
    public static final OID ICMP_IN_MSGS = new OID("1.3.6.1.2.1.5.1.0");
    public static final OID ICMP_IN_ERRORS = new OID("1.3.6.1.2.1.5.2.0");
    public static final OID ICMP_IN_DEST_UNREACHES = new OID("1.3.6.1.2.1.5.3.0");
    public static final OID ICMP_IN_TIME_EXCDS = new OID("1.3.6.1.2.1.5.4.0");
    public static final OID ICMP_IN_PARM_PROBS = new OID("1.3.6.1.2.1.5.5.0");
    public static final OID ICMP_IN_SRC_QUENCHS = new OID("1.3.6.1.2.1.5.6.0");
    public static final OID ICMP_IN_REDIRECTS = new OID("1.3.6.1.2.1.5.7.0");
    public static final OID ICMP_IN_ECHOS = new OID("1.3.6.1.2.1.5.8.0");
    public static final OID ICMP_IN_ECHO_REPS = new OID("1.3.6.1.2.1.5.9.0");
    public static final OID ICMP_IN_TIMESTAMPS = new OID("1.3.6.1.2.1.5.10.0");
    public static final OID ICMP_IN_TIMESTAMP_REPS = new OID("1.3.6.1.2.1.5.11.0");
    public static final OID ICMP_IN_ADDR_MASKS = new OID("1.3.6.1.2.1.5.12.0");
    public static final OID ICMP_IN_ADDR_MASK_REPS = new OID("1.3.6.1.2.1.5.13.0");
    public static final OID ICMP_OUT_MSGS = new OID("1.3.6.1.2.1.5.14.0");
    public static final OID ICMP_OUT_ERRORS = new OID("1.3.6.1.2.1.5.15.0");
    public static final OID ICMP_OUT_DEST_UNREACHES = new OID("1.3.6.1.2.1.5.16.0");
    public static final OID ICMP_OUT_TIME_EXCDS = new OID("1.3.6.1.2.1.5.17.0");
    public static final OID ICMP_OUT_PARM_PROBS = new OID("1.3.6.1.2.1.5.18.0");
    public static final OID ICMP_OUT_SRC_QUENCHES = new OID("1.3.6.1.2.1.5.19.0");
    public static final OID ICMP_OUT_REDIRECTS = new OID("1.3.6.1.2.1.5.20.0");
    public static final OID ICMP_OUT_ECHOS = new OID("1.3.6.1.2.1.5.21.0");
    public static final OID ICMP_OUT_ECHO_REPS = new OID("1.3.6.1.2.1.5.22.0");
    public static final OID ICMP_OUT_TIMESTAMPS = new OID("1.3.6.1.2.1.5.23.0");
    public static final OID ICMP_OUT_TIMESTAMP_REPS = new OID("1.3.6.1.2.1.5.24.0");
    public static final OID ICMP_OUT_ADDR_MASKS = new OID("1.3.6.1.2.1.5.25.0");
    public static final OID ICMP_OUT_ADDR_MASK_REPS = new OID("1.3.6.1.2.1.5.26.0");

    /* TCP */
    public static final OID TCP_ATTEMPT_FAILS = new OID("1.3.6.1.2.1.6.7.0");
    public static final OID TCP_CURR_ESTAB = new OID("1.3.6.1.2.1.6.9.0");
    public static final OID TCP_IN_SEGS = new OID("1.3.6.1.2.1.6.10.0");
    public static final OID TCP_OUT_ESGS = new OID("1.3.6.1.2.1.6.11.0");
    public static final OID TCP_IN_ERRORS = new OID("1.3.6.1.2.1.6.14.0");

    /* UDP */
    public static final OID UDP_IN_DATAGRAMS = new OID("1.3.6.1.2.1.7.1.0");
    public static final OID UDP_NO_PORTS = new OID("1.3.6.1.2.1.7.2.0");
    public static final OID UDP_IN_ERRORS = new OID("1.3.6.1.2.1.7.3.0");
    public static final OID UDP_OUT_DATAGRAMS = new OID("1.3.6.1.2.1.7.4.0");

    /* SNMP */
    public static final OID SNMP_IN_PKTS = new OID("1.3.6.1.2.1.11.1.0");
    public static final OID SNMP_OUT_PKTS = new OID("1.3.6.1.2.1.11.2.0");
    public static final OID SNMP_IN_BAD_VERSIONS = new OID("1.3.6.1.2.1.11.3.0");
    public static final OID SNMP_IN_BAD_COMMUNITY_NAMES = new OID("1.3.6.1.2.1.11.4.0");
    public static final OID SNMP_IN_BAD_COMMUNITY_USES = new OID("1.3.6.1.2.1.11.5.0");
    public static final OID SNMP_IN_ASN_PARSE_ERRS = new OID("1.3.6.1.2.1.11.6.0");
    public static final OID SNMP_IN_TOO_BIGS = new OID("1.3.6.1.2.1.11.8.0");
    public static final OID SNMP_IN_NO_SUCH_NAMES = new OID("1.3.6.1.2.1.11.9.0");
    public static final OID SNMP_IN_BAD_VALUES = new OID("1.3.6.1.2.1.11.10.0");
    public static final OID SNMP_IN_READ_ONLYS = new OID("1.3.6.1.2.1.11.11.0");
    public static final OID SNMP_IN_GEN_ERRS = new OID("1.3.6.1.2.1.11.12.0");
    public static final OID SNMP_TOTAL_REQ_VARS = new OID("1.3.6.1.2.1.11.13.0");
    public static final OID SNMP_TOTAL_SET_VARS = new OID("1.3.6.1.2.1.11.14.0");
    public static final OID SNMP_IN_GET_REQUESTS = new OID("1.3.6.1.2.1.11.15.0");
    public static final OID SNMP_IN_GET_NEXTS = new OID("1.3.6.1.2.1.11.16.0");
    public static final OID SNMP_IN_SET_REQUESTS = new OID("1.3.6.1.2.1.11.17.0");
    public static final OID SNMP_IN_GET_RESPONSES = new OID("1.3.6.1.2.1.11.18.0");
    public static final OID SNMP_IN_TRAPS = new OID("1.3.6.1.2.1.11.19.0");
    public static final OID SNMP_OUT_TOO_BIGS = new OID("1.3.6.1.2.1.11.20.0");
    public static final OID SNMP_OUT_NO_SUCH_NAMES = new OID("1.3.6.1.2.1.11.21.0");
    public static final OID SNMP_OUT_BAD_VALUES = new OID("1.3.6.1.2.1.11.22.0");
    public static final OID SNMP_OUT_GEN_ERRS = new OID("1.3.6.1.2.1.11.24.0");
    public static final OID SNMP_OUT_GET_REQUESTS = new OID("1.3.6.1.2.1.11.25.0");
    public static final OID SNMP_OUT_GET_NEXTS = new OID("1.3.6.1.2.1.11.26.0");
    public static final OID SNMP_OUT_SET_REQUESTS = new OID("1.3.6.1.2.1.11.27.0");
    public static final OID SNMP_OUT_GET_RESPONSES = new OID("1.3.6.1.2.1.11.28.0");
    public static final OID SNMP_OUT_TRAPS = new OID("1.3.6.1.2.1.11.29.0");

    /*  IfMIB (no instance) */
    public static final OID IF_NAME = new OID("1.3.6.1.2.1.31.1.1.1.1");
    public static final OID IF_IN_MULTICAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.2");
    public static final OID IF_IN_BROADCAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.3");
    public static final OID IF_OUT_MULTICAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.4");
    public static final OID IF_OUT_BROADCAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.5");
    public static final OID IF_HC_IN_OCTETS = new OID("1.3.6.1.2.1.31.1.1.1.6");
    public static final OID IF_HC_IN_UCAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.7");
    public static final OID IF_HC_IN_MULTICAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.8");
    public static final OID IF_HC_IN_BROADCAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.9");
    public static final OID IF_HC_OUT_OCTETS = new OID("1.3.6.1.2.1.31.1.1.1.10");
    public static final OID IF_HC_OUT_UCAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.11");
    public static final OID IF_HC_OUT_MULTICAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.12");
    public static final OID IF_HC_OUT_BROADCAST_PKTS = new OID("1.3.6.1.2.1.31.1.1.1.13");
    public static final OID IF_LINK_UPDOWN_TRAP_ENABLE = new OID("1.3.6.1.2.1.31.1.1.1.14");
    public static final OID IF_HIGH_SPEED = new OID("1.3.6.1.2.1.31.1.1.1.5");
    public static final OID IF_ALIAS = new OID("1.3.6.1.2.1.31.1.1.1.18");
}
