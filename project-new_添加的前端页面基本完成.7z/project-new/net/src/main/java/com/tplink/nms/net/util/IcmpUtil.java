package com.tplink.nms.net.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IcmpUtil {
    private static final int    PINT_TIMEOUT = 3000;
    private static final Logger logger       = LoggerFactory.getLogger(IcmpUtil.class);
    
    public static boolean isReachable(String ip) {
        return isReachable(ip, PINT_TIMEOUT);
    }
    
    public static boolean isReachable(String ip, int timeout) {
        long start = System.currentTimeMillis();
        boolean reachable = false;
        Process process;
        try {
            process = Runtime.getRuntime().exec("ping " + ip + " -n 4 -w " + timeout);
            BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
            
            String s;
            while ((s = br.readLine()) != null) {
                reachable = getCheckResult(s);
                if (reachable) {
                    break;
                }
            }
        } catch (Exception ex) {
            logger.warn(ex.getMessage(), ex);
        }
        long end = System.currentTimeMillis();
        logger.debug("used time is :" + (end - start) + "ms to ping " + ip);
        return reachable;
    }
    
    public static boolean getCheckResult(String line) {
        Pattern pattern = Pattern.compile("(\\d+ms)(\\s+)(TTL=\\d+)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(line);
        while (matcher.find()) {
            return true;
        }
        return false;
    }
    
    public static void main(String[] args) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(100);
        for (int i = 0; i < 1; i++) {
            Reachable reachable = new Reachable();
            pool.execute(reachable);
        }
        Thread.currentThread().join();
    }
    
    static class Reachable implements Runnable {
        
        @Override
        public void run() {
            long start = System.currentTimeMillis();
            Process process;
            try {
                process = Runtime.getRuntime().exec("ping 192.168.0.1 -n 4 -w 2000");
                BufferedReader br = new BufferedReader(new InputStreamReader(
                    process.getInputStream()));
                
                String s;
                while ((s = br.readLine()) != null) {
                    boolean result = getCheckResult(s);
                    if (result) {
                        break;
                    }
                }
                long end = System.currentTimeMillis();
                // System.out.println(sb.toString());
                logger.debug("used time is :" + (end - start) + "ms to ping ");
                // process.waitFor();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            long end = System.currentTimeMillis();
            System.out.println("used time is :" + (end - start));
        }
        
    }
}
