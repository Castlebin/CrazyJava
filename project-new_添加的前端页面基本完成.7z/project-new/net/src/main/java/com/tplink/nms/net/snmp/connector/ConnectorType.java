package com.tplink.nms.net.snmp.connector;

public enum ConnectorType {
	SNMP, ICMP
}
