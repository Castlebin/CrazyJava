package com.tplink.nms.net.snmp.domain;

import org.snmp4j.PDU;

import com.tplink.nms.net.snmp.proxy.EquipmentProxy;

public class SnmpPDU {
    private PDU            pdu;
    private int            snmpVersion;
    private EquipmentProxy proxy;
    
    public int getSnmpVersion() {
        return snmpVersion;
    }
    
    public void setSnmpVersion(int snmpVersion) {
        this.snmpVersion = snmpVersion;
    }
    
    public PDU getPdu() {
        return pdu;
    }
    
    public void setPdu(PDU pdu) {
        this.pdu = pdu;
    }
    
    public EquipmentProxy getProxy() {
        return proxy;
    }
    
    public void setProxy(EquipmentProxy proxy) {
        this.proxy = proxy;
    }
    
}
