package com.tplink.nms.net.snmp.domain;

import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.OctetString;

public class SnmpParamV3 extends SnmpParam {
    private SecurityLevel level;
    private AuthMode      authMode;
    private OctetString        securityName;
    private OctetString        authPassword;
    private PrivacyMode   privacyMode;
    private OctetString        privacyPassword;
    private OctetString        contextEngineId;
    
    private OctetString        localEngineId;
    
    public SnmpParamV3() {
        this(SecurityLevel.AUTH_PRIV, null, null, null, null, null, null, null);
    }
    
    public SnmpParamV3(SecurityLevel level, AuthMode authMode, OctetString securityName,
        OctetString authPassword, PrivacyMode privacyMode, OctetString privacyPassword,
        OctetString contextEngineId, OctetString localEngineId) {
        this.snmpVersion = SnmpConstants.version3;
        this.level = level;
        this.authPassword = authPassword;
        this.privacyPassword = privacyPassword;
        this.contextEngineId = contextEngineId;
        this.localEngineId = localEngineId;
        this.authMode = authMode;
        this.privacyMode = privacyMode;
        switch (level) {
        case NOAUTH_NOPRIV:
            authMode = authMode == null ? AuthMode.NONE : authMode;
            privacyMode = privacyMode == null ? PrivacyMode.NONE : privacyMode;
            break;
        case AUTH_NOPRIV:
            privacyMode = privacyMode == null ? PrivacyMode.NONE : privacyMode;
        default:
            break;
        }
        this.securityName = securityName;
    }
    
    public OctetString getLocalEngineId() {
        return localEngineId;
    }
    
    public OctetString getSecurityName() {
        return securityName;
    }
    
    public SecurityLevel getLevel() {
        return level;
    }
    
    public OctetString getAuthPassword() {
        return authPassword;
    }
    
    public OctetString getPrivacyPassword() {
        return privacyPassword;
    }
    
    public AuthMode getAuthMode() {
        return authMode;
    }
    
    public PrivacyMode getPrivacyMode() {
        return privacyMode;
    }
    
    public OctetString getContextEngineId() {
        return contextEngineId;
    }
    
}
