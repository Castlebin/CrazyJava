/*
 * Copyright (c) 2013-2014 Shenzhen TP-LINK Technologies Co., Ltd.
 */

package com.tplink.nms.net.snmp.gateway;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.snmp4j.PDU;
import org.snmp4j.smi.VariableBinding;

import com.tplink.nms.net.snmp.domain.SnmpVariableBinding;

public class SnmpGatewayResponse implements GatewayResponse {
    private int                       errorStatus;
    private int                       errorIndex;
    private int                       requestID;
    private List<SnmpVariableBinding> responseValues;
    private PDU                       pdu;
    
    public SnmpGatewayResponse() {
        
    }
    
    public SnmpGatewayResponse(PDU pdu) {
        if (pdu == null) {
            throw new NullPointerException("Snmp pdu is null.");
        }
        
        if (pdu.getType() != PDU.RESPONSE)
            throw new IllegalArgumentException(
                "Can't construct SnmpResponse from a none response pdu");
        
        this.pdu = pdu;
        errorIndex = pdu.getErrorIndex();
        errorStatus = pdu.getErrorStatus();
        requestID = pdu.getRequestID().toInt();
        responseValues = new ArrayList<>();
        
        Vector<VariableBinding> vbs = pdu.getVariableBindings();
        for (VariableBinding vb : vbs) {
            responseValues.add(new SnmpVariableBinding(vb));
        }
    }
    
    public int getErrorStatus() {
        return errorStatus;
    }
    
    public int getErrorIndex() {
        return errorIndex;
    }
    
    public int getRequestID() {
        return requestID;
    }
    
    public List<SnmpVariableBinding> getResponseValues() {
        return responseValues;
    }
    
    @Override
    public String toString() {
        return pdu.toString();
    }
    
    @Override
    public boolean isSuccess() {
        return errorStatus == 0;
    }
}
