package com.tplink.nms.net.snmp.connector;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tplink.nms.net.snmp.exception.SnmpException;
import com.tplink.nms.net.snmp.proxy.EquipmentProxy;
import com.tplink.nms.net.snmp.proxy.EquipmentProxyManage;

public class SnmpConnectorPool {
    private static SnmpConnectorPool instance = new SnmpConnectorPool();
    private List<SnmpConnector>      inUseConnectors;
    private volatile boolean         isInit   = false;
    private volatile boolean         isClosed = false;
    private final Object             _lock    = new Object();
    private Logger                   logger   = LoggerFactory.getLogger(getClass());
    
    private SnmpConnectorPool() {
        
    }
    
    public void initPool() {
        synchronized (_lock) {
            if (isInit || isClosed) {
                return;
            }
            try {
                inUseConnectors = new ArrayList<SnmpConnector>();
                isInit = true;
            } catch (SnmpException e) {
                
            }
            // logger.debug("initlizing " + ConnectorConstants.InitConnectorNum + " connectors");
        }
    }
    
    public synchronized void closePool() {
        synchronized (_lock) {
            for (SnmpConnector connector : inUseConnectors) {
                connector.destroy();
            }
            inUseConnectors.clear();
            isClosed = true;
            logger.debug("close connector pool");
        }
    }
    
    public static SnmpConnectorPool getInstance() {
        return instance;
    }
    
    public SnmpConnector getAvailbleConnector(String ip) {
        SnmpConnector connector = null;
        synchronized (_lock) {
            if (inUseConnectors.size() > 0) {
                for (SnmpConnector uConnector : inUseConnectors) {
                    if (ip.equals(uConnector.getIp())) {
                        connector = uConnector;
                    }
                }
            }
            if (null == connector) {
                connector = createSnmpConnector(ip);
                connector.setIp(ip);
                inUseConnectors.add(connector);
            }
            return connector;
        }
    }
    
    private SnmpConnector createSnmpConnector(String ip) throws SnmpException {
        EquipmentProxy proxy = EquipmentProxyManage.getInstance().getEquipmentProxy(ip);
        if (null == proxy) {
            proxy = EquipmentProxyManage.getInstance().createEquipmentProxy(ip);
        }
        return new SnmpConnector(proxy);
    }
    
    public synchronized void closeSnmpConnector(SnmpConnector connector) {
        if (inUseConnectors.contains(connector)) {
            logger.debug("return unused connector");
            inUseConnectors.remove(connector);
            connector.setIp(null);
        }
    }
    
    public int getInUseConnectorsNum() {
        return inUseConnectors.size();
    }
    
}
