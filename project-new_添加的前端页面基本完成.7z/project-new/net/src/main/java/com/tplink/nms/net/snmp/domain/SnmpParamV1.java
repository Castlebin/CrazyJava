package com.tplink.nms.net.snmp.domain;

import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.OctetString;

import com.tplink.nms.net.snmp.constants.NetContants;

public class SnmpParamV1 extends SnmpParam {
    protected OctetString readCommunity;
    protected OctetString writeCommunity;
    
    public SnmpParamV1() {
        this(NetContants.DEFAULT_READ_COMMUNITY, NetContants.DEFAULT_WRITE_COMMUNITY);
    }
    
    public SnmpParamV1(OctetString readCommunity, OctetString writeCommunity) {
        snmpVersion = SnmpConstants.version1;
        this.readCommunity = readCommunity;
        this.writeCommunity = writeCommunity;
    }
    
    public OctetString getReadCommunity() {
        return readCommunity;
    }
    
    public void setReadCommunity(OctetString readCommunity) {
        this.readCommunity = readCommunity;
    }
    
    public void setReadCommunity(String readCommunity) {
        this.readCommunity = new OctetString(readCommunity);
    }
    
    public OctetString getWriteCommunity() {
        return writeCommunity;
    }
    
    public void setWriteCommunity(OctetString writeCommunity) {
        this.writeCommunity = writeCommunity;
    }
    
    public void setWriteCommunity(String writeCommunity) {
        this.writeCommunity = new OctetString(writeCommunity);
    }
}
