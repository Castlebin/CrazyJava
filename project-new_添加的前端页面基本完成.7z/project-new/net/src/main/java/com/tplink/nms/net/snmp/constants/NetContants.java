package com.tplink.nms.net.snmp.constants;

import org.snmp4j.smi.OctetString;


public class NetContants {
    public static final int timeout                 = 500;
    public static final int retryTimes              = 0;
    public static final int SNMP_DEFAULT_PORT       = 161;
    public static OctetString    DEFAULT_READ_COMMUNITY  = new OctetString("public");
    public static OctetString    DEFAULT_WRITE_COMMUNITY = new OctetString("private");
}
