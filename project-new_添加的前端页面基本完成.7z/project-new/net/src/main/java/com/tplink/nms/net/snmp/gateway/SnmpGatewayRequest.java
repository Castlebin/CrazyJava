package com.tplink.nms.net.snmp.gateway;

import org.snmp4j.Target;

import com.tplink.nms.net.snmp.domain.SnmpPDU;
import com.tplink.nms.net.snmp.proxy.EquipmentProxy;

public class SnmpGatewayRequest implements GatewayRequest {
    private SnmpPDU        pdu;
    private Target         target;
    private EquipmentProxy proxy;
    
    public SnmpGatewayRequest() {
        
    }
    
    public SnmpGatewayRequest(SnmpPDU pdu, Target target) {
        this.pdu = pdu;
        this.target = target;
        this.proxy = pdu.getProxy();
    }
    
    public SnmpPDU getSnmpPdu() {
        return pdu;
    }
    
    public void setSnmpPdu(SnmpPDU pdu) {
        this.pdu = pdu;
    }
    
    public Target getTarget() {
        return target;
    }
    
    public void setTarget(Target target) {
        this.target = target;
    }
    
    public EquipmentProxy getProxy() {
        return proxy;
    }
    
    public void setProxy(EquipmentProxy proxy) {
        this.proxy = proxy;
    }
    
}
