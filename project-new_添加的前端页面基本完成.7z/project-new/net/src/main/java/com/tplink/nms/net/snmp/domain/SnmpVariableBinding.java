/*
 * Copyright (c) 2013-2014 Shenzhen TP-LINK Technologies Co., Ltd.
 */

package com.tplink.nms.net.snmp.domain;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

public class SnmpVariableBinding extends VariableBinding {

    /**
	 * 
	 */
	private static final long serialVersionUID = -5075447134932304467L;
	private OID oid;

    public SnmpVariableBinding(VariableBinding vb) {
        super(vb.getOid(), vb.getVariable());
        oid = vb.getOid();
    }

    public SnmpVariableBinding() {
        super();
    }

    public OID getSnmpOID() {
        return oid;
    }
}
