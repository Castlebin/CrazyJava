package com.tplink.nms.net.snmp.trap.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tplink.nms.net.snmp.trap.SnmpTrap;
import com.tplink.nms.net.snmp.trap.TrapFilter;

public class DefaultTrapHandler extends TrapHandler {
    private TrapFilter trapFilter;
    private Logger     logger = LoggerFactory.getLogger(getClass());
    
    public DefaultTrapHandler(TrapFilter trapFilter) {
        this.trapFilter = trapFilter;
    }
    
    @Override
    protected void process(SnmpTrap trap) {
        logger.debug("get snmp trap :" + trap.toString());
        if (filter(trap)) {
            if (trap.isV1trap()) {
                
            }
        }
    }
    
    public void setTrapFilter(TrapFilter trapFilter) {
        this.trapFilter = trapFilter;
    }
    
    @Override
    protected boolean filter(SnmpTrap trap) {
        return trapFilter.filter(trap.getTrapOID());
    }
    
}
