package com.tplink.nms.net.snmp.gateway;

import com.tplink.nms.net.snmp.connector.SnmpConnector;
import com.tplink.nms.net.snmp.connector.SnmpConnectorPool;
import com.tplink.nms.net.snmp.exception.SnmpException;
import com.tplink.nms.net.snmp.exception.SnmpParamException;

public class SnmpGateway implements Gateway {
    
    @Override
    public GatewayResponse sendRequest(GatewayRequest request) {
        SnmpGatewayResponse snmpGatewayResponse = null;
        SnmpConnector connector = null;
        try {
            if (request instanceof SnmpGatewayRequest) {
                SnmpGatewayRequest snmpGatewayRequest = (SnmpGatewayRequest) request;
                connector = SnmpConnectorPool.getInstance().getAvailbleConnector(
                    snmpGatewayRequest.getProxy().getIp());
                if (null != connector) {
                    snmpGatewayResponse = connector.get(snmpGatewayRequest.getSnmpPdu().getPdu(),
                        snmpGatewayRequest.getTarget());
                }
            }
        } catch (SnmpParamException e) {
            // TODO Auto-generated catch block
        } catch (SnmpException e) {
            // TODO Auto-generated catch block
        } finally {
            // if (null != connector) {
            // SnmpConnectorPool.getInstance().closeSnmpConnector(connector);
            // }
        }
        if (null == snmpGatewayResponse) {
            snmpGatewayResponse = new SnmpGatewayResponse();
        }
        return snmpGatewayResponse;
    }
    
    @Override
    public GatewayType getGatewayType() {
        return GatewayType.Snmp;
    }
    
}
