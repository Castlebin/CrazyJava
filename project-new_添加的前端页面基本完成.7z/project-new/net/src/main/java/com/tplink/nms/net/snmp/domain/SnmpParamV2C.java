package com.tplink.nms.net.snmp.domain;

import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.OctetString;

public class SnmpParamV2C extends SnmpParamV1 {
    public SnmpParamV2C() {
        super();
        this.snmpVersion = SnmpConstants.version2c;
    }
    
    public SnmpParamV2C(OctetString readCommunity, OctetString writeCommunity) {
        super(readCommunity, writeCommunity);
        this.snmpVersion = SnmpConstants.version2c;
    }
}
