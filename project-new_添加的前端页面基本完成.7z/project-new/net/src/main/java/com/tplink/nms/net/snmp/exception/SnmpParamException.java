package com.tplink.nms.net.snmp.exception;


/**
 * Created by Simon Wei on 2015/4/16.
 */
public class SnmpParamException extends SnmpException {
    public SnmpParamException(String message) {
        super(message);
    }
}
