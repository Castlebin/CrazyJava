package com.tplink.nms.net.snmp.trap;

import java.util.ArrayList;
import java.util.List;

import org.snmp4j.smi.OID;

public class TrapFilter {
    public enum FilterType {
        ALL_PASS, SELECTED_PASS
    }
    
    private List<OID>  passOIDs;
    private FilterType filterType;
    private String     filterName;
    
    private TrapFilter(FilterType type) {
        passOIDs = new ArrayList<>();
        filterType = type;
    }
    
    public static TrapFilter newInstance(String filterName) {
        TrapFilter filter = new TrapFilter(FilterType.ALL_PASS);
        filter.filterName = filterName;
        return filter;
    }
    
    public static TrapFilter newInstance() {
        return new TrapFilter(FilterType.SELECTED_PASS);
    }
    
    List<OID> getPassOIDs() {
        return passOIDs;
    }
    
    public TrapFilter addOID(OID oid) {
        if (filterType != FilterType.ALL_PASS)
            passOIDs.add(oid);
        return this;
    }
    
    public boolean filter(OID oid) {
        return filterType == FilterType.ALL_PASS || passOIDs.contains(oid);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        
        TrapFilter that = (TrapFilter) o;
        
        if (filterName != null ? !filterName.equals(that.filterName)
            : that.filterName != null)
            return false;
        if (filterType != that.filterType)
            return false;
        if (!passOIDs.equals(that.passOIDs))
            return false;
        
        return true;
    }
    
    @Override
    public int hashCode() {
        int result = passOIDs.hashCode();
        result = 31 * result + filterType.hashCode();
        result = 31 * result + (filterName != null ? filterName.hashCode() : 0);
        return result;
    }
}
