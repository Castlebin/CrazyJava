package com.tplink.nms.net.snmp.gateway;

public interface GatewayRequest {

}
