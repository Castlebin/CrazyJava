package com.tplink.nms.net.snmp.proxy;

import java.util.HashMap;
import java.util.Map;

import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.GenericAddress;

import com.tplink.nms.net.snmp.constants.NetContants;
import com.tplink.nms.net.snmp.domain.SnmpParam;
import com.tplink.nms.net.snmp.domain.SnmpParamV1;
import com.tplink.nms.net.snmp.domain.SnmpParamV2C;
import com.tplink.nms.net.snmp.domain.SnmpParamV3;

public class EquipmentProxy {
    private String                  ip;
    private int                     port;
    private long                    lastHearbeatTime;
    private long                    lastConnectedTime;
    private boolean                 hasConnectedBefore;
    private EquipmentProxyState     state;
    private Address                 address;
    private Map<Integer, SnmpParam> snmpParams = new HashMap<Integer, SnmpParam>();
    
    enum EquipmentProxyState {
        ONLINE, OFFLINE
    }
    
    protected EquipmentProxy(String ip) {
        this.ip = ip;
        this.port = NetContants.SNMP_DEFAULT_PORT;
        snmpParams.put(SnmpConstants.version1, new SnmpParamV1());
        snmpParams.put(SnmpConstants.version2c, new SnmpParamV2C());
        snmpParams.put(SnmpConstants.version3, new SnmpParamV3());
    }
    
    public void setSnmpParam(int snmpVersion, SnmpParam snmpParam) {
        snmpParams.put(snmpVersion, snmpParam);
    }
    
    public Address getAddress() {
        if (address == null) {
            address = GenericAddress.parse(ip + "/" + port);
        }
        return address;
    }
    
    public void setAddress(Address address) {
        this.address = address;
    }
    
    public String getIp() {
        return ip;
    }
    
    public void setIp(String ip) {
        this.ip = ip;
    }
    
    public int getPort() {
        return port;
    }
    
    public void setPort(int port) {
        this.port = port;
    }
    
    public long getLastHearbeatTime() {
        return lastHearbeatTime;
    }
    
    public void setLastHearbeatTime(long lastHearbeatTime) {
        this.lastHearbeatTime = lastHearbeatTime;
    }
    
    public long getLastConnectedTime() {
        return lastConnectedTime;
    }
    
    public void setLastConnectedTime(long lastConnectedTime) {
        this.lastConnectedTime = lastConnectedTime;
    }
    
    public boolean isHasConnectedBefore() {
        return hasConnectedBefore;
    }
    
    public void setHasConnectedBefore(boolean hasConnectedBefore) {
        this.hasConnectedBefore = hasConnectedBefore;
    }
    
    public EquipmentProxyState getState() {
        return state;
    }
    
    public void setState(EquipmentProxyState state) {
        this.state = state;
    }
    
    public SnmpParam getSnmpParam(int snmpVersion) {
        return snmpParams.get(snmpVersion);
    }

}
