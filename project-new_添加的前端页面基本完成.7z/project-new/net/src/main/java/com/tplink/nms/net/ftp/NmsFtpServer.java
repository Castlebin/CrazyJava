package com.tplink.nms.net.ftp;

import java.io.File;

import org.apache.ftpserver.FtpServer;
import org.apache.ftpserver.FtpServerFactory;
import org.apache.ftpserver.ftplet.FtpException;
import org.apache.ftpserver.usermanager.PropertiesUserManagerFactory;

import com.tplink.nms.utils.FileUtil;

public class NmsFtpServer implements FtpServer {
    
    private FtpServer server;
    private String    fileName;
    
    public NmsFtpServer(String fileName) {
        this.fileName = fileName;
        FtpServerFactory serverFactory = new FtpServerFactory();
        PropertiesUserManagerFactory userManagerFactory = new PropertiesUserManagerFactory();
        File file = FileUtil.getFile(fileName);
        userManagerFactory.setFile(file);
        serverFactory.setUserManager(userManagerFactory.createUserManager());
        server = serverFactory.createServer();
    }
    
    public String getFileName() {
        return fileName;
    }
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    @Override
    public void start() throws FtpException {
        server.start();
    }
    
    @Override
    public void stop() {
        server.stop();
    }
    
    @Override
    public boolean isStopped() {
        return server.isStopped();
    }
    
    @Override
    public void suspend() {
        server.suspend();
    }
    
    @Override
    public void resume() {
        server.resume();
    }
    
    @Override
    public boolean isSuspended() {
        return server.isSuspended();
    }
    
}
