package com.tplink.nms.net.snmp.common;

import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.ScopedPDU;
import org.snmp4j.SecureTarget;
import org.snmp4j.Target;
import org.snmp4j.UserTarget;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.security.SecurityModel;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.IpAddress;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.util.DefaultPDUFactory;

import com.tplink.nms.net.snmp.constants.NetContants;
import com.tplink.nms.net.snmp.domain.SnmpPDU;
import com.tplink.nms.net.snmp.domain.SnmpParam;
import com.tplink.nms.net.snmp.domain.SnmpParam.AuthMode;
import com.tplink.nms.net.snmp.domain.SnmpParam.PrivacyMode;
import com.tplink.nms.net.snmp.domain.SnmpParam.SecurityLevel;
import com.tplink.nms.net.snmp.domain.SnmpParamV1;
import com.tplink.nms.net.snmp.domain.SnmpParamV2C;
import com.tplink.nms.net.snmp.domain.SnmpParamV3;
import com.tplink.nms.net.snmp.exception.SnmpException;
import com.tplink.nms.net.snmp.gateway.SnmpGatewayRequest;
import com.tplink.nms.net.snmp.proxy.EquipmentProxy;

public class SnmpBuilder {
    
    public static SnmpParam newSnmpParamV1() {
        SnmpParamV1 snmpParam = new SnmpParamV1();
        snmpParam.setReadCommunity(NetContants.DEFAULT_READ_COMMUNITY);
        snmpParam.setWriteCommunity(NetContants.DEFAULT_WRITE_COMMUNITY);
        return snmpParam;
    }
    
    public static SnmpParam newSnmpParamV2() {
        SnmpParamV2C snmpParam = new SnmpParamV2C();
        snmpParam.setReadCommunity(NetContants.DEFAULT_READ_COMMUNITY);
        snmpParam.setWriteCommunity(NetContants.DEFAULT_WRITE_COMMUNITY);
        return snmpParam;
    }
    
    public static SnmpParam newSnmpParamV3(String securityName, String authPassword,
        String privacyPassword, String contextEngineId, String localEngineId) {
        SnmpParamV3 snmpParam = new SnmpParamV3(SecurityLevel.AUTH_PRIV, AuthMode.MD5,
            new OctetString(securityName), new OctetString(authPassword), PrivacyMode.NONE,
            new OctetString(privacyPassword), new OctetString(contextEngineId), new OctetString(
                localEngineId));
        return snmpParam;
    }
    
    public static SnmpParam newSnmpParamV3(SecurityLevel level, AuthMode authMode,
        String securityName, String authPassword, PrivacyMode privacyMode, String privacyPassword,
        String contextEngineId, String localEngineId) {
        SnmpParamV3 snmpParam = new SnmpParamV3(level, authMode, new OctetString(securityName),
            new OctetString(authPassword), privacyMode, new OctetString(privacyPassword),
            new OctetString(contextEngineId), new OctetString(localEngineId));
        return snmpParam;
    }
    
    public static SnmpGatewayRequest newSnmpGatewayRequest(SnmpParam snmpParam, String ip) {
        SnmpGatewayRequest request = new SnmpGatewayRequest();
        // TODO
        return request;
    }
    
    public static <clazz> Target newTarget(Class<?> clazz, EquipmentProxy proxy) {
        if (CommunityTarget.class.isAssignableFrom(clazz)) {
            SnmpParamV1 param = (SnmpParamV1) proxy.getSnmpParam(SnmpConstants.version1);
            CommunityTarget target = new CommunityTarget();
            if (proxy != null) {
                target.setAddress(proxy.getAddress());
            }
            target.setCommunity(new OctetString(param.getReadCommunity()));
            if (param.getType() == PDU.SET)
                target.setCommunity(new OctetString(param.getWriteCommunity()));
            target.setRetries(NetContants.retryTimes);
            target.setTimeout(NetContants.timeout);
            return target;
        } else if (SecureTarget.class.isAssignableFrom(clazz)) {
            SnmpParamV3 param = (SnmpParamV3) proxy.getSnmpParam(SnmpConstants.version3);
            UserTarget target = new UserTarget();
            target.setVersion(SnmpConstants.version3);
            target.setAddress(proxy.getAddress());
            target.setSecurityLevel(SecurityModel.SECURITY_MODEL_USM);
            target.setSecurityName(new OctetString(param.getSecurityName()));
            target.setTimeout(NetContants.timeout);
            target.setRetries(NetContants.retryTimes);
            return target;
        }
        return null;
    }
    
    public static PDU createPDU(int snmpVersion, EquipmentProxy proxy) {
        PDU pdu = DefaultPDUFactory.createPDU(snmpVersion);
        if (snmpVersion == SnmpConstants.version3) {
            SnmpParamV3 snmpParam = (SnmpParamV3) proxy.getSnmpParam(snmpVersion);
            ((ScopedPDU) pdu).setContextEngineID(snmpParam.getContextEngineId());
        }
        return pdu;
    }
    
    public static SnmpPDU generateSnmpPDU(int pduType, int snmpVersion, EquipmentProxy proxy,
        String... oids) {
        SnmpPDU snmpPDU = new SnmpPDU();
        PDU pdu = createPDU(snmpVersion, proxy);
        for (String oid : oids) {
            pdu.add(new VariableBinding(new OID(oid)));
        }
        pdu.setType(pduType);
        snmpPDU.setPdu(pdu);
        snmpPDU.setProxy(proxy);
        return snmpPDU;
    }
    
    public static SnmpPDU generateSetSnmpPDU(int snmpVersion, EquipmentProxy proxy, String oid,
        Object value) {
        SnmpPDU snmpPDU = new SnmpPDU();
        PDU pdu = createPDU(snmpVersion, null);
        pdu.setType(PDU.SET);
        if (value instanceof Integer) {
            pdu.add(new VariableBinding(new OID(oid), new Integer32((Integer) value)));
        } else if (value instanceof String) {
            pdu.add(new VariableBinding(new OID(oid), new OctetString((String) value)));
        } else if (value instanceof IpAddress) {
            pdu.add(new VariableBinding(new OID(oid), (IpAddress) value));
        } else {
            throw new SnmpException("Unsupported value type");
        }
        snmpPDU.setPdu(pdu);
        snmpPDU.setProxy(proxy);
        return snmpPDU;
    }
    
    public static SnmpPDU generateGetBulkSnmpPDU(int snmpVersion, EquipmentProxy proxy, String oid,
        int maxRepetitions) {
        if (maxRepetitions < 1) {
            throw new SnmpException("Parameters maxRepetitions must be equal or greater than 1.");
        }
        SnmpPDU snmpPDU = new SnmpPDU();
        PDU pdu = createPDU(snmpVersion, null);
        pdu.setType(PDU.GETBULK);
        pdu.add(new VariableBinding(new OID(oid)));
        pdu.setMaxRepetitions(maxRepetitions);
        snmpPDU.setPdu(pdu);
        snmpPDU.setProxy(proxy);
        return snmpPDU;
    }
}
