package com.tplink.nms.net.snmp.trap;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.snmp4j.CommandResponderEvent;
import org.snmp4j.PDU;
import org.snmp4j.PDUv1;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.smi.VariableBinding;

import com.tplink.nms.net.snmp.constants.SnmpOID;
import com.tplink.nms.net.snmp.domain.SnmpVariableBinding;

public class SnmpTrap implements Iterable<SnmpVariableBinding> {
    private CommandResponderEvent     commandResponderEvent;
    private OID                       trapOID;
    private String                    trapTime;
    private List<SnmpVariableBinding> trapVbs;
    /* some other pdu's fields */
    private int                       errorIndex;
    private int                       errorStatus;
    private String                    errorStatusText;
    private int                       requestID;
    /* v1 trap fields */
    private boolean                   isV1trap;
    private OID                       enterprise;
    private int                       specificTrapId;
    private int                       genericTrapId;
    
    /* Some other responder event's fields */
    private String                    senderIp;
    
    @SuppressWarnings("unchecked")
    public SnmpTrap(CommandResponderEvent commandResponderEvent) {
        this.commandResponderEvent = commandResponderEvent;
        PDU pdu = commandResponderEvent.getPDU();
        trapVbs = new ArrayList<SnmpVariableBinding>();
        Vector<VariableBinding> vbs = pdu.getVariableBindings();
        Iterator<VariableBinding> iterator = vbs.iterator();
        while (iterator.hasNext()) {
            VariableBinding svb = iterator.next();
            if (svb.getOid().equals(SnmpOID.SNMP_TRAP)) {
                trapOID = new OID(svb.getVariable().toString());
            } else if (svb.getOid().equals(SnmpOID.SYS_UP_TIME)) {
                trapTime = svb.getVariable().toString();
            } else {
                trapVbs.add(new SnmpVariableBinding(svb));
            }
        }
        
        if (pdu.getType() == PDU.V1TRAP) {
            isV1trap = true;
            PDUv1 pdu1 = (PDUv1) pdu;
            this.enterprise = pdu1.getEnterprise();
            this.specificTrapId = pdu1.getSpecificTrap();
            this.genericTrapId = pdu1.getGenericTrap();
        } else {
            isV1trap = false;
        }
        
        this.errorIndex = pdu.getErrorIndex();
        this.errorStatus = pdu.getErrorStatus();
        this.errorStatusText = pdu.getErrorStatusText();
        this.requestID = pdu.getRequestID().toInt();
        this.senderIp = new UdpAddress(commandResponderEvent.getPeerAddress().toString())
            .getInetAddress().getHostAddress();
    }
    
    public CommandResponderEvent getCommandResponderEvent() {
        return commandResponderEvent;
    }
    
    public void setCommandResponderEvent(CommandResponderEvent commandResponderEvent) {
        this.commandResponderEvent = commandResponderEvent;
    }
    
    @Override
    public Iterator<SnmpVariableBinding> iterator() {
        return trapVbs.iterator();
    }
    
    public OID getTrapOID() {
        if (isV1trap)
            throw new IllegalStateException(
                "V1 trap doesn't have this field, use !isV1trap() to judge first.");
        return trapOID;
    }
    
    public String getTrapTime() {
        if (isV1trap)
            throw new IllegalStateException(
                "V1 trap doesn't have this field, use !isV1trap() to judge first.");
        return trapTime;
    }
    
    public int getErrorIndex() {
        return errorIndex;
    }
    
    public int getErrorStatus() {
        return errorStatus;
    }
    
    public String getErrorStatusText() {
        return errorStatusText;
    }
    
    public int getRequestID() {
        return requestID;
    }
    
    public String getSenderAddress() {
        return senderIp;
    }
    
    public boolean isV1trap() {
        return isV1trap;
    }
    
    public OID getEnterprise() {
        if (!isV1trap)
            throw new IllegalStateException("Not a v1 trap, use isV1trap() to judge first.");
        return enterprise;
    }
    
    public int getSpecificTrapId() {
        if (!isV1trap)
            throw new IllegalStateException("Not a v1 trap, use isV1trap() to judge first.");
        return specificTrapId;
    }
    
    public int getGenericTrapId() {
        if (!isV1trap)
            throw new IllegalStateException("Not a v1 trap, use isV1Trap() to judge first.");
        return genericTrapId;
    }
    
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
    
    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }
    
    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }
    
}
