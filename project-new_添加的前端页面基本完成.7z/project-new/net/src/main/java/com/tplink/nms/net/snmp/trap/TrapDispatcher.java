package com.tplink.nms.net.snmp.trap;

import java.util.HashMap;
import java.util.Map;

import org.snmp4j.CommandResponderEvent;

import com.tplink.nms.net.snmp.trap.handler.DefaultTrapHandler;
import com.tplink.nms.net.snmp.trap.handler.TrapHandler;

public class TrapDispatcher {
    private static final Map<TrapFilter, TrapHandler> trapHandlers = new HashMap<TrapFilter, TrapHandler>();
    static {
        TrapFilter filter = TrapFilter.newInstance("default");
        trapHandlers.put(filter, new DefaultTrapHandler(filter));
    }
    
    public static void dispatch(CommandResponderEvent event) {
        for (TrapFilter filter : trapHandlers.keySet()) {
            TrapHandler handler = trapHandlers.get(filter);
            handler.processPdu(event);
        }
    }
    
    public static void addTrapHandler(TrapFilter filter, TrapHandler handler) {
        trapHandlers.put(filter, handler);
    }
    
}
