package com.tplink.nms.net.snmp.constants;

public class ConnectorConstants {
    public static final int MaxConnectorNum  = 30;
    public static final int InitConnectorNum = 10;
}
