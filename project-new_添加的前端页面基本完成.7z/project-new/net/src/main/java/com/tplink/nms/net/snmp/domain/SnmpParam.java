package com.tplink.nms.net.snmp.domain;

import org.snmp4j.PDU;

/**
 * Created by Simon Wei on 2015/4/15.
 */
public abstract class SnmpParam {
    protected int snmpVersion;
    protected int type = PDU.GET;
    
    public int getSnmpVersion() {
        return snmpVersion;
    }
    
    public void setSnmpVersion(int snmpVersion) {
        this.snmpVersion = snmpVersion;
    }
    
    public int getType() {
        return type;
    }
    
    public void setType(int type) {
        this.type = type;
    }
    
    public enum AuthMode {
        NONE, MD5, SHA
    }
    
    public enum PrivacyMode {
        NONE, DES, DES3, AES128, AES196, AES256
    }
    
    public enum SecurityLevel {
        NOAUTH_NOPRIV, AUTH_NOPRIV, AUTH_PRIV;
        
        public int toInt() {
            switch (this) {
            case NOAUTH_NOPRIV:
                return 1;
            case AUTH_NOPRIV:
                return 2;
            case AUTH_PRIV:
                return 3;
            default:
                return 1;
            }
        }
    }
}
