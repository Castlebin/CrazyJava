package com.tplink.nms.net.snmp.connector;


/**
 * Created by Simon Wei on 2015/4/16.
 */
public interface Connector {
	public ConnectorType getConnectorType();
}
