package com.tplink.nms.net.module;

import org.apache.ftpserver.ftplet.FtpException;

import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;
import com.tplink.nms.module.ModuleState;
import com.tplink.nms.mq.MQManager;
import com.tplink.nms.mq.MQModule;
import com.tplink.nms.net.ftp.NmsFtpServer;
import com.tplink.nms.net.snmp.connector.SnmpConnectorPool;
import com.tplink.nms.net.snmp.proxy.EquipmentProxyManage;
import com.tplink.nms.net.snmp.trap.TrapReceiver;

public class NetModule extends AbstractModule {
    private final Object _lock = new Object();
    private MQModule     mqModule;
    private NmsFtpServer nmsFtpServer;
    
    @Override
    public void execute(ModuleContext moduleContext) throws ModuleRunException {
        synchronized (_lock) {
            SnmpConnectorPool.getInstance().initPool();
            TrapReceiver.getInstance().run();
            nmsFtpServer = new NmsFtpServer("properties/ftp.properties");
            try {
                nmsFtpServer.start();
            } catch (FtpException e) {
                throw new ModuleRunException(e.getMessage());
            }
            mqModule = MQManager.newModule(moduleName);
            mqModule.start();
            moduleState = ModuleState.RUNNING;
        }
    }
    
    @Override
    public void stop() {
        synchronized (_lock) {
            SnmpConnectorPool.getInstance().closePool();
            TrapReceiver.getInstance().stop();
            if (null != nmsFtpServer) {
                nmsFtpServer.stop();
            }
            if (mqModule != null) {
                mqModule.stop();
            }
            EquipmentProxyManage.getInstance().shutdownDetectTask();
            moduleState = ModuleState.STOPED;
        }
    }
    
}
