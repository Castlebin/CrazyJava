package com.tplink.nms.net.snmp.trap.handler;

import org.snmp4j.CommandResponder;
import org.snmp4j.CommandResponderEvent;

import com.tplink.nms.net.snmp.trap.SnmpTrap;

/**
 * Created by Simon Wei on 2015/4/16.
 */
public abstract class TrapHandler implements CommandResponder {
    @Override
    public void processPdu(CommandResponderEvent commandResponderEvent) {
        SnmpTrap trap = new SnmpTrap(commandResponderEvent);
        process(trap);
    }
    
    protected abstract void process(SnmpTrap trap);
    
    protected abstract boolean filter(SnmpTrap trap);
}
