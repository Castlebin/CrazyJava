package com.tplink.nms.bootstrap;

/**
 * Created by Simon Wei on 2015/4/2.
 */
public class RunException extends Exception{
    private Exception oldException = null;

    public RunException(String msg){
        super(msg);
    }

    public RunException(String msg, Exception oldException){
        super(msg);
        this.oldException = oldException;
    }
}
