package com.tplink.nms.bootstrap;

import com.tplink.nms.module.AbstractModule;
import com.tplink.nms.module.Module;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.utils.FileUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.ArrayList;

/**
 * Created by Simon Wei on 2015/4/2.
 */
public class XmlModules {
    private String xmlModulePath = "";

    public XmlModules(String xmlFileName) {
        xmlModulePath = xmlFileName;
    }

    public void parse(ModuleContext context) throws RunException {
        File file = new File(xmlModulePath);
        if (!validate(file)) {
            file = FileUtil.getConfFile(xmlModulePath, XmlModules.class);
            if (!validate(file)) {
                throw new RunException("Modules file " + xmlModulePath + " is NOT EXIST!");
            }
        }

        Document document = getDocument(file);
        Element root = document.getDocumentElement();
        parseElementRoot(root, context);
    }

    private boolean validate(File file) {
        if (!file.exists()) {
            return false;
        } else {
            // TODO
            // xsd format check , infinite loop detect.
            return true;
        }
    }

    private Document getDocument(File file) throws RunException {
        DocumentBuilderFactory facotry = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = null;
        Document doc = null;
        try {
            builder = facotry.newDocumentBuilder();
            doc = builder.parse(file);
        } catch (Exception e) {
            throw new RunException("Modules file " + file.getName() + " parse ERROR.", e);
        }
        return doc;
    }

    private void parseElementRoot(Element root, ModuleContext context) throws RunException {
        NodeList children = root.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (!(child instanceof Element))
                continue;

            Element childElement = (Element) child;
            if (childElement.getTagName().equals("modules")) {
                parseElementModules(childElement, context);
            }
        }
    }

    private void parseElementModules(Element modules, ModuleContext context) throws RunException {
        NodeList children = modules.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (!(child instanceof Element))
                continue;
            Element childElement = (Element) child;
            if (childElement.getTagName().equals("module")) {
                parseElementModule(childElement, context);
            }
        }
    }

    private void parseElementModule(Element moduleElement, ModuleContext context) throws RunException {
        String moduleName = moduleElement.getAttribute("name");
        String moduleClassName = "";
        String moduleDescription = "";
        ArrayList<String> dmNameLists = new ArrayList<String>();

        NodeList children = moduleElement.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (!(child instanceof Element))
                continue;
            Element childElement = (Element) child;
            if (childElement.getTagName().equals("className")) {
                moduleClassName = childElement.getFirstChild().getNodeValue();
            }else if(childElement.getTagName().equals("dependencyModuleList")){
                NodeList dmList = childElement.getChildNodes();
                for(int j=0; j<dmList.getLength(); j++) {
                    Node md = dmList.item(j);
                    if (!(md instanceof Element))
                        continue;
                    Element mdElement = (Element) md;
                    if (mdElement.getTagName().equals("dependencyModule")) {
                        String dependencyModuleNames = mdElement.getFirstChild().getNodeValue();
                        String[] nameList = dependencyModuleNames.split(",");
                        if(nameList != null) {
                            for (int li = 0; li < nameList.length; li++) {
                                dmNameLists.add(nameList[li].trim());
                            }
                        }
                    }
                }
            }else if(childElement.getTagName().equals("description")){
                moduleDescription = childElement.getFirstChild().getNodeValue();
            }

        }

        if (moduleName == null || moduleName.isEmpty() || moduleClassName.isEmpty()) {
            throw new RunException("Modules file parse ERROR.");
        }


        Class<?> clazz;
        Object o;
        try {
            clazz = Class.forName(moduleClassName);
            o = clazz.newInstance();
        } catch (Exception e) {
            throw new RunException("Module class " + moduleClassName + " instance ERROR.", e);
        }

        if(o == null || !(o instanceof AbstractModule)){
            throw new RunException("Invalid module class name : " + moduleClassName);
        }
        Module module = (Module)o;
        module.setModuleName(moduleName);
        module.setModuleDescription(moduleDescription);
        for(String dmName : dmNameLists){
            module.pushDependencyModule(dmName);
        }

        context.putModule(module);
    }
}
