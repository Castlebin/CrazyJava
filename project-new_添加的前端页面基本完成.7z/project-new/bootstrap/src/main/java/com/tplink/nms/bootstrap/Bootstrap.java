package com.tplink.nms.bootstrap;

import com.tplink.nms.config.PropertyKey;
import com.tplink.nms.module.Module;
import com.tplink.nms.module.ModuleContext;
import com.tplink.nms.module.ModuleRunException;
import com.tplink.nms.module.ModuleState;
import com.tplink.nms.system.Handler;
import com.tplink.nms.system.NmsSystem;
import com.tplink.nms.utils.SystemUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by Simon Wei on 2015/3/31.
 */
public class Bootstrap {
    private static final String XML_MODULE_PATH = "modules.xml";

    public static void main(String[] args) {
        init(args);

        XmlModules xmlModules = new XmlModules(XML_MODULE_PATH);
        final ModuleContext moduleContext = ModuleContext.getModuleContextInstance();
        try {
            xmlModules.parse(moduleContext);
        } catch (RunException e) {
        }

        run(moduleContext);

        NmsSystem.addHandler("bootstrap.stop", new Handler() {
            @Override
            public void handle(Object... objects) {
                stop(moduleContext);
            }
        });
    }

    private static void run(ModuleContext context) {
        for (String moduleName : context) {
            Module module = context.getModuleByName(moduleName);
            try {
                module.run(context);
            } catch (ModuleRunException e) {
                Logger logger = LoggerFactory.getLogger(Bootstrap.class);
                logger.error(e.getMessage());
                stop(context);
                break;
            }
        }
    }

    private static void stop(ModuleContext context) {
        for (String moduleName : context) {
            Module module = context.getModuleByName(moduleName);
            if (module.getModuleState().equals(ModuleState.RUNNING)) {
                module.stop();
            }
        }
    }

    private static void init(String[] args) {
        String nmsHome = System.getProperty(PropertyKey.HOME_KEY_SUFFIX);
        if (nmsHome == null) {
            nmsHome = SystemUtil.getHomePath();
            System.setProperty(PropertyKey.HOME_KEY_SUFFIX, nmsHome);
        }
    }
}
