-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        5.5.16-enterprise-commercial-advanced - MySQL Enterprise Server - Advanced Edition (Commercial)
-- 服务器操作系统:                      Win32
-- HeidiSQL 版本:                  9.1.0.4867
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 导出 tnt_cm 的数据库结构
DROP DATABASE IF EXISTS `tnt_cm`;
CREATE DATABASE IF NOT EXISTS `tnt_cm` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tnt_cm`;


-- 导出  表 tnt_cm.tbl_backup_file 结构
DROP TABLE IF EXISTS `tbl_backup_file`;
CREATE TABLE IF NOT EXISTS `tbl_backup_file` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DEVICE_ID` int(10) unsigned NOT NULL,
  `BACKFILE` varchar(64) NOT NULL,
  `BACKTIME` datetime NOT NULL,
  `BASEFLAG` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_cm.tbl_backup_file 的数据：~0 rows (大约)
DELETE FROM `tbl_backup_file`;
/*!40000 ALTER TABLE `tbl_backup_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_backup_file` ENABLE KEYS */;


-- 导出  表 tnt_cm.tbl_backup_task 结构
DROP TABLE IF EXISTS `tbl_backup_task`;
CREATE TABLE IF NOT EXISTS `tbl_backup_task` (
  `TASK_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TASK_NAME` varchar(64) NOT NULL,
  `TASK_DESCRIPTION` varchar(128) DEFAULT NULL,
  `TASK_STATUS` varchar(32) NOT NULL,
  `TASK_CYCLE` varchar(32) NOT NULL,
  `TASK_WEEKDAY` varchar(32) DEFAULT NULL,
  `TASK_MONTHDAY` varchar(32) DEFAULT NULL,
  `TASK_RUNTIME` varchar(64) NOT NULL,
  `TASK_LAST_RESULT` varchar(255) DEFAULT NULL,
  `TASK_LAST_RUNTIME` datetime DEFAULT NULL,
  PRIMARY KEY (`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_cm.tbl_backup_task 的数据：~0 rows (大约)
DELETE FROM `tbl_backup_task`;
/*!40000 ALTER TABLE `tbl_backup_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_backup_task` ENABLE KEYS */;


-- 导出  表 tnt_cm.tbl_backup_task_device 结构
DROP TABLE IF EXISTS `tbl_backup_task_device`;
CREATE TABLE IF NOT EXISTS `tbl_backup_task_device` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TASK_ID` int(10) unsigned NOT NULL,
  `DEVICE_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `TASK_ID` (`TASK_ID`),
  CONSTRAINT `tbl_backup_task_device_ibfk_1` FOREIGN KEY (`TASK_ID`) REFERENCES `tbl_backup_task` (`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_cm.tbl_backup_task_device 的数据：~0 rows (大约)
DELETE FROM `tbl_backup_task_device`;
/*!40000 ALTER TABLE `tbl_backup_task_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_backup_task_device` ENABLE KEYS */;


-- 导出  表 tnt_cm.tbl_backup_task_excutedetail 结构
DROP TABLE IF EXISTS `tbl_backup_task_excutedetail`;
CREATE TABLE IF NOT EXISTS `tbl_backup_task_excutedetail` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TASK_ID` int(10) unsigned NOT NULL,
  `DEVICE_ID` int(10) unsigned NOT NULL,
  `BACKRESULT` varchar(64) NOT NULL,
  `BACKTYPE` varchar(64) NOT NULL,
  `BACKFILE` varchar(64) DEFAULT NULL,
  `ERRORCODE` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `DEVICE_ID` (`DEVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_cm.tbl_backup_task_excutedetail 的数据：~0 rows (大约)
DELETE FROM `tbl_backup_task_excutedetail`;
/*!40000 ALTER TABLE `tbl_backup_task_excutedetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_backup_task_excutedetail` ENABLE KEYS */;


-- 导出  表 tnt_cm.tbl_deploy_task 结构
DROP TABLE IF EXISTS `tbl_deploy_task`;
CREATE TABLE IF NOT EXISTS `tbl_deploy_task` (
  `TASK_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TASK_NAME` varchar(64) NOT NULL,
  `TASK_DESCRIPTION` varchar(255) DEFAULT NULL,
  `TASK_TYPE` varchar(32) NOT NULL,
  `TASK_STATUS` varchar(32) NOT NULL,
  `TASK_RESULT` varchar(64) NOT NULL,
  `TASK_CREATEBY` varchar(64) NOT NULL,
  `TASK_CREATETIME` datetime NOT NULL,
  `TASK_DEPLOYTIME` datetime NOT NULL,
  `TASK_DEPLOYTYPE` varchar(32) NOT NULL,
  `TASK_DEPLOY_RECOVER_POLICY` int(10) unsigned NOT NULL,
  `TASK_DEPLOYORDER` text NOT NULL,
  PRIMARY KEY (`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_cm.tbl_deploy_task 的数据：~0 rows (大约)
DELETE FROM `tbl_deploy_task`;
/*!40000 ALTER TABLE `tbl_deploy_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_deploy_task` ENABLE KEYS */;


-- 导出  表 tnt_cm.tbl_deploy_taskdevice 结构
DROP TABLE IF EXISTS `tbl_deploy_taskdevice`;
CREATE TABLE IF NOT EXISTS `tbl_deploy_taskdevice` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TASK_ID` int(10) unsigned NOT NULL,
  `DEVICE_ID` int(10) unsigned NOT NULL,
  `DEPLOY_ORDER` text,
  PRIMARY KEY (`ID`),
  KEY `TASK_ID` (`TASK_ID`),
  CONSTRAINT `tbl_deploy_taskdevice_ibfk_1` FOREIGN KEY (`TASK_ID`) REFERENCES `tbl_deploy_task` (`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_cm.tbl_deploy_taskdevice 的数据：~0 rows (大约)
DELETE FROM `tbl_deploy_taskdevice`;
/*!40000 ALTER TABLE `tbl_deploy_taskdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_deploy_taskdevice` ENABLE KEYS */;


-- 导出  表 tnt_cm.tbl_deploy_task_excutedetail 结构
DROP TABLE IF EXISTS `tbl_deploy_task_excutedetail`;
CREATE TABLE IF NOT EXISTS `tbl_deploy_task_excutedetail` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TASK_ID` int(10) unsigned NOT NULL,
  `DEVICE_ID` int(10) unsigned NOT NULL,
  `DEPLOY_RESULT` varchar(64) NOT NULL,
  `ERRORCODE` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_cm.tbl_deploy_task_excutedetail 的数据：~0 rows (大约)
DELETE FROM `tbl_deploy_task_excutedetail`;
/*!40000 ALTER TABLE `tbl_deploy_task_excutedetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_deploy_task_excutedetail` ENABLE KEYS */;


-- 导出 tnt_fm 的数据库结构
DROP DATABASE IF EXISTS `tnt_fm`;
CREATE DATABASE IF NOT EXISTS `tnt_fm` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tnt_fm`;


-- 导出  表 tnt_fm.fig_alarm 结构
DROP TABLE IF EXISTS `fig_alarm`;
CREATE TABLE IF NOT EXISTS `fig_alarm` (
  `figure_id` int(11) NOT NULL AUTO_INCREMENT,
  `fault_category` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`figure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.fig_alarm 的数据：~0 rows (大约)
DELETE FROM `fig_alarm`;
/*!40000 ALTER TABLE `fig_alarm` DISABLE KEYS */;
/*!40000 ALTER TABLE `fig_alarm` ENABLE KEYS */;


-- 导出  表 tnt_fm.fig_dev 结构
DROP TABLE IF EXISTS `fig_dev`;
CREATE TABLE IF NOT EXISTS `fig_dev` (
  `figure_id` int(11) NOT NULL AUTO_INCREMENT,
  `dev_type_id` int(11) DEFAULT NULL,
  `dev_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`figure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.fig_dev 的数据：~0 rows (大约)
DELETE FROM `fig_dev`;
/*!40000 ALTER TABLE `fig_dev` DISABLE KEYS */;
/*!40000 ALTER TABLE `fig_dev` ENABLE KEYS */;


-- 导出  表 tnt_fm.fig_rule 结构
DROP TABLE IF EXISTS `fig_rule`;
CREATE TABLE IF NOT EXISTS `fig_rule` (
  `figure_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `desc` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`figure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.fig_rule 的数据：~0 rows (大约)
DELETE FROM `fig_rule`;
/*!40000 ALTER TABLE `fig_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `fig_rule` ENABLE KEYS */;


-- 导出  表 tnt_fm.query_condition_dev 结构
DROP TABLE IF EXISTS `query_condition_dev`;
CREATE TABLE IF NOT EXISTS `query_condition_dev` (
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  `option_id` int(11) DEFAULT NULL,
  `dev_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.query_condition_dev 的数据：~0 rows (大约)
DELETE FROM `query_condition_dev`;
/*!40000 ALTER TABLE `query_condition_dev` DISABLE KEYS */;
/*!40000 ALTER TABLE `query_condition_dev` ENABLE KEYS */;


-- 导出  表 tnt_fm.query_condition_dev_type 结构
DROP TABLE IF EXISTS `query_condition_dev_type`;
CREATE TABLE IF NOT EXISTS `query_condition_dev_type` (
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  `option_id` int(11) DEFAULT NULL,
  `dev_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.query_condition_dev_type 的数据：~0 rows (大约)
DELETE FROM `query_condition_dev_type`;
/*!40000 ALTER TABLE `query_condition_dev_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `query_condition_dev_type` ENABLE KEYS */;


-- 导出  表 tnt_fm.query_option 结构
DROP TABLE IF EXISTS `query_option`;
CREATE TABLE IF NOT EXISTS `query_option` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `system_flag` tinyint(4) DEFAULT NULL,
  `alarm_days` int(11) DEFAULT NULL,
  `begin_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `acked` int(11) DEFAULT '0',
  `cleared` int(11) DEFAULT '0',
  `fault_category_list` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.query_option 的数据：~0 rows (大约)
DELETE FROM `query_option`;
/*!40000 ALTER TABLE `query_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `query_option` ENABLE KEYS */;


-- 导出  表 tnt_fm.rn_dev 结构
DROP TABLE IF EXISTS `rn_dev`;
CREATE TABLE IF NOT EXISTS `rn_dev` (
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_tbl_id` int(11) DEFAULT NULL,
  `dev_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.rn_dev 的数据：~4 rows (大约)
DELETE FROM `rn_dev`;
/*!40000 ALTER TABLE `rn_dev` DISABLE KEYS */;
INSERT INTO `rn_dev` (`tbl_id`, `type_tbl_id`, `dev_id`) VALUES
	(53, 53, '13'),
	(54, 54, '12'),
	(56, 56, '12'),
	(57, 57, '12');
/*!40000 ALTER TABLE `rn_dev` ENABLE KEYS */;


-- 导出  表 tnt_fm.rn_dev_alarm 结构
DROP TABLE IF EXISTS `rn_dev_alarm`;
CREATE TABLE IF NOT EXISTS `rn_dev_alarm` (
  `type_tbl_id` int(11) DEFAULT NULL,
  `alarm_sn` bigint(20) DEFAULT NULL,
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.rn_dev_alarm 的数据：~7 rows (大约)
DELETE FROM `rn_dev_alarm`;
/*!40000 ALTER TABLE `rn_dev_alarm` DISABLE KEYS */;
INSERT INTO `rn_dev_alarm` (`type_tbl_id`, `alarm_sn`, `tbl_id`) VALUES
	(53, 30001, 111),
	(53, 30002, 112),
	(54, 10001, 113),
	(54, 40004, 114),
	(56, 10003, 116),
	(57, 10001, 117),
	(57, 40004, 118);
/*!40000 ALTER TABLE `rn_dev_alarm` ENABLE KEYS */;


-- 导出  表 tnt_fm.rn_dev_type 结构
DROP TABLE IF EXISTS `rn_dev_type`;
CREATE TABLE IF NOT EXISTS `rn_dev_type` (
  `option_id` int(11) DEFAULT NULL,
  `dev_type_id` int(11) DEFAULT NULL,
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.rn_dev_type 的数据：~4 rows (大约)
DELETE FROM `rn_dev_type`;
/*!40000 ALTER TABLE `rn_dev_type` DISABLE KEYS */;
INSERT INTO `rn_dev_type` (`option_id`, `dev_type_id`, `tbl_id`) VALUES
	(15, 1, 53),
	(15, 4, 54),
	(16, 4, 56),
	(17, 4, 57);
/*!40000 ALTER TABLE `rn_dev_type` ENABLE KEYS */;


-- 导出  表 tnt_fm.rn_group 结构
DROP TABLE IF EXISTS `rn_group`;
CREATE TABLE IF NOT EXISTS `rn_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `desc_info` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.rn_group 的数据：~3 rows (大约)
DELETE FROM `rn_group`;
/*!40000 ALTER TABLE `rn_group` DISABLE KEYS */;
INSERT INTO `rn_group` (`group_id`, `name`, `desc_info`) VALUES
	(24, 'a', 'a'),
	(25, 'test', 'test'),
	(26, '管理组', '这是管理组');
/*!40000 ALTER TABLE `rn_group` ENABLE KEYS */;


-- 导出  表 tnt_fm.rn_option_rule 结构
DROP TABLE IF EXISTS `rn_option_rule`;
CREATE TABLE IF NOT EXISTS `rn_option_rule` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `enable` tinyint(4) DEFAULT '0',
  `severitytotal` int(11) DEFAULT '0',
  `sendcleared` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.rn_option_rule 的数据：~3 rows (大约)
DELETE FROM `rn_option_rule`;
/*!40000 ALTER TABLE `rn_option_rule` DISABLE KEYS */;
INSERT INTO `rn_option_rule` (`option_id`, `name`, `enable`, `severitytotal`, `sendcleared`) VALUES
	(15, 'a', 1, 1, 0),
	(16, 'r1', 1, 1, 0),
	(17, '2', 1, 0, 0);
/*!40000 ALTER TABLE `rn_option_rule` ENABLE KEYS */;


-- 导出  表 tnt_fm.rn_rule_group 结构
DROP TABLE IF EXISTS `rn_rule_group`;
CREATE TABLE IF NOT EXISTS `rn_rule_group` (
  `option_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`option_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.rn_rule_group 的数据：~3 rows (大约)
DELETE FROM `rn_rule_group`;
/*!40000 ALTER TABLE `rn_rule_group` DISABLE KEYS */;
INSERT INTO `rn_rule_group` (`option_id`, `group_id`) VALUES
	(15, 24),
	(16, 25),
	(17, 24),
	(17, 25);
/*!40000 ALTER TABLE `rn_rule_group` ENABLE KEYS */;


-- 导出  表 tnt_fm.rn_user 结构
DROP TABLE IF EXISTS `rn_user`;
CREATE TABLE IF NOT EXISTS `rn_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `desc_info` varchar(128) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.rn_user 的数据：~4 rows (大约)
DELETE FROM `rn_user`;
/*!40000 ALTER TABLE `rn_user` DISABLE KEYS */;
INSERT INTO `rn_user` (`user_id`, `name`, `desc_info`, `phone`, `email`, `group_id`) VALUES
	(68, 'a', '', 'a', 'a', 24),
	(69, 'shixian', 'dd', '11111111111', 'wushixian@tp-link.net', 25),
	(70, 'yinweitao', '', '', 'yinweitao@tp-link.net', 25),
	(71, 'gaoyuxin', 'ga', '123456', 'gao@t.com', 25);
/*!40000 ALTER TABLE `rn_user` ENABLE KEYS */;


-- 导出  表 tnt_fm.server_smtp 结构
DROP TABLE IF EXISTS `server_smtp`;
CREATE TABLE IF NOT EXISTS `server_smtp` (
  `tbl_id` int(11) NOT NULL,
  `smtp_server` varchar(45) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `sender` varchar(128) DEFAULT NULL,
  `username` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `auth_enable` tinyint(1) DEFAULT NULL,
  `ssl_enable` tinyint(1) DEFAULT NULL,
  `checked` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.server_smtp 的数据：~1 rows (大约)
DELETE FROM `server_smtp`;
/*!40000 ALTER TABLE `server_smtp` DISABLE KEYS */;
INSERT INTO `server_smtp` (`tbl_id`, `smtp_server`, `port`, `sender`, `username`, `password`, `auth_enable`, `ssl_enable`, `checked`) VALUES
	(1, 'smtp.tp-link.net', 25, 'wushixian@tp-link.net', 'wushixian@tp-link.net', '3233', 1, 0, 0);
/*!40000 ALTER TABLE `server_smtp` ENABLE KEYS */;


-- 导出  表 tnt_fm.shield_alarm 结构
DROP TABLE IF EXISTS `shield_alarm`;
CREATE TABLE IF NOT EXISTS `shield_alarm` (
  `alarm_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `alarm_sn` bigint(20) NOT NULL,
  `count` int(11) DEFAULT NULL,
  `dev_id` int(11) NOT NULL,
  `dev_type_id` int(11) NOT NULL,
  `dev_ip` varchar(128) NOT NULL DEFAULT '255.255.255.255',
  `dev_name` varchar(128) DEFAULT NULL,
  `fault_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_arrived_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `acked_user` varchar(128) DEFAULT NULL,
  `acked_time` timestamp NULL DEFAULT NULL,
  `paras` varchar(3072) DEFAULT NULL,
  `cleared_user` varchar(128) DEFAULT NULL,
  `cleared_time` timestamp NULL DEFAULT NULL,
  `status` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`alarm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.shield_alarm 的数据：~0 rows (大约)
DELETE FROM `shield_alarm`;
/*!40000 ALTER TABLE `shield_alarm` DISABLE KEYS */;
/*!40000 ALTER TABLE `shield_alarm` ENABLE KEYS */;


-- 导出  表 tnt_fm.shield_alarm_time 结构
DROP TABLE IF EXISTS `shield_alarm_time`;
CREATE TABLE IF NOT EXISTS `shield_alarm_time` (
  `shield_id` int(11) DEFAULT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.shield_alarm_time 的数据：~2 rows (大约)
DELETE FROM `shield_alarm_time`;
/*!40000 ALTER TABLE `shield_alarm_time` DISABLE KEYS */;
INSERT INTO `shield_alarm_time` (`shield_id`, `start_time`, `end_time`, `tbl_id`) VALUES
	(3, '16:17:40', '16:17:40', 3),
	(4, '17:09:02', '17:09:02', 4);
/*!40000 ALTER TABLE `shield_alarm_time` ENABLE KEYS */;


-- 导出  表 tnt_fm.shield_dev 结构
DROP TABLE IF EXISTS `shield_dev`;
CREATE TABLE IF NOT EXISTS `shield_dev` (
  `shield_id` int(11) DEFAULT NULL,
  `dev_type_id` int(11) DEFAULT NULL,
  `dev_id` int(11) DEFAULT NULL,
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.shield_dev 的数据：~2 rows (大约)
DELETE FROM `shield_dev`;
/*!40000 ALTER TABLE `shield_dev` DISABLE KEYS */;
INSERT INTO `shield_dev` (`shield_id`, `dev_type_id`, `dev_id`, `tbl_id`) VALUES
	(4, 0, 1, 7),
	(4, 0, 2, 8);
/*!40000 ALTER TABLE `shield_dev` ENABLE KEYS */;


-- 导出  表 tnt_fm.shield_dev_alarm 结构
DROP TABLE IF EXISTS `shield_dev_alarm`;
CREATE TABLE IF NOT EXISTS `shield_dev_alarm` (
  `alarm_sn` bigint(20) NOT NULL,
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  `dev_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.shield_dev_alarm 的数据：~2 rows (大约)
DELETE FROM `shield_dev_alarm`;
/*!40000 ALTER TABLE `shield_dev_alarm` DISABLE KEYS */;
INSERT INTO `shield_dev_alarm` (`alarm_sn`, `tbl_id`, `dev_id`) VALUES
	(10001, 7, 8),
	(10002, 8, 8);
/*!40000 ALTER TABLE `shield_dev_alarm` ENABLE KEYS */;


-- 导出  表 tnt_fm.shield_rule 结构
DROP TABLE IF EXISTS `shield_rule`;
CREATE TABLE IF NOT EXISTS `shield_rule` (
  `shield_id` int(11) NOT NULL AUTO_INCREMENT,
  `shield_name` varchar(128) NOT NULL,
  `enable` tinyint(4) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `severitytotal` int(11) DEFAULT NULL,
  PRIMARY KEY (`shield_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.shield_rule 的数据：~1 rows (大约)
DELETE FROM `shield_rule`;
/*!40000 ALTER TABLE `shield_rule` DISABLE KEYS */;
INSERT INTO `shield_rule` (`shield_id`, `shield_name`, `enable`, `start_date`, `end_date`, `severitytotal`) VALUES
	(4, 'test', 1, '2014-04-09', '2014-04-09', 1111);
/*!40000 ALTER TABLE `shield_rule` ENABLE KEYS */;


-- 导出  表 tnt_fm.tnt_alarm_category 结构
DROP TABLE IF EXISTS `tnt_alarm_category`;
CREATE TABLE IF NOT EXISTS `tnt_alarm_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.tnt_alarm_category 的数据：~8 rows (大约)
DELETE FROM `tnt_alarm_category`;
/*!40000 ALTER TABLE `tnt_alarm_category` DISABLE KEYS */;
INSERT INTO `tnt_alarm_category` (`category_id`, `category_name`) VALUES
	(0, 'other'),
	(1, 'scurity'),
	(2, 'monitor'),
	(3, 'configure'),
	(4, 'device'),
	(5, 'temp5'),
	(6, 'temp6'),
	(7, 'temp7');
/*!40000 ALTER TABLE `tnt_alarm_category` ENABLE KEYS */;


-- 导出  表 tnt_fm.tnt_alarm_conf 结构
DROP TABLE IF EXISTS `tnt_alarm_conf`;
CREATE TABLE IF NOT EXISTS `tnt_alarm_conf` (
  `alarm_sn` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `fault_name` varchar(128) NOT NULL,
  `fault_type` tinyint(4) NOT NULL,
  `severity` tinyint(4) NOT NULL,
  `fault_category` smallint(6) NOT NULL,
  `desc_info` varchar(1024) DEFAULT NULL,
  `suggestion` varchar(1024) DEFAULT NULL,
  `comment` varchar(1024) DEFAULT NULL,
  `reason` text,
  `trap_oid` varchar(128) DEFAULT NULL,
  `enterprise_id` varchar(128) DEFAULT NULL,
  `generic_id` smallint(6) DEFAULT NULL,
  `specific_id` int(11) DEFAULT NULL,
  `create_user` varchar(128) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_user` varchar(128) DEFAULT NULL,
  `update_time` timestamp NULL DEFAULT NULL,
  `threshold_type` int(11) DEFAULT '0',
  `threshold` varchar(128) DEFAULT '0',
  `calculate_type` int(11) DEFAULT '0',
  `calculate_num` int(11) DEFAULT '0',
  `indicator_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`alarm_sn`),
  UNIQUE KEY `serial_num_UNIQUE` (`alarm_sn`)
) ENGINE=InnoDB AUTO_INCREMENT=40012 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.tnt_alarm_conf 的数据：~127 rows (大约)
DELETE FROM `tnt_alarm_conf`;
/*!40000 ALTER TABLE `tnt_alarm_conf` DISABLE KEYS */;
INSERT INTO `tnt_alarm_conf` (`alarm_sn`, `group_id`, `enable`, `fault_name`, `fault_type`, `severity`, `fault_category`, `desc_info`, `suggestion`, `comment`, `reason`, `trap_oid`, `enterprise_id`, `generic_id`, `specific_id`, `create_user`, `create_time`, `update_user`, `update_time`, `threshold_type`, `threshold`, `calculate_type`, `calculate_num`, `indicator_id`) VALUES
	(10001, 10000, 1, 'coldStart', 3, 4, 2, 'Sent when cold start', '我饿的方式礼服案例警方萨芬奥飞案例啊啊\n路上风景啊啊阿里警方说法 \n 时间飞 上飞机啦发得分就是奥利弗啊历史的警方说奥飞案件多发阿军方萨芬啊发了 士大夫法拉了双方案件发动机范围飞撒老夫老 是减肥啦方式拉附近的风景了萨芬爱上了减肥啦了房间里萨附近的了房间啊就拉啊 登陆 上了飞机按了发送的发了封的看法奥飞的萨芬的发放的阿道夫爱的发撒', '444', '4445555', '1.3.6.1.6.3.1.1.5.1', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', '', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(10002, 10000, 1, 'warmStart', 3, 4, 3, 'Sent when warm start', NULL, NULL, NULL, '1.3.6.1.6.3.1.1.5.2', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(10003, 10000, 1, 'linkDown', 3, 1, 3, 'Sent when link is down', NULL, 'test', NULL, '1.3.6.1.6.3.1.1.5.3', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(10004, 10000, 1, 'linkUp', 3, 4, 3, 'Sent when link is up', 'no need action', 'no need to deal 是否 df ', 'link up', '1.3.6.1.6.3.1.1.5.4', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(10005, 10000, 1, 'authenticationFailure', 3, 3, 3, 'System detects the device credential is wrong', NULL, NULL, NULL, '1.3.6.1.6.3.1.1.5.5', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20001, 20000, 1, 'ipAddrChange', 3, 3, 3, 'Sent when IP of switch changed', '', '', '', '1.3.6.1.4.1.11863.1.1.*.1.1.2.6.1', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20002, 20000, 1, 'macTableFull', 3, 2, 3, 'Sent when mac table full', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.2.3.4.4|1.3.6.1.4.1.11863.6.10.2.4', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20003, 20000, 1, 'flashModify', 3, 4, 3, 'Sent when flash modify', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.1.5|1.3.6.1.4.1.11863.6.3.2.1', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20004, 20000, 1, 'highCpuLoadExceed', 3, 2, 3, 'Device CPU utilization is over 80%', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.14.12.1|1.3.6.1.4.1.11863.6.4.2.1', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20005, 20000, 1, 'lldpRemTablesChange', 3, 4, 3, 'Open the switch LLDP function, when neighbor statistic information of port occurs', NULL, NULL, NULL, '1.0.8802.1.1.2.0.0.1|1.3.6.1.4.1.11863.6.35.2.1 ', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20006, 20000, 1, 'fdbDynMacNew', 3, 4, 3, 'Learn a new dynamic MAC address', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.2.3.4.1|1.3.6.1.4.1.11863.6.10.2.1', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20007, 20000, 1, 'fdbStaticMacNew', 3, 4, 3, 'Learn a new static MAC address', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.2.3.4.2|1.3.6.1.4.1.11863.6.10.2.2', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20008, 20000, 1, 'fdbFilterMacNew', 3, 4, 3, 'Learn a new filter MAC address', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.2.3.4.3|1.3.6.1.4.1.11863.6.10.2.3', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20009, 20000, 1, 'macLearnModeChange', 3, 4, 3, 'Learn mode changed', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.2.3.4.6|1.3.6.1.4.1.11863.6.10.2.6', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20010, 20000, 1, 'macMaxLearnedNumExceed', 3, 3, 3, 'The number of MAC address port learning reaches maximum allowable value', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.2.3.4.5|1.3.6.1.4.1.11863.6.10.2.5', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20011, 20000, 1, 'mstpTopologyChange', 3, 4, 3, 'Topology of mstp changed', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.4.5.1|1.3.6.1.4.1.11863.6.21.2.1', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20012, 20000, 1, 'vlanCreate', 3, 4, 3, 'Vlan created', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.3.1.2.1|1.3.6.1.4.1.11863.6.14.2.1', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(20013, 20000, 1, 'vlanDelete', 3, 3, 3, 'Vlan deleted', NULL, NULL, NULL, '1.3.6.1.4.1.11863.1.1.*.3.1.2.1|1.3.6.1.4.1.11863.6.14.2.1', NULL, NULL, NULL, 'system', '2014-05-15 14:05:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(30001, 30000, 1, 'agentInventoryCardMismatch', 3, 3, 0, 'Sent when a card is inserted which is a different type than what the slot was configured for.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.13.0.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30002, 30000, 1, 'agentInventoryCardUnsupported', 3, 3, 0, 'Sent when a card is inserted which is of a type that is not supported by the slot.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.13.0.2', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30003, 30000, 1, 'agentInventoryStackPortLinkUp', 3, 4, 0, 'Sent when a Stack Port is connected to annother Stack Member.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.13.0.3', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30004, 30000, 1, 'agentInventoryStackPortLinkDown', 3, 2, 0, 'Sent when a Stack Port is disconnected from annother Stack Member.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.13.0.4', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30005, 30000, 1, 'agentPortSecurityViolation', 3, 4, 0, 'Sent when a packet is received on a locked port with a source MAC address that is not allowed.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.20.2.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30006, 30000, 1, 'aclTrapRuleLogEvent', 3, 4, 2, 'This trap is generated on a periodic basis to indicate that an ACL rule configured for logging was actively used by hardware to take action on one or more packets.  The aclTrapRuleHitCount denotes the number of times this rule was hit during the most rec...', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.3.2.0.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30007, 30000, 1, 'multipleUsersTrap', 3, 4, 2, 'This trap is sent when more than one user is logged in with administrative access.  Only applies to CLI interface.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30008, 30000, 1, 'broadcastStormStartTrap', 3, 4, 2, 'This trap is sent when a broadcast storm is detected.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.2', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30009, 30000, 1, 'broadcastStormEndTrap', 3, 4, 2, 'This trap is sent when a broadcast storm is no longer detected.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.3', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30010, 30000, 1, 'linkFailureTrap', 3, 2, 2, 'Sent when link failure detected', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.4', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30011, 30000, 1, 'vlanRequestFailureTrap', 3, 3, 2, 'Sent when VLAN request failur detected', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.5', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30012, 30000, 1, 'vlanDeleteLastTrap', 3, 4, 2, 'Trap is sent when attempting to delete the last configured VLAN or the Default VLAN', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.6', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30013, 30000, 1, 'vlanDefaultCfgFailureTrap', 3, 2, 2, 'Trap is sent if there are failures in resetting VLAN configuration to defaults.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.7', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30014, 30000, 1, 'vlanRestoreFailureTrap', 3, 2, 2, 'Sent when VLAN restore failur detected', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.8', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30015, 30000, 1, 'fanFailureTrap', 3, 2, 2, 'Sent when fan failure detected', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.9', NULL, NULL, NULL, 'system', '2013-02-21 11:34:37', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30016, 30000, 1, 'stpInstanceNewRootTrap', 3, 4, 5, 'Trap is sent when this machine is a new STP Root when there is more than one STP instance.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.10', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30017, 30000, 1, 'stpInstanceTopologyChangeTrap', 3, 4, 2, 'Trap is sent when there is a STP topology change when there is more than one STP instance.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.11', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30018, 30000, 1, 'powerSupplyStatusChangeTrap', 3, 4, 5, 'Sent when power supply status is changed.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.12', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30019, 30000, 1, 'failedUserLoginTrap', 3, 3, 2, 'Trap is sent when a user fails to authenticate via the CLI or Web interfaces.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.13', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30020, 30000, 1, 'userLockoutTrap', 3, 3, 2, 'Trap is sent when a user account is locked due to consecutive failed login attempts via the CLI or Web interfaces beyond the allowed limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.14', NULL, NULL, NULL, 'system', '2014-03-19 14:46:41', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30021, 30000, 1, 'topologyChangeInitiatedTrap', 3, 4, 2, 'Sent when topology change initiated', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.15', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30022, 30000, 1, 'loopDetectedTrap', 3, 2, 2, 'Sent when loop detected', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.16', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30023, 30000, 1, 'pciExcepSetTrap', 3, 3, 5, 'trapMgrpciExceptionrBitSetTrap', NULL, NULL, NULL, '1.3.6.1.4.1.4526.11.1.0.17', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30024, 30000, 1, 'boxsFanStateChange', 3, 4, 2, 'Trap is sent when fan state change happens.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.43.0.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30025, 30000, 1, 'boxsPowSupplyStateChange', 3, 4, 2, 'Trap is sent when power supply state change happens.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.43.0.2', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30026, 30000, 1, 'boxsTemperatureChange', 3, 4, 2, 'Trap is sent when temperature is changing and crossing any of the thresholds', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.43.0.3', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30027, 30000, 1, 'cpClientAuthenticationFailure', 3, 3, 2, 'A cpClientAuthenticationFailure trap signifies that the SNMP entity, acting in an agent role, has detected a client authentication failure.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.38.4.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30028, 30000, 1, 'cpClientConnect', 3, 4, 2, 'A cpClientConnect trap signifies that the SNMP entity, acting in an agent role, has detected a client connection.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.38.4.2', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30029, 30000, 1, 'cpClientDatabaseFull', 3, 4, 2, 'A cpClientDatabaseFull trap signifies that the SNMP entity, acting in an agent role, has detected that client authentication database is full.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.38.4.3', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30030, 30000, 1, 'cpClientDisconnect', 3, 4, 2, 'A cpClientDisconnect trap signifies that the SNMP entity, acting in an agent role, has detected a client disconnection.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.38.4.4', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30031, 30000, 1, 'agentInventoryCardMismatch', 3, 3, 2, 'Sent when a card is inserted which is a different type than what the slot was configured for.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.13.0.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30032, 30000, 1, 'agentInventoryCardUnsupported', 3, 3, 2, 'Sent when a card is inserted which is of a type that is not supported by the slot.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.13.0.2', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30033, 30000, 1, 'agentInventoryStackPortLinkUp', 3, 4, 5, 'Sent when a Stack Port is connected to annother Stack Member.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.13.0.3', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30034, 30000, 1, 'agentInventoryStackPortLinkDown', 3, 2, 5, 'Sent when a Stack Port is disconnected from annother Stack Member.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.13.0.4', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30035, 30000, 1, 'agentPortSecurityViolation', 3, 4, 5, 'Sent when a packet is received on a locked port with a source MAC address that is not allowed.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.20.2.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30036, 30000, 1, 'aclTrapRuleLogEvent', 3, 4, 5, 'This trap is generated on a periodic basis to indicate that an ACL rule configured for logging was actively used by hardware to take action on one or more packets.  The aclTrapRuleHitCount denotes the number of times this rule was hit during the most rec...', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.3.2.0.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30037, 30000, 1, 'multipleUsersTrap', 3, 4, 5, 'This trap is sent when more than one user is logged in with administrative access.  Only applies to CLI interface.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30038, 30000, 1, 'broadcastStormStartTrap', 3, 4, 2, 'This trap is sent when a broadcast storm is detected.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.2', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30039, 30000, 1, 'broadcastStormEndTrap', 3, 4, 2, 'This trap is sent when a broadcast storm is no longer detected.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.3', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30040, 30000, 1, 'linkFailureTrap', 3, 2, 2, 'Sent when link failure detected', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.4', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30041, 30000, 1, 'vlanRequestFailureTrap', 3, 3, 2, 'Sent when VLAN request failur detected', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.5', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30042, 30000, 1, 'vlanDeleteLastTrap', 3, 4, 5, 'Trap is sent when attempting to delete the last configured VLAN or the Default VLAN', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.6', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30043, 30000, 1, 'vlanDefaultCfgFailureTrap', 3, 2, 5, 'Trap is sent if there are failures in resetting VLAN configuration to defaults.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.7', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30044, 30000, 1, 'vlanRestoreFailureTrap', 3, 2, 5, 'Sent when VLAN restore failur detected', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.8', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30045, 30000, 1, 'fanFailureTrap', 3, 2, 5, 'Sent when fan failure detected', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.9', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30046, 30000, 1, 'stpInstanceNewRootTrap', 3, 4, 5, 'Trap is sent when this machine is a new STP Root when there is more than one STP instance.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.10', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30047, 30000, 1, 'stpInstanceTopologyChangeTrap', 3, 4, 5, 'Trap is sent when there is a STP topology change when there is more than one STP instance.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.11', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30048, 30000, 1, 'powerSupplyStatusChangeTrap', 3, 4, 1, 'Sent when power supply status is changed.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.12', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30049, 30000, 1, 'failedUserLoginTrap', 3, 3, 1, 'Trap is sent when a user fails to authenticate via the CLI or Web interfaces.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.13', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30050, 30000, 1, 'userLockoutTrap', 3, 2, 1, 'Trap is sent when a user account is locked due to consecutive failed login attempts via the CLI or Web interfaces beyond the allowed limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.14', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30051, 30000, 1, 'daiIntfErrorDisabledTrap', 3, 1, 3, 'Trap is sent once an interface is error disabled by DAI when the incoming packet rate exceeded configured rate limit during a burst-interval.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.15', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30052, 30000, 1, 'stpInstanceLoopInconsistentStartTrap', 3, 4, 1, 'Trap is sent when this port in this STP instance enters loop inconsistent state upon failure to receive a BPDU.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.16', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30053, 30000, 1, 'stpInstanceLoopInconsistentEndTrap', 3, 4, 1, 'Trap is sent when this port in this STP instance exits loop inconsistent state upon reception of a BPDU.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.17', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30054, 30000, 1, 'dhcpSnoopingIntfErrorDisabledTrap', 3, 3, 1, 'Trap is sent once an interface is error disabled by DHCP Snooping when the incoming packet rate exceeded configured rate limit during a burst-interval.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.18', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30055, 30000, 1, 'noStartupConfigTrap', 3, 1, 1, 'Trap is sent when startup-config file exists and SSH is enabled.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.10.1.0.19', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30056, 30000, 1, 'Node is down', 1, 1, 1, 'The node status is down.', NULL, NULL, NULL, 'node_down', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30057, 30000, 1, 'Trap service is down', 1, 1, 1, 'NMS Server failed to start trap receiver.', NULL, NULL, NULL, 'trap_service', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30058, 30000, 1, 'Syslog service is down', 1, 1, 1, 'NMS Server failed to start syslog receiver.', NULL, NULL, NULL, 'syslog_service', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30059, 30000, 1, 'FTP service is down', 1, 1, 1, 'NMS Server failed to start FTP .', NULL, NULL, NULL, 'ftp_service', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30060, 30000, 1, 'TFTP service is down', 1, 1, 1, 'NMS Server failed to start TFTP.', NULL, NULL, NULL, 'tftp_service', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30061, 30000, 1, 'PM collection service error', 1, 1, 1, 'NMS Server monitor polling service is abnormal.', NULL, NULL, NULL, 'pm_collection_service', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30062, 30000, 1, 'Device CPU utilization is over 90%', 2, 1, 0, 'Device CPU utilization is over 90%', NULL, NULL, NULL, 'device_cpu.cpu_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '90', 1, 3, NULL),
	(30063, 30000, 1, 'Device CPU utilization is over 80%', 2, 2, 0, 'Device CPU utilization is over 80%', NULL, NULL, NULL, 'device_cpu.cpu_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '80', 1, 3, NULL),
	(30064, 30000, 1, 'Device Memory utilization is over 95%', 2, 2, 0, 'Device Memory utilization is over 95%', NULL, NULL, NULL, 'device_memory.memory_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '95', 1, 3, NULL),
	(30065, 30000, 1, 'Device Memory utilization is over 90%', 2, 3, 0, 'Device Memory utilization is over 90%', NULL, NULL, NULL, 'device_memory.memory_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '90', 1, 3, NULL),
	(30066, 30000, 1, 'NMS CPU utilization is over 90%', 2, 1, 0, 'NMS CPU utilization is over 90%', NULL, NULL, NULL, 'nms_system_monitor.cpu_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '90', 1, 3, NULL),
	(30067, 30000, 1, 'NMS Memory utilization is over 90%', 2, 1, 0, 'NMS Memory utilization is over 90%', NULL, NULL, NULL, 'nms_system_monitor.memory_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '90', 1, 3, NULL),
	(30068, 30000, 1, 'NMS Disk utilization is over 90%', 2, 1, 0, 'NMS Disk utilization is over 90%', NULL, NULL, NULL, 'nms_system_monitor.disk_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '90', 1, 1, NULL),
	(30069, 30000, 1, 'NMS JVM Memory utilization is over 90%', 2, 1, 0, 'NMS JVM Memory utilization is over 90%', NULL, NULL, NULL, 'nms_system_monitor.jvm_memory_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '90', 1, 3, NULL),
	(30070, 30000, 1, 'NMS CPU utilization is over 80%', 2, 2, 0, 'NMS CPU utilization is over 80%', NULL, NULL, NULL, 'nms_system_monitor.cpu_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '80', 1, 3, NULL),
	(30071, 30000, 1, 'NMS Memory utilization is over 80%', 2, 2, 0, 'NMS Memory utilization is over 80%', NULL, NULL, NULL, 'nms_system_monitor.memory_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '80', 1, 3, NULL),
	(30072, 30000, 1, 'NMS Disk utilization is over 80%', 2, 2, 0, 'NMS Disk utilization is over 80%', NULL, NULL, NULL, 'nms_system_monitor.disk_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '80', 1, 1, NULL),
	(30073, 30000, 1, 'NMS JVM Memory utilization is over 80%', 2, 2, 0, 'NMS JVM Memory utilization is over 80%', NULL, NULL, NULL, 'nms_system_monitor.jvm_memory_used', NULL, NULL, NULL, 'system', '2014-03-19 14:46:42', 'null', '2000-01-01 00:00:00', 1, '80', 1, 3, NULL),
	(30074, 30000, 1, 'Rogue AP detect', 3, 3, 0, 'This trap shall notify detection of an unknown AP.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.4.17.1.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30075, 30000, 1, 'Max station limitation reached', 3, 2, 0, 'This trap shall notify reaching the max station limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.4.17.2.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30076, 30000, 1, 'Station denied', 3, 4, 0, 'This trap shall notify the denial of a station.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.4.17.3.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30077, 30000, 1, 'No outgoing beacons', 3, 2, 0, 'This trap shall notify no outgoing beacons.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.4.17.4.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30078, 30000, 1, 'Rogue AP detect', 3, 3, 0, 'This trap shall notify detection of an unknown AP.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.8.17.1.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30079, 30000, 1, 'Max station limitation reached', 3, 2, 0, 'This trap shall notify reaching the max station limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.8.17.2.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30080, 30000, 1, 'Station denied', 3, 4, 0, 'This trap shall notify the denial of a station.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.8.17.3.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30081, 30000, 1, 'No outgoing beacons', 3, 2, 0, 'This trap shall notify no outgoing beacons.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.4.17.8.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30082, 30000, 1, 'Rogue AP detect', 3, 3, 0, 'This trap shall notify detection of an unknown AP.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.12.17.1.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30083, 30000, 1, 'Max station limitation reached', 3, 2, 0, 'This trap shall notify reaching the max station limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.12.17.2.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30084, 30000, 1, 'Station denied', 3, 4, 0, 'This trap shall notify the denial of a station.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.12.17.3.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30085, 30000, 1, 'No outgoing beacons', 3, 2, 0, 'This trap shall notify no outgoing beacons.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.4.17.12.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30086, 30000, 1, 'Rogue AP detect', 3, 3, 0, 'This trap shall notify detection of an unknown AP.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.13.17.1.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30087, 30000, 1, 'Max station limitation reached', 3, 2, 0, 'This trap shall notify reaching the max station limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.13.17.2.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30088, 30000, 1, 'Station denied', 3, 4, 0, 'This trap shall notify the denial of a station.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.13.17.3.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30089, 30000, 1, 'No outgoing beacons', 3, 2, 0, 'This trap shall notify no outgoing beacons.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.13.17.4.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30090, 30000, 1, 'Rogue AP detect', 3, 3, 0, 'This trap shall notify detection of an unknown AP.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.5.18.1.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30091, 30000, 1, 'Max station limitation reached', 3, 2, 0, 'This trap shall notify reaching the max station limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.5.18.2.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30092, 30000, 1, 'Station denied', 3, 4, 0, 'This trap shall notify the denial of a station.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.5.18.3.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30093, 30000, 1, 'No outgoing beacons', 3, 2, 0, 'This trap shall notify no outgoing beacons.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.5.18.4.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30094, 30000, 1, 'Rogue AP detect', 3, 3, 0, 'This trap shall notify detection of an unknown AP.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.10.17.1.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30095, 30000, 1, 'Max station limitation reached', 3, 2, 0, 'This trap shall notify reaching the max station limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.10.17.2.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30096, 30000, 1, 'Station denied', 3, 4, 0, 'This trap shall notify the denial of a station.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.10.17.3.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30097, 30000, 1, 'No outgoing beacons', 3, 2, 0, 'This trap shall notify no outgoing beacons.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.10.17.4.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30098, 30000, 1, 'Vlan access control mechanism failure', 3, 1, 0, 'This trap shall notify the failure of vlan access control mechanism.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.10.17.5.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30099, 30000, 1, 'Vlan access control assignment failure', 3, 1, 0, 'This trap shall notify the failure of vlan access control assignment.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.10.17.6.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30100, 30000, 1, 'Max vlan configuration limitation reached', 3, 3, 0, 'This trap shall notify reaching the max vlan configuration limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.10.17.7.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30101, 30000, 1, 'Rogue AP detect', 3, 3, 0, 'This trap shall notify detection of an unknown AP.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.9.17.1.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30102, 30000, 1, 'Max station limitation reached', 3, 2, 0, 'This trap shall notify reaching the max station limit.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.9.17.2.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30103, 30000, 1, 'Station denied', 3, 4, 0, 'This trap shall notify the denial of a station.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.9.17.3.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30104, 30000, 1, 'No outgoing beacons', 3, 2, 0, 'This trap shall notify no outgoing beacons.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.9.17.4.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(30105, 30000, 1, 'Vlan access control mechanism failure', 3, 1, 0, 'This trap shall notify the failure of vlan access control mechanism.', NULL, NULL, NULL, '1.3.6.1.4.1.4526.100.7.9.17.5.1', NULL, NULL, NULL, 'system', '2014-03-19 14:46:44', 'null', '2000-01-01 00:00:00', 1, NULL, 1, 1, NULL),
	(40008, 10000, 0, '浮点测试', 2, 1, 2, '浮点测试', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'operator', '2014-06-20 16:19:50', NULL, NULL, 0, '564.41', 0, 3, 841),
	(40009, 10000, 0, '设备状态', 2, 1, 2, '设备状态', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'operator', '2014-06-20 16:21:17', NULL, NULL, 0, '2', 1, 4, 840),
	(40010, 10000, 0, '设备状态2', 2, 1, 2, '设备状态2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'operator', '2014-06-20 16:21:37', NULL, NULL, 0, '6.101', 0, 4, 840),
	(40011, 10000, 0, 'ICMP测试', 2, 1, 2, 'ICMP测试', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'operator', '2014-06-20 16:22:00', NULL, NULL, 1, '56.01', 0, 5, 846);
/*!40000 ALTER TABLE `tnt_alarm_conf` ENABLE KEYS */;


-- 导出  表 tnt_fm.tnt_alarm_group 结构
DROP TABLE IF EXISTS `tnt_alarm_group`;
CREATE TABLE IF NOT EXISTS `tnt_alarm_group` (
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `dev_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.tnt_alarm_group 的数据：~55 rows (大约)
DELETE FROM `tnt_alarm_group`;
/*!40000 ALTER TABLE `tnt_alarm_group` DISABLE KEYS */;
INSERT INTO `tnt_alarm_group` (`tbl_id`, `group_id`, `dev_type_id`) VALUES
	(5, 10000, 2),
	(6, 10000, 3),
	(7, 10000, 4),
	(8, 10000, 5),
	(9, 10000, 6),
	(10, 10000, 7),
	(11, 10000, 8),
	(12, 10000, 9),
	(13, 10000, 10),
	(14, 10000, 11),
	(15, 10000, 12),
	(16, 10000, 13),
	(17, 10000, 14),
	(18, 10000, 15),
	(19, 10000, 16),
	(20, 10000, 17),
	(21, 10000, 18),
	(22, 10000, 19),
	(23, 10000, 20),
	(24, 10000, 21),
	(25, 10000, 22),
	(26, 10000, 23),
	(27, 10000, 24),
	(28, 10000, 25),
	(29, 10000, 26),
	(30, 10000, 27),
	(31, 10000, 28),
	(32, 20000, 2),
	(33, 20000, 3),
	(34, 20000, 4),
	(35, 20000, 5),
	(36, 20000, 6),
	(37, 20000, 7),
	(38, 20000, 8),
	(39, 20000, 9),
	(40, 20000, 10),
	(41, 20000, 11),
	(42, 20000, 12),
	(43, 20000, 13),
	(44, 20000, 14),
	(45, 20000, 15),
	(46, 20000, 16),
	(47, 20000, 17),
	(48, 20000, 18),
	(49, 20000, 19),
	(50, 20000, 20),
	(51, 20000, 21),
	(52, 20000, 22),
	(53, 20000, 23),
	(54, 20000, 24),
	(55, 20000, 25),
	(56, 20000, 26),
	(57, 20000, 27),
	(58, 20000, 28),
	(59, 30000, 1);
/*!40000 ALTER TABLE `tnt_alarm_group` ENABLE KEYS */;


-- 导出  表 tnt_fm.tnt_alarm_severity 结构
DROP TABLE IF EXISTS `tnt_alarm_severity`;
CREATE TABLE IF NOT EXISTS `tnt_alarm_severity` (
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  `severity` int(11) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.tnt_alarm_severity 的数据：~4 rows (大约)
DELETE FROM `tnt_alarm_severity`;
/*!40000 ALTER TABLE `tnt_alarm_severity` DISABLE KEYS */;
INSERT INTO `tnt_alarm_severity` (`tbl_id`, `severity`, `name`) VALUES
	(1, 1, 'urgent'),
	(2, 2, 'serious'),
	(3, 3, 'normal'),
	(4, 4, 'hint');
/*!40000 ALTER TABLE `tnt_alarm_severity` ENABLE KEYS */;


-- 导出  表 tnt_fm.tnt_current_alarm 结构
DROP TABLE IF EXISTS `tnt_current_alarm`;
CREATE TABLE IF NOT EXISTS `tnt_current_alarm` (
  `alarm_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `alarm_sn` bigint(20) NOT NULL,
  `count` int(11) DEFAULT NULL,
  `dev_id` int(11) NOT NULL,
  `dev_type_id` int(11) NOT NULL,
  `dev_ip` varchar(128) NOT NULL DEFAULT '255.255.255.255',
  `dev_name` varchar(128) DEFAULT NULL,
  `fault_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_arrived_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `acked_user` varchar(128) DEFAULT NULL,
  `acked_time` timestamp NULL DEFAULT NULL,
  `paras` varchar(3072) DEFAULT NULL,
  `cleared_user` varchar(128) DEFAULT NULL,
  `cleared_time` timestamp NULL DEFAULT NULL,
  `status` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`alarm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.tnt_current_alarm 的数据：~2 rows (大约)
DELETE FROM `tnt_current_alarm`;
/*!40000 ALTER TABLE `tnt_current_alarm` DISABLE KEYS */;
INSERT INTO `tnt_current_alarm` (`alarm_id`, `alarm_sn`, `count`, `dev_id`, `dev_type_id`, `dev_ip`, `dev_name`, `fault_time`, `last_arrived_time`, `acked_user`, `acked_time`, `paras`, `cleared_user`, `cleared_time`, `status`) VALUES
	(17, 10003, 1, 12, 4, '192.168.0.1', 'SL3452', '2014-06-05 17:59:32', '2014-06-05 17:59:32', NULL, NULL, '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 2, 1.3.6.1.4.1.11863 = Port23 linkDown]', NULL, NULL, 'NANC'),
	(18, 10004, 1, 12, 4, '192.168.0.1', 'SL3452', '2014-06-05 17:59:33', '2014-06-05 17:59:33', NULL, NULL, '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 1, 1.3.6.1.4.1.11863 = Port23 linkUp]', NULL, NULL, 'NANC');
/*!40000 ALTER TABLE `tnt_current_alarm` ENABLE KEYS */;


-- 导出  表 tnt_fm.tnt_enterprise 结构
DROP TABLE IF EXISTS `tnt_enterprise`;
CREATE TABLE IF NOT EXISTS `tnt_enterprise` (
  `enterprise_id` varchar(128) NOT NULL,
  `enterprise_name` varchar(128) NOT NULL,
  PRIMARY KEY (`enterprise_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.tnt_enterprise 的数据：~0 rows (大约)
DELETE FROM `tnt_enterprise`;
/*!40000 ALTER TABLE `tnt_enterprise` DISABLE KEYS */;
/*!40000 ALTER TABLE `tnt_enterprise` ENABLE KEYS */;


-- 导出  表 tnt_fm.tnt_group_device 结构
DROP TABLE IF EXISTS `tnt_group_device`;
CREATE TABLE IF NOT EXISTS `tnt_group_device` (
  `tbl_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `dev_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.tnt_group_device 的数据：~7 rows (大约)
DELETE FROM `tnt_group_device`;
/*!40000 ALTER TABLE `tnt_group_device` DISABLE KEYS */;
INSERT INTO `tnt_group_device` (`tbl_id`, `group_id`, `dev_type_id`) VALUES
	(1, 10000, 1),
	(2, 20000, 1),
	(3, 10000, 2),
	(4, 10000, 3),
	(5, 10000, 4),
	(6, 10000, 6),
	(7, 20000, 6);
/*!40000 ALTER TABLE `tnt_group_device` ENABLE KEYS */;


-- 导出  表 tnt_fm.tnt_history_alarm 结构
DROP TABLE IF EXISTS `tnt_history_alarm`;
CREATE TABLE IF NOT EXISTS `tnt_history_alarm` (
  `alarm_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `alarm_sn` bigint(20) NOT NULL,
  `count` int(11) NOT NULL,
  `dev_id` int(11) DEFAULT NULL,
  `dev_ip` varchar(128) NOT NULL DEFAULT '255.255.255.255',
  `dev_name` varchar(45) DEFAULT NULL,
  `fault_time` timestamp NULL DEFAULT NULL,
  `acked_user` varchar(128) DEFAULT NULL,
  `acked_time` timestamp NULL DEFAULT NULL,
  `cleared_user` varchar(128) DEFAULT NULL,
  `cleared_time` timestamp NULL DEFAULT NULL,
  `paras` varchar(3072) DEFAULT NULL,
  `status` varchar(128) DEFAULT NULL,
  `last_arrived_time` timestamp NULL DEFAULT NULL,
  `dev_type_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`alarm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.tnt_history_alarm 的数据：~6 rows (大约)
DELETE FROM `tnt_history_alarm`;
/*!40000 ALTER TABLE `tnt_history_alarm` DISABLE KEYS */;
INSERT INTO `tnt_history_alarm` (`alarm_id`, `alarm_sn`, `count`, `dev_id`, `dev_ip`, `dev_name`, `fault_time`, `acked_user`, `acked_time`, `cleared_user`, `cleared_time`, `paras`, `status`, `last_arrived_time`, `dev_type_id`) VALUES
	(23, 10004, 1, 12, '192.168.0.1', 'SL3452', '2014-06-05 16:58:55', NULL, NULL, 'system', '2014-06-05 17:00:48', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 1, 1.3.6.1.4.1.11863 = Port23 linkUp]', 'NAC', '2014-06-05 16:58:55', '4'),
	(24, 10003, 1, 12, '192.168.0.1', 'SL3452', '2014-06-05 16:58:50', NULL, NULL, 'system', '2014-06-05 17:00:56', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 2, 1.3.6.1.4.1.11863 = Port23 linkDown]', 'NAC', '2014-06-05 16:58:50', '4'),
	(25, 10004, 1, 12, '192.168.0.1', 'SL3452', '2014-06-05 17:30:25', NULL, NULL, 'system', '2014-06-05 17:34:29', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 1, 1.3.6.1.4.1.11863 = Port23 linkUp]', 'NAC', '2014-06-05 17:30:25', '4'),
	(26, 10003, 1, 12, '192.168.0.1', 'SL3452', '2014-06-05 17:30:21', NULL, NULL, 'system', '2014-06-05 17:34:38', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 2, 1.3.6.1.4.1.11863 = Port23 linkDown]', 'NAC', '2014-06-05 17:30:21', '4'),
	(27, 10003, 1, 12, '192.168.0.1', 'SL3452', '2014-06-05 17:57:40', NULL, NULL, 'system', '2014-06-05 17:59:22', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 2, 1.3.6.1.4.1.11863 = Port23 linkDown]', 'NAC', '2014-06-05 17:57:40', '4'),
	(28, 10004, 1, 12, '192.168.0.1', 'SL3452', '2014-06-05 17:57:43', NULL, NULL, 'system', '2014-06-05 17:59:26', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 1, 1.3.6.1.4.1.11863 = Port23 linkUp]', 'NAC', '2014-06-05 17:57:43', '4');
/*!40000 ALTER TABLE `tnt_history_alarm` ENABLE KEYS */;


-- 导出  表 tnt_fm.tnt_trap 结构
DROP TABLE IF EXISTS `tnt_trap`;
CREATE TABLE IF NOT EXISTS `tnt_trap` (
  `trap_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `receive_time` timestamp NULL DEFAULT NULL,
  `trap_version` varchar(8) DEFAULT NULL,
  `dev_ip` varchar(128) DEFAULT '255.255.255.255',
  `paras` varchar(3072) DEFAULT NULL,
  `system_time_long` bigint(20) DEFAULT NULL,
  `enterprise_id` int(11) DEFAULT NULL,
  `trap_oid` varchar(256) DEFAULT NULL,
  `generic_id` smallint(6) DEFAULT NULL,
  `specific_id` smallint(6) DEFAULT NULL,
  `trap_type` varchar(128) DEFAULT NULL,
  `dev_id` int(11) DEFAULT NULL,
  `system_time` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`trap_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_fm.tnt_trap 的数据：~5 rows (大约)
DELETE FROM `tnt_trap`;
/*!40000 ALTER TABLE `tnt_trap` DISABLE KEYS */;
INSERT INTO `tnt_trap` (`trap_id`, `receive_time`, `trap_version`, `dev_ip`, `paras`, `system_time_long`, `enterprise_id`, `trap_oid`, `generic_id`, `specific_id`, `trap_type`, `dev_id`, `system_time`) VALUES
	(16, '2014-06-05 17:30:21', 'V2c', '192.168.0.1', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 2, 1.3.6.1.4.1.11863 = Port23 linkDown]', NULL, NULL, '1.3.6.1.6.3.1.1.5.3', NULL, NULL, '1.3.6.1.6.3.1.1.5.3', 12, '1:20:01.71'),
	(17, '2014-06-05 17:30:25', 'V2c', '192.168.0.1', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 1, 1.3.6.1.4.1.11863 = Port23 linkUp]', NULL, NULL, '1.3.6.1.6.3.1.1.5.4', NULL, NULL, '1.3.6.1.6.3.1.1.5.4', 12, '1:20:05.86'),
	(18, '2014-06-05 17:57:40', 'V2c', '192.168.0.1', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 2, 1.3.6.1.4.1.11863 = Port23 linkDown]', NULL, NULL, '1.3.6.1.6.3.1.1.5.3', NULL, NULL, '1.3.6.1.6.3.1.1.5.3', 12, '1:47:17.78'),
	(19, '2014-06-05 17:57:43', 'V2c', '192.168.0.1', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 1, 1.3.6.1.4.1.11863 = Port23 linkUp]', NULL, NULL, '1.3.6.1.6.3.1.1.5.4', NULL, NULL, '1.3.6.1.6.3.1.1.5.4', 12, '1:47:21.01'),
	(20, '2014-06-05 17:59:32', 'V2c', '192.168.0.1', '[1.3.6.1.2.1.2.2.1.1.23 = 23, 1.3.6.1.2.1.2.2.1.7.23 = 1, 1.3.6.1.2.1.2.2.1.8.23 = 2, 1.3.6.1.4.1.11863 = Port23 linkDown]', NULL, NULL, '1.3.6.1.6.3.1.1.5.3', NULL, NULL, '1.3.6.1.6.3.1.1.5.3', 12, '1:49:09.21');
/*!40000 ALTER TABLE `tnt_trap` ENABLE KEYS */;


-- 导出 tnt_monitor 的数据库结构
DROP DATABASE IF EXISTS `tnt_monitor`;
CREATE DATABASE IF NOT EXISTS `tnt_monitor` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tnt_monitor`;


-- 导出  表 tnt_monitor.pm_dashboard_view 结构
DROP TABLE IF EXISTS `pm_dashboard_view`;
CREATE TABLE IF NOT EXISTS `pm_dashboard_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `interval_type` int(11) NOT NULL,
  `interval` int(11) DEFAULT NULL,
  `source` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_dashboard_view 的数据：~0 rows (大约)
DELETE FROM `pm_dashboard_view`;
/*!40000 ALTER TABLE `pm_dashboard_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_dashboard_view` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_entry_device_rel 结构
DROP TABLE IF EXISTS `pm_entry_device_rel`;
CREATE TABLE IF NOT EXISTS `pm_entry_device_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_id` int(11) NOT NULL,
  `dev_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`),
  CONSTRAINT `pm_entry_device_rel_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `pm_monitor_entry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_entry_device_rel 的数据：~0 rows (大约)
DELETE FROM `pm_entry_device_rel`;
/*!40000 ALTER TABLE `pm_entry_device_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_entry_device_rel` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_entry_group_rel 结构
DROP TABLE IF EXISTS `pm_entry_group_rel`;
CREATE TABLE IF NOT EXISTS `pm_entry_group_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`),
  CONSTRAINT `pm_entry_group_rel_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `pm_monitor_entry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_entry_group_rel 的数据：~0 rows (大约)
DELETE FROM `pm_entry_group_rel`;
/*!40000 ALTER TABLE `pm_entry_group_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_entry_group_rel` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_entry_indicator_rel 结构
DROP TABLE IF EXISTS `pm_entry_indicator_rel`;
CREATE TABLE IF NOT EXISTS `pm_entry_indicator_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_id` int(11) NOT NULL,
  `indicator_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `indicator_id` (`indicator_id`),
  KEY `entry_id` (`entry_id`),
  CONSTRAINT `pm_entry_indicator_rel_ibfk_2` FOREIGN KEY (`indicator_id`) REFERENCES `pm_indicator` (`id`),
  CONSTRAINT `pm_entry_indicator_rel_ibfk_4` FOREIGN KEY (`indicator_id`) REFERENCES `pm_indicator` (`id`),
  CONSTRAINT `pm_entry_indicator_rel_ibfk_5` FOREIGN KEY (`entry_id`) REFERENCES `pm_monitor_entry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_entry_indicator_rel 的数据：~0 rows (大约)
DELETE FROM `pm_entry_indicator_rel`;
/*!40000 ALTER TABLE `pm_entry_indicator_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_entry_indicator_rel` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_indicator 结构
DROP TABLE IF EXISTS `pm_indicator`;
CREATE TABLE IF NOT EXISTS `pm_indicator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `unit` varchar(8) NOT NULL,
  `cal_class` varchar(128) NOT NULL,
  `cal_exp` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_indicator 的数据：~26 rows (大约)
DELETE FROM `pm_indicator`;
/*!40000 ALTER TABLE `pm_indicator` DISABLE KEYS */;
INSERT INTO `pm_indicator` (`id`, `name`, `unit`, `cal_class`, `cal_exp`) VALUES
	(1, 'monitor.indicator.deviceStatus', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.status.UpDownCal', ''),
	(2, 'monitor.indicator.ipInAddrError', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.ip.IpInAddrErrorsCal', ''),
	(3, 'monitor.indicator.ipInDiscard', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.ip.IpInDiscardsCal', ''),
	(4, 'monitor.indicator.ipInHdrError', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.ip.IpInHdrErrorsCal', ''),
	(5, 'monitor.indicator.ipOutDiscard', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.ip.IpOutDiscardsCal', ''),
	(6, 'monitor.indicator.ipOutNoRoutes', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.ip.IpOutNoRoutesCal', ''),
	(7, 'monitor.indicator.icmpInMsgs', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.icmp.IcmpInMsgsCal', ''),
	(8, 'monitor.indicator.icmpInErrors', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.icmp.IcmpInErrorsCal', ''),
	(9, 'monitor.indicator.icmpOutMsgs', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.icmp.IcmpOutMsgsCal', ''),
	(10, 'monitor.indicator.tcpInErrors', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.tcp.TcpInErrorsCal', ''),
	(11, 'monitor.indicator.tcpAttemptFails', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.tcp.TcpAttemptFailsCal', ''),
	(12, 'monitor.indicator.tcpConnections', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.tcp.TcpCurrEstabCal', ''),
	(13, 'monitor.indicator.udpInErrors', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.udp.UdpInErrorsCal', ''),
	(14, 'monitor.indicator.udpNoRoutes', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.udp.UdpNoPortsCal', ''),
	(15, 'monitor.indicator.snmpInTraps', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.snmp.SnmpDeviceInTrapsCal', ''),
	(16, 'monitor.indicator.snmpOutTraps', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.snmp.SnmpDeviceOutTrapsCal', ''),
	(17, 'monitor.indicator.ifInUcast', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfInUcastPktsCal', ''),
	(18, 'monitor.indicator.ifOutUcast', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfOutUcastPktsCal', ''),
	(19, 'monitor.indicator.ifInNUcast', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfInNUcastPktsCal', ''),
	(20, 'monitor.indicator.ifOutNUcast', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfOutNUcastPktsCal', ''),
	(21, 'monitor.indicator.ifInOctets', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfInOctetsCal', ''),
	(22, 'monitor.indicator.ifOutOctets', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfOutOctetsCal', ''),
	(23, 'monitor.indicator.ifInErrors', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfInErrorsCal', ''),
	(24, 'monitor.indicator.ifOutErrors', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfOutErrorsCal', ''),
	(25, 'monitor.indicator.ifInDiscards', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfInDiscardsCal', ''),
	(26, 'monitor.indicator.ifOutDiscards', '', 'com.tp_link.nms.apps.monitor.service.calculator.impl.inf.IfOutDiscardsCal', '');
/*!40000 ALTER TABLE `pm_indicator` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_monitor_data 结构
DROP TABLE IF EXISTS `pm_monitor_data`;
CREATE TABLE IF NOT EXISTS `pm_monitor_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_id` int(11) NOT NULL,
  `dev_id` int(11) NOT NULL,
  `value` varchar(128) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `indicator_id` (`indicator_id`),
  CONSTRAINT `pm_monitor_data_ibfk_1` FOREIGN KEY (`indicator_id`) REFERENCES `pm_indicator` (`id`),
  CONSTRAINT `pm_monitor_data_ibfk_2` FOREIGN KEY (`indicator_id`) REFERENCES `pm_indicator` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_monitor_data 的数据：~0 rows (大约)
DELETE FROM `pm_monitor_data`;
/*!40000 ALTER TABLE `pm_monitor_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_monitor_data` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_monitor_entry 结构
DROP TABLE IF EXISTS `pm_monitor_entry`;
CREATE TABLE IF NOT EXISTS `pm_monitor_entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `describe` varchar(256) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `type` varchar(128) NOT NULL,
  `interval` tinyint(4) NOT NULL,
  `interval_type` tinyint(4) NOT NULL,
  `device_all` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_monitor_entry 的数据：~0 rows (大约)
DELETE FROM `pm_monitor_entry`;
/*!40000 ALTER TABLE `pm_monitor_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_monitor_entry` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_monitor_interface_data 结构
DROP TABLE IF EXISTS `pm_monitor_interface_data`;
CREATE TABLE IF NOT EXISTS `pm_monitor_interface_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_id` int(11) NOT NULL,
  `dev_id` int(11) NOT NULL,
  `dev_if_id` int(11) NOT NULL,
  `value` varchar(128) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `indicator_id` (`indicator_id`),
  CONSTRAINT `pm_monitor_interface_data_ibfk_1` FOREIGN KEY (`indicator_id`) REFERENCES `pm_indicator` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_monitor_interface_data 的数据：~0 rows (大约)
DELETE FROM `pm_monitor_interface_data`;
/*!40000 ALTER TABLE `pm_monitor_interface_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_monitor_interface_data` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_statistic 结构
DROP TABLE IF EXISTS `pm_statistic`;
CREATE TABLE IF NOT EXISTS `pm_statistic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `class` varchar(256) NOT NULL,
  `entry_type` varchar(128) DEFAULT NULL,
  `value_name` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_statistic 的数据：~10 rows (大约)
DELETE FROM `pm_statistic`;
/*!40000 ALTER TABLE `pm_statistic` DISABLE KEYS */;
INSERT INTO `pm_statistic` (`id`, `name`, `class`, `entry_type`, `value_name`) VALUES
	(1, 'monitor.statistic.ipErrPktsToday', 'com.tp_link.nms.apps.monitor.service.stastic.IpErrPktsTodayStatJob', 'type.device', 'monitor.statistic.ipErrPkts'),
	(2, 'monitor.statistic.ipDiscardPktsToday', 'com.tp_link.nms.apps.monitor.service.stastic.IpDiscardPktsTodayStatJob', 'type.device', 'monitor.statistic.ipDiscardPkts'),
	(3, 'monitor.statistic.snmpInTrapsToday', 'com.tp_link.nms.apps.monitor.service.stastic.SnmpInTrapTodayStatJob', 'type.device', 'monitor.statistic.snmpInTraps'),
	(4, 'monitor.statistic.snmpOutTrapsToday', 'com.tp_link.nms.apps.monitor.service.stastic.SnmpOutTrapTodayStatJob', 'type.device', 'monitor.statistic.snmpOutTraps'),
	(5, 'monitor.statistic.tcpErrPktsToday', 'com.tp_link.nms.apps.monitor.service.stastic.TcpErrPktsTodayStatJob', 'type.device', 'monitor.statistic.tcpErrPkts'),
	(6, 'monitor.statistic.udpErrPktsToday', 'com.tp_link.nms.apps.monitor.service.stastic.UdpErrPktsTodayStatJob', 'type.device', 'monitor.statistic.udpErrPkts'),
	(7, 'monitor.statistic.udpNoPortsToday', 'com.tp_link.nms.apps.monitor.service.stastic.UdpNoPortsPktTodayStatJob', 'type.device', 'monitor.statistic.udpNoPorts'),
	(8, 'monitor.statistic.ifDiscardsToday', 'com.tp_link.nms.apps.monitor.service.stastic.IfDiscardPktsTodayStatJob', 'type.interface', 'monitor.statistic.ifDiscards'),
	(9, 'monitor.statistic.ifErrPktsToday', 'com.tp_link.nms.apps.monitor.service.stastic.IfErrPktsTodayStatJob', 'type.interface', 'monitor.statistic.ifErrPkts'),
	(10, 'monitor.statistic.ifUcastPktsToday', 'com.tp_link.nms.apps.monitor.service.stastic.IfUcastPktsTodayStatJob', 'type.interface', 'monitor.statistic.ifUcastPkts');
/*!40000 ALTER TABLE `pm_statistic` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_topn_device_statistic 结构
DROP TABLE IF EXISTS `pm_topn_device_statistic`;
CREATE TABLE IF NOT EXISTS `pm_topn_device_statistic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `statistic_id` int(11) NOT NULL,
  `dev_id` int(11) NOT NULL,
  `dev_type` varchar(256) NOT NULL,
  `dev_name` varchar(256) NOT NULL,
  `value` varchar(128) NOT NULL,
  `top` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `statistic_id` (`statistic_id`),
  CONSTRAINT `pm_topn_device_statistic_ibfk_1` FOREIGN KEY (`statistic_id`) REFERENCES `pm_statistic` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_topn_device_statistic 的数据：~0 rows (大约)
DELETE FROM `pm_topn_device_statistic`;
/*!40000 ALTER TABLE `pm_topn_device_statistic` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_topn_device_statistic` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_topn_interface_statistic 结构
DROP TABLE IF EXISTS `pm_topn_interface_statistic`;
CREATE TABLE IF NOT EXISTS `pm_topn_interface_statistic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `statistic_id` int(11) NOT NULL,
  `dev_id` int(11) NOT NULL,
  `dev_if_id` int(11) NOT NULL,
  `dev_name` varchar(256) NOT NULL,
  `if_name` varchar(256) NOT NULL,
  `in_value` varchar(128) NOT NULL,
  `out_value` varchar(128) NOT NULL,
  `top` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `statistic_id` (`statistic_id`),
  CONSTRAINT `pm_topn_interface_statistic_ibfk_1` FOREIGN KEY (`statistic_id`) REFERENCES `pm_statistic` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_topn_interface_statistic 的数据：~0 rows (大约)
DELETE FROM `pm_topn_interface_statistic`;
/*!40000 ALTER TABLE `pm_topn_interface_statistic` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_topn_interface_statistic` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_view_device_rel 结构
DROP TABLE IF EXISTS `pm_view_device_rel`;
CREATE TABLE IF NOT EXISTS `pm_view_device_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `view_id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `view_id` (`view_id`),
  CONSTRAINT `pm_view_device_rel_ibfk_1` FOREIGN KEY (`view_id`) REFERENCES `pm_dashboard_view` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_view_device_rel 的数据：~0 rows (大约)
DELETE FROM `pm_view_device_rel`;
/*!40000 ALTER TABLE `pm_view_device_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_view_device_rel` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_view_indicator_rel 结构
DROP TABLE IF EXISTS `pm_view_indicator_rel`;
CREATE TABLE IF NOT EXISTS `pm_view_indicator_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `view_id` int(11) NOT NULL,
  `indicator_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `view_id` (`view_id`),
  KEY `indicator_id` (`indicator_id`),
  CONSTRAINT `pm_view_indicator_rel_ibfk_1` FOREIGN KEY (`view_id`) REFERENCES `pm_dashboard_view` (`id`),
  CONSTRAINT `pm_view_indicator_rel_ibfk_2` FOREIGN KEY (`indicator_id`) REFERENCES `pm_indicator` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_view_indicator_rel 的数据：~0 rows (大约)
DELETE FROM `pm_view_indicator_rel`;
/*!40000 ALTER TABLE `pm_view_indicator_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_view_indicator_rel` ENABLE KEYS */;


-- 导出  表 tnt_monitor.pm_view_interface_rel 结构
DROP TABLE IF EXISTS `pm_view_interface_rel`;
CREATE TABLE IF NOT EXISTS `pm_view_interface_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `view_id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `dev_if_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `view_id` (`view_id`),
  CONSTRAINT `pm_view_interface_rel_ibfk_1` FOREIGN KEY (`view_id`) REFERENCES `pm_dashboard_view` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_monitor.pm_view_interface_rel 的数据：~0 rows (大约)
DELETE FROM `pm_view_interface_rel`;
/*!40000 ALTER TABLE `pm_view_interface_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `pm_view_interface_rel` ENABLE KEYS */;


-- 导出 tnt_resource 的数据库结构
DROP DATABASE IF EXISTS `tnt_resource`;
CREATE DATABASE IF NOT EXISTS `tnt_resource` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tnt_resource`;


-- 导出  表 tnt_resource.tbl_autodiscover_timer 结构
DROP TABLE IF EXISTS `tbl_autodiscover_timer`;
CREATE TABLE IF NOT EXISTS `tbl_autodiscover_timer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_time` bigint(20) NOT NULL,
  `interval_type` int(3) NOT NULL,
  `interval_value` int(10) NOT NULL,
  `enable_status` int(1) NOT NULL,
  `begin_ip` varchar(15) NOT NULL,
  `end_ip` varchar(15) NOT NULL,
  `last_excute_time` datetime NOT NULL,
  `next_excute_time` datetime NOT NULL,
  `snmp_template_id` int(10) NOT NULL,
  `telnet_template_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_autodiscover_timer 的数据：~0 rows (大约)
DELETE FROM `tbl_autodiscover_timer`;
/*!40000 ALTER TABLE `tbl_autodiscover_timer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_autodiscover_timer` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_category_info 结构
DROP TABLE IF EXISTS `tbl_category_info`;
CREATE TABLE IF NOT EXISTS `tbl_category_info` (
  `CATEGORY_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CATEGORY_NAME` varchar(64) NOT NULL,
  `CATEGORY_DEV_ICON_ID` int(10) unsigned NOT NULL DEFAULT '10000',
  `CATEGORY_TOPO_ICON_ID` int(10) unsigned NOT NULL DEFAULT '10000',
  `CATEGORY_DEFAULT_VISIBLE` int(1) NOT NULL,
  PRIMARY KEY (`CATEGORY_ID`),
  KEY `CATEGORY_DEV_ICON_ID` (`CATEGORY_DEV_ICON_ID`),
  KEY `CATEGORY_TOPO_ICON_ID` (`CATEGORY_TOPO_ICON_ID`),
  CONSTRAINT `tbl_category_info_ibfk_1` FOREIGN KEY (`CATEGORY_DEV_ICON_ID`) REFERENCES `tbl_icon_info` (`ICON_ID`),
  CONSTRAINT `tbl_category_info_ibfk_2` FOREIGN KEY (`CATEGORY_TOPO_ICON_ID`) REFERENCES `tbl_icon_info` (`ICON_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_category_info 的数据：~4 rows (大约)
DELETE FROM `tbl_category_info`;
/*!40000 ALTER TABLE `tbl_category_info` DISABLE KEYS */;
INSERT INTO `tbl_category_info` (`CATEGORY_ID`, `CATEGORY_NAME`, `CATEGORY_DEV_ICON_ID`, `CATEGORY_TOPO_ICON_ID`, `CATEGORY_DEFAULT_VISIBLE`) VALUES
	(1, 'switch', 1, 1, 1),
	(2, 'route', 2, 2, 1),
	(3, 'icmp', 3, 3, 1),
	(4, 'otherSnmp', 4, 4, 1);
/*!40000 ALTER TABLE `tbl_category_info` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_device_access_config 结构
DROP TABLE IF EXISTS `tbl_device_access_config`;
CREATE TABLE IF NOT EXISTS `tbl_device_access_config` (
  `DEV_ID` int(10) unsigned NOT NULL COMMENT '???id',
  `SNMP_ID` int(10) unsigned NOT NULL,
  `TELNET_ID` int(10) unsigned NOT NULL,
  `LOGIN_TYPE` smallint(3) NOT NULL COMMENT '?????????',
  `STATUS_CHECK_PERIOD` int(11) NOT NULL COMMENT '?????????????',
  PRIMARY KEY (`DEV_ID`),
  UNIQUE KEY `SNMP_ID` (`SNMP_ID`),
  UNIQUE KEY `TELNET_ID` (`TELNET_ID`),
  CONSTRAINT `tbl_device_access_config_ibfk_1` FOREIGN KEY (`SNMP_ID`) REFERENCES `tbl_snmp_config` (`SNMP_ID`),
  CONSTRAINT `tbl_device_access_config_ibfk_2` FOREIGN KEY (`TELNET_ID`) REFERENCES `tbl_telnet_config` (`TELNET_ID`),
  CONSTRAINT `tbl_device_access_config_ibfk_3` FOREIGN KEY (`DEV_ID`) REFERENCES `tbl_device_info` (`DEV_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_device_access_config 的数据：~0 rows (大约)
DELETE FROM `tbl_device_access_config`;
/*!40000 ALTER TABLE `tbl_device_access_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_device_access_config` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_device_info 结构
DROP TABLE IF EXISTS `tbl_device_info`;
CREATE TABLE IF NOT EXISTS `tbl_device_info` (
  `DEV_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DEV_NAME` varchar(256) NOT NULL,
  `DEV_TYPE_ID` int(10) unsigned NOT NULL,
  `DEV_IP` varchar(128) NOT NULL,
  `DEV_MASK` varchar(128) NOT NULL,
  `DEV_MAC` varchar(20) NOT NULL,
  `DEV_STATUS` int(10) unsigned NOT NULL,
  `DEV_DISCOVERY_TIME` bigint(20) unsigned NOT NULL,
  `DEV_CATEGORY_ID` int(10) unsigned NOT NULL,
  `DEV_SYNCHOR_TIME` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`DEV_ID`),
  KEY `DEV_TYPE_ID` (`DEV_TYPE_ID`),
  KEY `DEV_CATEGORY_ID` (`DEV_CATEGORY_ID`),
  CONSTRAINT `tbl_device_info_ibfk_1` FOREIGN KEY (`DEV_TYPE_ID`) REFERENCES `tbl_type_info` (`TYPE_ID`),
  CONSTRAINT `tbl_device_info_ibfk_2` FOREIGN KEY (`DEV_CATEGORY_ID`) REFERENCES `tbl_category_info` (`CATEGORY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_device_info 的数据：~0 rows (大约)
DELETE FROM `tbl_device_info`;
/*!40000 ALTER TABLE `tbl_device_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_device_info` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_device_interfaces 结构
DROP TABLE IF EXISTS `tbl_device_interfaces`;
CREATE TABLE IF NOT EXISTS `tbl_device_interfaces` (
  `DEV_ID` int(10) unsigned NOT NULL,
  `DEV_IFINDEX` int(10) unsigned NOT NULL,
  `DEV_IFNAME` varchar(255) NOT NULL,
  `DEV_IFDESC` varchar(255) NOT NULL,
  `DEV_IFTYPE` int(10) unsigned NOT NULL,
  `DEV_IFSPEED` int(10) unsigned NOT NULL,
  `DEV_IFPHYADDRESS` varchar(20) NOT NULL,
  `DEV_IFADMINSTATUS` int(10) unsigned NOT NULL,
  `DEV_IFOPSTATUS` int(10) unsigned NOT NULL,
  `DEV_IFMTU` int(10) unsigned NOT NULL,
  `DEV_IFALIAS` varchar(255) NOT NULL,
  `DEV_IFLASTCHANGE` int(11) NOT NULL,
  `DEV_IFUSED` int(1) NOT NULL DEFAULT '0',
  `DEV_IFISPORT` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`DEV_ID`,`DEV_IFINDEX`),
  CONSTRAINT `FKCEA1B5A2BEF5AC49` FOREIGN KEY (`DEV_ID`) REFERENCES `tbl_device_snmpinfo` (`DEV_ID`),
  CONSTRAINT `tbl_device_interfaces_ibfk_1` FOREIGN KEY (`DEV_ID`) REFERENCES `tbl_device_snmpinfo` (`DEV_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_device_interfaces 的数据：~0 rows (大约)
DELETE FROM `tbl_device_interfaces`;
/*!40000 ALTER TABLE `tbl_device_interfaces` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_device_interfaces` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_device_snmpinfo 结构
DROP TABLE IF EXISTS `tbl_device_snmpinfo`;
CREATE TABLE IF NOT EXISTS `tbl_device_snmpinfo` (
  `DEV_ID` int(10) unsigned NOT NULL COMMENT '???id',
  `DEV_SYSOID` varchar(255) NOT NULL COMMENT '?????OID',
  `DEV_SYSNAME` varchar(255) NOT NULL,
  `DEV_VERSION` varchar(255) NOT NULL COMMENT '?????????????',
  `DEV_CONTACT` varchar(255) NOT NULL COMMENT '????????',
  `DEV_LOCATION` varchar(255) NOT NULL COMMENT '???????',
  `DEV_START_TIME` bigint(20) DEFAULT NULL,
  `DEV_DESCRIPTION` varchar(500) NOT NULL,
  PRIMARY KEY (`DEV_ID`),
  CONSTRAINT `tbl_device_snmpinfo_ibfk_1` FOREIGN KEY (`DEV_ID`) REFERENCES `tbl_device_info` (`DEV_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_device_snmpinfo 的数据：~0 rows (大约)
DELETE FROM `tbl_device_snmpinfo`;
/*!40000 ALTER TABLE `tbl_device_snmpinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_device_snmpinfo` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_dev_group 结构
DROP TABLE IF EXISTS `tbl_dev_group`;
CREATE TABLE IF NOT EXISTS `tbl_dev_group` (
  `GROUP_ID` int(11) NOT NULL AUTO_INCREMENT,
  `GROUP_TYPE` int(11) NOT NULL,
  `GROUP_NAME` varchar(128) NOT NULL,
  `GROUP_DESCRIPTION` varchar(256) NOT NULL,
  `GROUP_CREATEBY` varchar(128) NOT NULL,
  `GROUP_CREATETIME` bigint(20) NOT NULL,
  `GROUP_MEMBER_NUMBER` int(11) NOT NULL DEFAULT '0',
  `FILTER_VENDOR` varchar(64) DEFAULT NULL,
  `FILTER_CATEGORY` int(11) DEFAULT NULL,
  `FILTER_TYPE` varchar(128) DEFAULT NULL,
  `FILTER_LOCATION` varchar(128) DEFAULT NULL,
  `FILTER_CONTACT` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_dev_group 的数据：~0 rows (大约)
DELETE FROM `tbl_dev_group`;
/*!40000 ALTER TABLE `tbl_dev_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_dev_group` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_group_member 结构
DROP TABLE IF EXISTS `tbl_group_member`;
CREATE TABLE IF NOT EXISTS `tbl_group_member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GROUP_ID` int(11) NOT NULL,
  `DEV_ID` int(10) unsigned NOT NULL COMMENT '???id',
  PRIMARY KEY (`ID`),
  KEY `GROUP_ID` (`GROUP_ID`),
  KEY `DEV_ID` (`DEV_ID`),
  CONSTRAINT `tbl_group_member_ibfk_1` FOREIGN KEY (`GROUP_ID`) REFERENCES `tbl_dev_group` (`GROUP_ID`),
  CONSTRAINT `tbl_group_member_ibfk_2` FOREIGN KEY (`DEV_ID`) REFERENCES `tbl_device_info` (`DEV_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_group_member 的数据：~0 rows (大约)
DELETE FROM `tbl_group_member`;
/*!40000 ALTER TABLE `tbl_group_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_group_member` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_icon_info 结构
DROP TABLE IF EXISTS `tbl_icon_info`;
CREATE TABLE IF NOT EXISTS `tbl_icon_info` (
  `ICON_ID` int(10) unsigned NOT NULL DEFAULT '0',
  `ICON_NAME` varchar(100) NOT NULL,
  `ICON_FILENAME` varchar(100) NOT NULL,
  `ICON_TYPE` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ICON_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_icon_info 的数据：~4 rows (大约)
DELETE FROM `tbl_icon_info`;
/*!40000 ALTER TABLE `tbl_icon_info` DISABLE KEYS */;
INSERT INTO `tbl_icon_info` (`ICON_ID`, `ICON_NAME`, `ICON_FILENAME`, `ICON_TYPE`) VALUES
	(1, 'switch', 'style/images/rm/device_switch.png', 0),
	(2, 'route', 'style/images/rm/device_route.png', 0),
	(3, 'icmp', 'style/images/rm/device_icmp.png', 0),
	(4, 'other snmp', 'style/images/rm/device_unknown.png', 0);
/*!40000 ALTER TABLE `tbl_icon_info` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_link_info 结构
DROP TABLE IF EXISTS `tbl_link_info`;
CREATE TABLE IF NOT EXISTS `tbl_link_info` (
  `LINK_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LINK_NAME` varchar(255) NOT NULL,
  `LINK_SDEV_ID` int(10) unsigned NOT NULL COMMENT '???id',
  `LINK_SDEV_NAME` varchar(255) NOT NULL,
  `LINK_SDEV_IP` varchar(128) NOT NULL,
  `LINK_SDEV_STATE` int(10) unsigned NOT NULL,
  `LINK_SDEV_PORTINDEX` int(10) unsigned NOT NULL,
  `LINK_SDEV_PORTNAME` varchar(128) NOT NULL,
  `LINK_SDEV_PORTADMINSTATUS` int(10) unsigned NOT NULL,
  `LINK_SDEV_PORTOPSTATUS` int(10) unsigned NOT NULL,
  `LINK_DDEV_ID` int(10) unsigned NOT NULL COMMENT '???id',
  `LINK_DDEV_NAME` varchar(255) NOT NULL,
  `LINK_DDEV_IP` varchar(128) NOT NULL,
  `LINK_DDEV_STATE` int(10) unsigned NOT NULL,
  `LINK_DDEV_PORTINDEX` int(10) unsigned NOT NULL,
  `LINK_DDEV_PORTNAME` varchar(128) NOT NULL,
  `LINK_DDEV_PORTADMINSTATUS` int(10) unsigned NOT NULL,
  `LINK_DDEV_PORTOPSTATUS` int(10) unsigned NOT NULL,
  `LINK_STATUS` int(10) unsigned NOT NULL,
  `LINK_TYPE` int(10) unsigned NOT NULL,
  `LINK_SPEED` int(10) unsigned NOT NULL,
  PRIMARY KEY (`LINK_ID`),
  KEY `LINK_SDEV_ID` (`LINK_SDEV_ID`,`LINK_SDEV_PORTINDEX`),
  KEY `LINK_DDEV_ID` (`LINK_DDEV_ID`,`LINK_DDEV_PORTINDEX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_link_info 的数据：~0 rows (大约)
DELETE FROM `tbl_link_info`;
/*!40000 ALTER TABLE `tbl_link_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_link_info` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_snmp_config 结构
DROP TABLE IF EXISTS `tbl_snmp_config`;
CREATE TABLE IF NOT EXISTS `tbl_snmp_config` (
  `SNMP_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SNMP_VERSION` smallint(2) NOT NULL,
  `SNMP_PORT` int(10) unsigned NOT NULL,
  `SNMP_TIMEOUT` int(10) unsigned NOT NULL,
  `SNMP_RETRIES` int(10) unsigned NOT NULL,
  `SNMP_READCOMMUNITY` varchar(255) DEFAULT NULL,
  `SNMP_WRITECOMMUNITY` varchar(255) DEFAULT NULL,
  `SNMP_CONTEXT_NAME` varchar(64) NOT NULL,
  `SNMP_SECURITY_MODE` int(10) unsigned NOT NULL,
  `SNMP_SECURITY_NAME` varchar(64) NOT NULL,
  `SNMP_AUTH_MODE` int(10) unsigned NOT NULL,
  `SNMP_AUTH_PWD` varchar(64) NOT NULL,
  `SNMP_PRIVACY_MODE` int(10) unsigned NOT NULL,
  `SNMP_PRIVACY_PWD` varchar(64) NOT NULL,
  `TEMPLATE_TYPE` int(10) unsigned NOT NULL,
  `TEMPLATE_NAME` varchar(128) NOT NULL,
  PRIMARY KEY (`SNMP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_snmp_config 的数据：~1 rows (大约)
DELETE FROM `tbl_snmp_config`;
/*!40000 ALTER TABLE `tbl_snmp_config` DISABLE KEYS */;
INSERT INTO `tbl_snmp_config` (`SNMP_ID`, `SNMP_VERSION`, `SNMP_PORT`, `SNMP_TIMEOUT`, `SNMP_RETRIES`, `SNMP_READCOMMUNITY`, `SNMP_WRITECOMMUNITY`, `SNMP_CONTEXT_NAME`, `SNMP_SECURITY_MODE`, `SNMP_SECURITY_NAME`, `SNMP_AUTH_MODE`, `SNMP_AUTH_PWD`, `SNMP_PRIVACY_MODE`, `SNMP_PRIVACY_PWD`, `TEMPLATE_TYPE`, `TEMPLATE_NAME`) VALUES
	(0, 2, 161, 4, 3, 'public', 'public', '', 0, '', 0, '', 0, '', 0, 'default');
/*!40000 ALTER TABLE `tbl_snmp_config` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_subnet 结构
DROP TABLE IF EXISTS `tbl_subnet`;
CREATE TABLE IF NOT EXISTS `tbl_subnet` (
  `SUBNET_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SUBNET_NAME` varchar(128) NOT NULL,
  `SUBNET_IP` varchar(128) NOT NULL,
  `SUBNET_MASK` varchar(128) NOT NULL,
  `SUBNET_DEVNUM` int(10) unsigned NOT NULL,
  PRIMARY KEY (`SUBNET_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_subnet 的数据：~0 rows (大约)
DELETE FROM `tbl_subnet`;
/*!40000 ALTER TABLE `tbl_subnet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_subnet` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_telnet_config 结构
DROP TABLE IF EXISTS `tbl_telnet_config`;
CREATE TABLE IF NOT EXISTS `tbl_telnet_config` (
  `TELNET_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TELNET_AUTHMODE` smallint(3) NOT NULL,
  `TELNET_USERNAME` varchar(255) NOT NULL,
  `TELNET_PASSWORD` varchar(255) NOT NULL,
  `TELNET_PORT` int(10) unsigned NOT NULL,
  `TELNET_TIMEOUT` int(10) unsigned NOT NULL,
  `TELNET_RETRIES` int(10) unsigned NOT NULL,
  `TEMPLATE_TYPE` int(10) unsigned NOT NULL,
  `TEMPLATE_NAME` varchar(128) NOT NULL,
  PRIMARY KEY (`TELNET_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_resource.tbl_telnet_config 的数据：~1 rows (大约)
DELETE FROM `tbl_telnet_config`;
/*!40000 ALTER TABLE `tbl_telnet_config` DISABLE KEYS */;
INSERT INTO `tbl_telnet_config` (`TELNET_ID`, `TELNET_AUTHMODE`, `TELNET_USERNAME`, `TELNET_PASSWORD`, `TELNET_PORT`, `TELNET_TIMEOUT`, `TELNET_RETRIES`, `TEMPLATE_TYPE`, `TEMPLATE_NAME`) VALUES
	(0, 0, '', '', 23, 4, 3, 0, 'default');
/*!40000 ALTER TABLE `tbl_telnet_config` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_topo_node_info 结构
DROP TABLE IF EXISTS `tbl_topo_node_info`;
CREATE TABLE IF NOT EXISTS `tbl_topo_node_info` (
  `NODE_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `POS_X` double(20,2) NOT NULL DEFAULT '0.00',
  `POS_Y` double(20,2) NOT NULL DEFAULT '0.00',
  `DEV_ID` int(10) unsigned NOT NULL,
  `TOPO_VIEW_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`NODE_ID`),
  KEY `TOPO_VIEW_ID` (`TOPO_VIEW_ID`),
  CONSTRAINT `tbl_topo_node_info_ibfk_1` FOREIGN KEY (`TOPO_VIEW_ID`) REFERENCES `tbl_topo_view` (`VIEW_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 正在导出表  tnt_resource.tbl_topo_node_info 的数据：~0 rows (大约)
DELETE FROM `tbl_topo_node_info`;
/*!40000 ALTER TABLE `tbl_topo_node_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_topo_node_info` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_topo_view 结构
DROP TABLE IF EXISTS `tbl_topo_view`;
CREATE TABLE IF NOT EXISTS `tbl_topo_view` (
  `VIEW_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `VIEW_NAME` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `VIEW_DESC` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VIEW_PARENT` int(10) unsigned NOT NULL,
  `POS_X` double(20,2) NOT NULL DEFAULT '0.00',
  `POS_Y` double(20,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`VIEW_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 正在导出表  tnt_resource.tbl_topo_view 的数据：~0 rows (大约)
DELETE FROM `tbl_topo_view`;
/*!40000 ALTER TABLE `tbl_topo_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_topo_view` ENABLE KEYS */;


-- 导出  表 tnt_resource.tbl_type_info 结构
DROP TABLE IF EXISTS `tbl_type_info`;
CREATE TABLE IF NOT EXISTS `tbl_type_info` (
  `TYPE_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TYPE_NAME` varchar(128) NOT NULL,
  `SYSOID` varchar(255) NOT NULL,
  `CATEGORY_ID` int(10) unsigned NOT NULL,
  `TYPE_DESCRIPTION` varchar(255) DEFAULT NULL,
  `VENDOR` varchar(64) DEFAULT NULL,
  `TYPE_DEFAULT_DEV_ICON_ID` int(10) unsigned NOT NULL,
  `TYPE_DEFAULT_TOPO_ICON_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`TYPE_ID`),
  KEY `TYPE_DEFAULT_DEV_ICON_ID` (`TYPE_DEFAULT_DEV_ICON_ID`),
  KEY `TYPE_DEFAULT_TOPO_ICON_ID` (`TYPE_DEFAULT_TOPO_ICON_ID`),
  KEY `CATEGORY_ID` (`CATEGORY_ID`),
  CONSTRAINT `tbl_type_info_ibfk_1` FOREIGN KEY (`TYPE_DEFAULT_DEV_ICON_ID`) REFERENCES `tbl_icon_info` (`ICON_ID`),
  CONSTRAINT `tbl_type_info_ibfk_2` FOREIGN KEY (`TYPE_DEFAULT_TOPO_ICON_ID`) REFERENCES `tbl_icon_info` (`ICON_ID`),
  CONSTRAINT `tbl_type_info_ibfk_3` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `tbl_category_info` (`CATEGORY_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='this table store the info of devices type that nms supported';

-- 正在导出表  tnt_resource.tbl_type_info 的数据：~30 rows (大约)
DELETE FROM `tbl_type_info`;
/*!40000 ALTER TABLE `tbl_type_info` DISABLE KEYS */;
INSERT INTO `tbl_type_info` (`TYPE_ID`, `TYPE_NAME`, `SYSOID`, `CATEGORY_ID`, `TYPE_DESCRIPTION`, `VENDOR`, `TYPE_DEFAULT_DEV_ICON_ID`, `TYPE_DEFAULT_TOPO_ICON_ID`) VALUES
	(1, 'ICMP Device', '*', 3, 'ICMP Device', 'Unknown', 3, 3),
	(2, '', '0.0.0.0.0', 4, 'Unknown Snmp Device', 'Unknown', 4, 4),
	(3, 'TL-SL5428', '1.3.6.1.4.1.11863.1.1.1', 1, 'TL-SL5428', 'TP-LINK', 1, 1),
	(4, 'TL-SL3452', '1.3.6.1.4.1.11863.1.1.2', 1, 'TL-SL3452', 'TP-LINK', 1, 1),
	(5, 'TL-SG3424', '1.3.6.1.4.1.11863.1.1.3', 1, 'TL-SG3424', 'TP-LINK', 1, 1),
	(6, 'TL-SG3216', '1.3.6.1.4.1.11863.1.1.4', 1, 'TL-SG3216', 'TP-LINK', 1, 1),
	(7, 'TL-SG3210', '1.3.6.1.4.1.11863.1.1.5', 1, 'TL-SG3210', 'TP-LINK', 1, 1),
	(8, 'TL-SL3428', '1.3.6.1.4.1.11863.1.1.6', 1, 'TL-SL3428', 'TP-LINK', 1, 1),
	(9, 'TL-SG5428 ', '1.3.6.1.4.1.11863.1.1.7', 1, 'TL-SG5428', 'TP-LINK', 1, 1),
	(10, 'TL-SG3424P', '1.3.6.1.4.1.11863.1.1.8', 1, 'TL-SG3424P', 'TP-LINK', 1, 1),
	(11, 'TL-SG5412F', '1.3.6.1.4.1.11863.1.1.9', 1, 'TL-SG5412F', 'TP-LINK', 1, 1),
	(12, 'T2700-28T', '1.3.6.1.4.1.11863.5.10', 1, 'T2700-28T', 'TP-LINK', 1, 1),
	(13, 'TL-SL2428', '1.3.6.1.4.1.11863.1.1.11', 1, 'TL-SL2428', 'TP-LINK', 1, 1),
	(14, 'TL-SG2216', '1.3.6.1.4.1.11863.1.1.12', 1, 'TL-SG2216', 'TP-LINK', 1, 1),
	(15, 'TL-SG2424', '1.3.6.1.4.1.11863.1.1.13', 1, 'TL-SG2424', 'TP-LINK', 1, 1),
	(16, 'TL-SG5428', '1.3.6.1.4.1.11863.1.1.14', 1, 'TL-SG5428', 'TP-LINK', 1, 1),
	(17, 'TL-SG2452 ', '1.3.6.1.4.1.11863.1.1.15', 1, 'TL-SG2452', 'TP-LINK', 1, 1),
	(18, 'TL-SL2218', '1.3.6.1.4.1.11863.1.1.16', 1, 'TL-SL2218', 'TP-LINK', 1, 1),
	(19, 'TL-SG2424P', '1.3.6.1.4.1.11863.1.1.17', 1, 'TL-SG2424P', 'TP-LINK', 1, 1),
	(20, 'TL-SG2210', '1.3.6.1.4.1.11863.1.1.18', 1, 'TL-SG2210', 'TP-LINK', 1, 1),
	(21, 'TL-SL2210', '1.3.6.1.4.1.11863.1.1.19', 1, 'TL-SL2210', 'TP-LINK', 1, 1),
	(22, 'T3700', '1.3.6.1.4.1.11863.5.20', 1, 'T3700', 'TP-LINK', 1, 1),
	(23, 'TL-SL2226P', '1.3.6.1.4.1.11863.1.1.21', 1, 'TL-SL2226P', 'TP-LINK', 1, 1),
	(24, 'TL-SL2452', '1.3.6.1.4.1.11863.1.1.22', 1, 'TL-SL2452', 'TP-LINK', 1, 1),
	(25, 'TL-SL2218P', '1.3.6.1.4.1.11863.1.1.23', 1, 'TL-SL2218P', 'TP-LINK', 1, 1),
	(26, 'TL-SG3424', '1.3.6.1.4.1.11863.1.1.24', 1, 'TL-SG3424', 'TP-LINK', 1, 1),
	(27, 'TL-SG2008', '1.3.6.1.4.1.11863.1.1.25', 1, 'TL-SG2008', 'TP-LINK', 1, 1),
	(28, 'TL-SG2210P', '1.3.6.1.4.1.11863.1.1.26', 1, 'TL-SG2210P', 'TP-LINK', 1, 1),
	(29, 'H3C Device', '1.3.6.1.4.1.25506.*', 4, 'H3C Device', 'H3C', 4, 4),
	(30, 'Cisco Device', '1.3.6.1.4.1.9.*', 4, 'Cisco Device', 'CISCO', 4, 4);
/*!40000 ALTER TABLE `tbl_type_info` ENABLE KEYS */;


-- 导出 tnt_sm 的数据库结构
DROP DATABASE IF EXISTS `tnt_sm`;
CREATE DATABASE IF NOT EXISTS `tnt_sm` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tnt_sm`;


-- 导出  表 tnt_sm.account_profile 结构
DROP TABLE IF EXISTS `account_profile`;
CREATE TABLE IF NOT EXISTS `account_profile` (
  `ID` int(11) NOT NULL,
  `ALLOWED_FAIL_TIMES` int(11) DEFAULT NULL,
  `LOCKED_FOREVER` bit(1) DEFAULT NULL,
  `LOCKING_DURATION` int(11) DEFAULT NULL,
  `LOCKING_PERIOD` int(11) DEFAULT NULL,
  `NOT_LOCK_LOGIN_FAIL_USER` bit(1) DEFAULT NULL,
  `NOT_STOP_NO_LOGIN_USER` bit(1) DEFAULT NULL,
  `STOPPING_PERIOD` int(11) DEFAULT NULL,
  `USER_NAME_MAX_LEN` int(11) DEFAULT NULL,
  `USER_NAME_MIN_LEN` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.account_profile 的数据：~1 rows (大约)
DELETE FROM `account_profile`;
/*!40000 ALTER TABLE `account_profile` DISABLE KEYS */;
INSERT INTO `account_profile` (`ID`, `ALLOWED_FAIL_TIMES`, `LOCKED_FOREVER`, `LOCKING_DURATION`, `LOCKING_PERIOD`, `NOT_LOCK_LOGIN_FAIL_USER`, `NOT_STOP_NO_LOGIN_USER`, `STOPPING_PERIOD`, `USER_NAME_MAX_LEN`, `USER_NAME_MIN_LEN`) VALUES
	(1, 3, b'0', 30, 10, b'1', b'0', 60, 30, 4);
/*!40000 ALTER TABLE `account_profile` ENABLE KEYS */;


-- 导出  表 tnt_sm.function_module 结构
DROP TABLE IF EXISTS `function_module`;
CREATE TABLE IF NOT EXISTS `function_module` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MODULE_NAME` varchar(64) NOT NULL,
  `IS_DEFAULT` tinyint(4) NOT NULL,
  `PATH` varchar(64) DEFAULT NULL,
  `SUB_MENU` varchar(1024) DEFAULT NULL,
  `DESCRIPTION` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.function_module 的数据：~6 rows (大约)
DELETE FROM `function_module`;
/*!40000 ALTER TABLE `function_module` DISABLE KEYS */;
INSERT INTO `function_module` (`ID`, `MODULE_NAME`, `IS_DEFAULT`, `PATH`, `SUB_MENU`, `DESCRIPTION`) VALUES
	(1, 'deviceMgr', 1, 'resourcemgr', NULL, 'sm.ui.desc.deviceManagement'),
	(2, 'monitor', 1, 'pm', NULL, 'sm.ui.desc.monitor'),
	(3, 'alarm', 1, 'fm', NULL, 'sm.ui.desc.alarm'),
	(4, 'user', 0, 'sm', NULL, 'sm.ui.desc.user'),
	(5, 'system', 0, 'system', NULL, 'sm.ui.desc.system'),
	(6, 'config', 0, 'cm', NULL, 'sm.ui.desc.config');
/*!40000 ALTER TABLE `function_module` ENABLE KEYS */;


-- 导出  表 tnt_sm.nms_oper 结构
DROP TABLE IF EXISTS `nms_oper`;
CREATE TABLE IF NOT EXISTS `nms_oper` (
  `OPER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `DESCRTIPTION` longtext,
  `OPER_DETAIL` longtext,
  `OPER_NAME` longtext,
  PRIMARY KEY (`OPER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.nms_oper 的数据：~12 rows (大约)
DELETE FROM `nms_oper`;
/*!40000 ALTER TABLE `nms_oper` DISABLE KEYS */;
INSERT INTO `nms_oper` (`OPER_ID`, `DESCRTIPTION`, `OPER_DETAIL`, `OPER_NAME`) VALUES
	(1, NULL, 'resourcemgr view', 'resourcemgr:view'),
	(2, NULL, 'resourcemgr modify', 'resourcemgr:modify'),
	(3, NULL, 'pm view', 'pm:view'),
	(4, NULL, 'pm modify', 'pm:modify'),
	(5, NULL, 'fm view', 'fm:view'),
	(6, NULL, 'fm modify', 'fm:modify'),
	(7, NULL, 'sm view', 'sm:view'),
	(8, NULL, 'sm modify', 'sm:modify'),
	(9, NULL, 'cm view', 'cm:view'),
	(10, NULL, 'cm modify', 'cm:modify'),
	(11, NULL, 'system view', 'system:view'),
	(12, NULL, 'system modify', 'system:modify');
/*!40000 ALTER TABLE `nms_oper` ENABLE KEYS */;


-- 导出  表 tnt_sm.nms_resource 结构
DROP TABLE IF EXISTS `nms_resource`;
CREATE TABLE IF NOT EXISTS `nms_resource` (
  `RES_ID` int(11) NOT NULL AUTO_INCREMENT,
  `DESCRIPTION` longtext,
  `RES_DETAIL` longtext,
  `RES_NAME` longtext,
  `TYPE` longtext,
  `VERSION` longtext,
  PRIMARY KEY (`RES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.nms_resource 的数据：~0 rows (大约)
DELETE FROM `nms_resource`;
/*!40000 ALTER TABLE `nms_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `nms_resource` ENABLE KEYS */;


-- 导出  表 tnt_sm.nms_role 结构
DROP TABLE IF EXISTS `nms_role`;
CREATE TABLE IF NOT EXISTS `nms_role` (
  `ROLE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CREATED_BY` longtext,
  `CREATED_TIME` datetime NOT NULL,
  `IS_DEFAULT` tinyint(4) DEFAULT NULL,
  `DESCRIPTION` longtext,
  `ROLE_NAME` longtext,
  PRIMARY KEY (`ROLE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.nms_role 的数据：~3 rows (大约)
DELETE FROM `nms_role`;
/*!40000 ALTER TABLE `nms_role` DISABLE KEYS */;
INSERT INTO `nms_role` (`ROLE_ID`, `CREATED_BY`, `CREATED_TIME`, `IS_DEFAULT`, `DESCRIPTION`, `ROLE_NAME`) VALUES
	(1, 'system', '2014-05-26 00:00:00', 1, 'administrator', 'administrator'),
	(2, 'system', '2014-05-26 00:00:00', 1, 'operator', 'operator'),
	(3, 'system', '2014-05-26 00:00:00', 1, 'observer', 'observer');
/*!40000 ALTER TABLE `nms_role` ENABLE KEYS */;


-- 导出  表 tnt_sm.nms_user 结构
DROP TABLE IF EXISTS `nms_user`;
CREATE TABLE IF NOT EXISTS `nms_user` (
  `USER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `AUTH_TYPE` int(11) DEFAULT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `DESCRIPTION` longtext,
  `EMAIL` varchar(128) DEFAULT NULL,
  `FAILED_COUNT` int(11) DEFAULT NULL,
  `IS_INITIAL_PWD` int(11) DEFAULT NULL,
  `IS_LOCKED` int(11) DEFAULT NULL,
  `IS_STOPPED` int(11) DEFAULT NULL,
  `LAST_LOGIN_TIME` datetime DEFAULT NULL,
  `LAST_PWD_CHANGE_TIME` datetime DEFAULT NULL,
  `LOCKED_TIME` datetime DEFAULT NULL,
  `PASSWORD` longtext,
  `STATUS` varchar(30) DEFAULT NULL,
  `TIME_PROFILE_ID` int(11) DEFAULT NULL,
  `NAME` longtext,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.nms_user 的数据：~1 rows (大约)
DELETE FROM `nms_user`;
/*!40000 ALTER TABLE `nms_user` DISABLE KEYS */;
INSERT INTO `nms_user` (`USER_ID`, `AUTH_TYPE`, `CREATED_TIME`, `DESCRIPTION`, `EMAIL`, `FAILED_COUNT`, `IS_INITIAL_PWD`, `IS_LOCKED`, `IS_STOPPED`, `LAST_LOGIN_TIME`, `LAST_PWD_CHANGE_TIME`, `LOCKED_TIME`, `PASSWORD`, `STATUS`, `TIME_PROFILE_ID`, `NAME`) VALUES
	(1, NULL, '2014-05-21 11:18:03', '', 'admin@system.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '123456a', 'active', NULL, 'admin');
/*!40000 ALTER TABLE `nms_user` ENABLE KEYS */;


-- 导出  表 tnt_sm.password_profile 结构
DROP TABLE IF EXISTS `password_profile`;
CREATE TABLE IF NOT EXISTS `password_profile` (
  `id` int(11) NOT NULL,
  `COMPLEXITY_DEGREE` varchar(32) DEFAULT NULL,
  `MUST_CONTAIN_SPECIAL_CHAR` bit(1) DEFAULT NULL,
  `NOT_LIMIT_RETENTION_PERIOD` int(11) DEFAULT NULL,
  `PASSWORD_MAX_LEN` int(11) DEFAULT NULL,
  `PASSWORD_MIN_LEN` int(11) DEFAULT NULL,
  `REMIND_DAYS_BEFORE_TERM` int(11) DEFAULT NULL,
  `RETENTION_PERIOD` int(11) DEFAULT NULL,
  `SPECIAL_CHAR` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.password_profile 的数据：~1 rows (大约)
DELETE FROM `password_profile`;
/*!40000 ALTER TABLE `password_profile` DISABLE KEYS */;
INSERT INTO `password_profile` (`id`, `COMPLEXITY_DEGREE`, `MUST_CONTAIN_SPECIAL_CHAR`, `NOT_LIMIT_RETENTION_PERIOD`, `PASSWORD_MAX_LEN`, `PASSWORD_MIN_LEN`, `REMIND_DAYS_BEFORE_TERM`, `RETENTION_PERIOD`, `SPECIAL_CHAR`) VALUES
	(1, NULL, NULL, NULL, 20, 6, NULL, NULL, NULL);
/*!40000 ALTER TABLE `password_profile` ENABLE KEYS */;


-- 导出  表 tnt_sm.role_oper_relation 结构
DROP TABLE IF EXISTS `role_oper_relation`;
CREATE TABLE IF NOT EXISTS `role_oper_relation` (
  `ROLE_ID` int(11) NOT NULL,
  `OPER_ID` int(11) NOT NULL,
  PRIMARY KEY (`ROLE_ID`,`OPER_ID`),
  KEY `FK24D688C4B9A33494` (`ROLE_ID`),
  KEY `FK24D688C42222C7B9` (`OPER_ID`),
  CONSTRAINT `FK24D688C42222C7B9` FOREIGN KEY (`OPER_ID`) REFERENCES `nms_oper` (`OPER_ID`),
  CONSTRAINT `FK24D688C4B9A33494` FOREIGN KEY (`ROLE_ID`) REFERENCES `nms_role` (`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.role_oper_relation 的数据：~28 rows (大约)
DELETE FROM `role_oper_relation`;
/*!40000 ALTER TABLE `role_oper_relation` DISABLE KEYS */;
INSERT INTO `role_oper_relation` (`ROLE_ID`, `OPER_ID`) VALUES
	(1, 1),
	(1, 2),
	(1, 3),
	(1, 4),
	(1, 5),
	(1, 6),
	(1, 7),
	(1, 8),
	(1, 9),
	(1, 10),
	(1, 11),
	(1, 12),
	(2, 1),
	(2, 2),
	(2, 3),
	(2, 4),
	(2, 5),
	(2, 6),
	(2, 7),
	(2, 9),
	(2, 10),
	(2, 11),
	(3, 1),
	(3, 3),
	(3, 5),
	(3, 7),
	(3, 9),
	(3, 11);
/*!40000 ALTER TABLE `role_oper_relation` ENABLE KEYS */;


-- 导出  表 tnt_sm.role_res_relation 结构
DROP TABLE IF EXISTS `role_res_relation`;
CREATE TABLE IF NOT EXISTS `role_res_relation` (
  `ROLE_ID` int(11) NOT NULL,
  `RES_ID` int(11) NOT NULL,
  PRIMARY KEY (`ROLE_ID`,`RES_ID`),
  KEY `FKE41FFE4DE8D0AD7` (`RES_ID`),
  KEY `FKE41FFE4B9A33494` (`ROLE_ID`),
  CONSTRAINT `FKE41FFE4B9A33494` FOREIGN KEY (`ROLE_ID`) REFERENCES `nms_role` (`ROLE_ID`),
  CONSTRAINT `FKE41FFE4DE8D0AD7` FOREIGN KEY (`RES_ID`) REFERENCES `nms_resource` (`RES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.role_res_relation 的数据：~0 rows (大约)
DELETE FROM `role_res_relation`;
/*!40000 ALTER TABLE `role_res_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_res_relation` ENABLE KEYS */;


-- 导出  表 tnt_sm.terminal_profile 结构
DROP TABLE IF EXISTS `terminal_profile`;
CREATE TABLE IF NOT EXISTS `terminal_profile` (
  `TERMINAL_PROFILE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime NOT NULL,
  `DESCRIPTION` longtext,
  `END_IP` varchar(64) DEFAULT NULL,
  `START_IP` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`TERMINAL_PROFILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.terminal_profile 的数据：~0 rows (大约)
DELETE FROM `terminal_profile`;
/*!40000 ALTER TABLE `terminal_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `terminal_profile` ENABLE KEYS */;


-- 导出  表 tnt_sm.time_profile 结构
DROP TABLE IF EXISTS `time_profile`;
CREATE TABLE IF NOT EXISTS `time_profile` (
  `TIME_PROFILE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime NOT NULL,
  `description` longtext,
  `END_DATE` datetime DEFAULT NULL,
  `END_TIME_EVERYDAT` datetime DEFAULT NULL,
  `name` longtext,
  `START_DATE` datetime DEFAULT NULL,
  `START_TIME_EVERYDAY` datetime DEFAULT NULL,
  `WORKING_DAYS` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`TIME_PROFILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.time_profile 的数据：~0 rows (大约)
DELETE FROM `time_profile`;
/*!40000 ALTER TABLE `time_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `time_profile` ENABLE KEYS */;


-- 导出  表 tnt_sm.user_online_monitor 结构
DROP TABLE IF EXISTS `user_online_monitor`;
CREATE TABLE IF NOT EXISTS `user_online_monitor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACCESS_IP` longtext,
  `LOG_IN_TIME` datetime DEFAULT NULL,
  `SESSION_ID` longtext,
  `STATUS` varchar(128) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.user_online_monitor 的数据：~0 rows (大约)
DELETE FROM `user_online_monitor`;
/*!40000 ALTER TABLE `user_online_monitor` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_online_monitor` ENABLE KEYS */;


-- 导出  表 tnt_sm.user_oper_log 结构
DROP TABLE IF EXISTS `user_oper_log`;
CREATE TABLE IF NOT EXISTS `user_oper_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DESCRIPTION` longtext,
  `IP_ADDRESS` varchar(64) DEFAULT NULL,
  `LOG_LEVEL` varchar(10) DEFAULT NULL,
  `OPER_TIME` datetime DEFAULT NULL,
  `RESULT` varchar(10) DEFAULT NULL,
  `SOURCE` longtext,
  `TARGET_OBJ` longtext,
  `USER_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.user_oper_log 的数据：~0 rows (大约)
DELETE FROM `user_oper_log`;
/*!40000 ALTER TABLE `user_oper_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_oper_log` ENABLE KEYS */;


-- 导出  表 tnt_sm.user_role_relation 结构
DROP TABLE IF EXISTS `user_role_relation`;
CREATE TABLE IF NOT EXISTS `user_role_relation` (
  `USER_ID` int(11) NOT NULL,
  `ROLE_ID` int(11) NOT NULL,
  PRIMARY KEY (`ROLE_ID`,`USER_ID`),
  KEY `FK88B88E31B9A33494` (`ROLE_ID`),
  KEY `FK88B88E315ECDF874` (`USER_ID`),
  CONSTRAINT `FK88B88E315ECDF874` FOREIGN KEY (`USER_ID`) REFERENCES `nms_user` (`USER_ID`),
  CONSTRAINT `FK88B88E31B9A33494` FOREIGN KEY (`ROLE_ID`) REFERENCES `nms_role` (`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.user_role_relation 的数据：~1 rows (大约)
DELETE FROM `user_role_relation`;
/*!40000 ALTER TABLE `user_role_relation` DISABLE KEYS */;
INSERT INTO `user_role_relation` (`USER_ID`, `ROLE_ID`) VALUES
	(1, 1);
/*!40000 ALTER TABLE `user_role_relation` ENABLE KEYS */;


-- 导出  表 tnt_sm.user_terminal_relation 结构
DROP TABLE IF EXISTS `user_terminal_relation`;
CREATE TABLE IF NOT EXISTS `user_terminal_relation` (
  `USER_ID` int(11) NOT NULL,
  `TERMINAL_PROFILE_ID` int(11) NOT NULL,
  PRIMARY KEY (`USER_ID`,`TERMINAL_PROFILE_ID`),
  KEY `FK49693CEBE661C7` (`TERMINAL_PROFILE_ID`),
  KEY `FK49693CEB5ECDF874` (`USER_ID`),
  CONSTRAINT `FK49693CEB5ECDF874` FOREIGN KEY (`USER_ID`) REFERENCES `nms_user` (`USER_ID`),
  CONSTRAINT `FK49693CEBE661C7` FOREIGN KEY (`TERMINAL_PROFILE_ID`) REFERENCES `terminal_profile` (`TERMINAL_PROFILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  tnt_sm.user_terminal_relation 的数据：~0 rows (大约)
DELETE FROM `user_terminal_relation`;
/*!40000 ALTER TABLE `user_terminal_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_terminal_relation` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
