package ch08.se09.common.dao.impl;

import ch08.se09.common.dao.BaseDao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.io.Serializable;
import java.util.List;

public class BaseDaoJpaImpl<T> implements BaseDao<T> {
    @PersistenceContext
    private EntityManager entityManager;

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public T get(Class<T> entityClazz, Serializable id) {
        return entityManager.find(entityClazz, id);
    }

    @Override
    public Serializable save(T entity) {
        entityManager.persist(entity);
        try {
            return (Serializable)entity.getClass().getMethod("getId").invoke(entity);
        } catch(Exception e) {
            e.printStackTrace();
            throw new RuntimeException(entity + "必须提供getId()方法！");
        }
    }

    @Override
    public void update(T entity) {
        entityManager.merge(entity);
    }

    @Override
    public void delete(T entity) {
        entityManager.remove(entity);
    }

    @Override
    public void delete(Class<T> entityClazz, Serializable id) {
        entityManager.createQuery("delete " + entityClazz.getSimpleName() + " en where en.id=?0")
                .setParameter(0, id)
                .executeUpdate();
    }

    // 获取所有实体
    public List<T> findAll(Class<T> entityClazz)
    {
        return find("select en from "
                + entityClazz.getSimpleName() + " en");
    }
    // 获取实体总数
    public long findCount(Class<T> entityClazz)
    {
        List<?> l = find("select count(*) from "
                + entityClazz.getSimpleName());
        // 返回查询得到的实体总数
        if (l != null && l.size() == 1 )
        {
            return (Long)l.get(0);
        }
        return 0;
    }

    // 根据JPQL语句查询实体
    @SuppressWarnings("unchecked")
    protected List<T> find(String jpql)
    {
        return (List<T>)entityManager.createQuery(jpql)
                .getResultList();
    }
    // 根据带占位符参数JPQL语句查询实体
    @SuppressWarnings("unchecked")
    protected List<T> find(String jpql , Object... params)
    {
        // 创建查询
        Query query = entityManager.createQuery(jpql);
        // 为包含占位符的JPQL语句设置参数
        for(int i = 0 , len = params.length ; i < len ; i++)
        {
            query.setParameter(i , params[i]);
        }
        return (List<T>)query.getResultList();
    }
    /**
     * 使用JPQL语句进行分页查询操作
     * @param jpql 需要查询的JPQL语句
     * @param pageNo 查询第pageNo页的记录
     * @param pageSize 每页需要显示的记录数
     * @return 当前页的所有记录
     */
    @SuppressWarnings("unchecked")
    protected List<T> findByPage(String jpql,
                                 int pageNo, int pageSize)
    {
        // 创建查询
        return entityManager.createQuery(jpql)
                // 执行分页
                .setFirstResult((pageNo - 1) * pageSize)
                .setMaxResults(pageSize)
                .getResultList();
    }
    /**
     * 使用JPQL语句进行分页查询操作
     * @param jpql 需要查询的JPQL语句
     * @param params 如果jpql带占位符参数，params用于传入占位符参数
     * @param pageNo 查询第pageNo页的记录
     * @param pageSize 每页需要显示的记录数
     * @return 当前页的所有记录
     */
    @SuppressWarnings("unchecked")
    protected List<T> findByPage(String jpql , int pageNo, int pageSize
            , Object... params)
    {
        // 创建查询
        Query query = entityManager.createQuery(jpql);
        // 为包含占位符的JPQL语句设置参数
        for(int i = 0 , len = params.length ; i < len ; i++)
        {
            query.setParameter(i , params[i]);
        }
        // 执行分页，并返回查询结果
        return query.setFirstResult((pageNo - 1) * pageSize)
                .setMaxResults(pageSize)
                .getResultList();
    }
}
