package ch08.se09.booksys.dao;

import ch08.se09.booksys.domain.Book;
import ch08.se09.common.dao.BaseDao;

public interface BookDao extends BaseDao<Book> {

}
