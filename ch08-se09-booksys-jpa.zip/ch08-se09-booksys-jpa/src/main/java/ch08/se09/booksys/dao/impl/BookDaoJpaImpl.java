package ch08.se09.booksys.dao.impl;

import ch08.se09.booksys.dao.BookDao;
import ch08.se09.booksys.domain.Book;
import ch08.se09.common.dao.impl.BaseDaoJpaImpl;

public class BookDaoJpaImpl extends BaseDaoJpaImpl<Book> implements BookDao {

}
