package ch08.se09.booksys.service;

import ch08.se09.booksys.domain.Book;

import java.util.List;

public interface BookService {

	int addBook(Book book);

	List<Book> getAllBooks();

	void deleteBook(int id);
	
}
